<?php
// Version: 2.0; Themes

global $scripturl;

$txt['maintenance'] = '(Maintenance)';
$txt['approval_member'] = 'Approval';
$txt['open_reports'] = 'Reports';
$txt['forum_search'] = 'Search...';

?>