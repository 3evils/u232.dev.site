<?php
// Version: 2.0; Themestrings

$txt['welcome_dude'] = 'Welcome, <strong>Guest</strong>.<br /> Please <a href="' . $scripturl . '?action=login">login</a> or <a href="' . $scripturl . '?action=register">register</a>.';

?>