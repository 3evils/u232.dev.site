<?php
/**********************************************************************************
* install_db.php - Search for & install database log, scheduled task & modsettings
* Version 1.1.3 by JMiller a/k/a butchs
* (http://www.eastcoastrollingthunder.com) 
*********************************************************************************
* This program is distributed in the hope that it is and will be useful, but
* WITHOUT ANY WARRANTIES; without even any implied warranty of MERCHANTABILITY
* or FITNESS FOR A PARTICULAR PURPOSE.
**********************************************************************************/

// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')) {
	require_once(dirname(__FILE__) . '/SSI.php'); }

// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF')) die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

global $boarddir, $sourcedir, $language, $user_info, $db_prefix, $ssi_theme, $settings, $modSettings;

if ((SMF == 'SSI') && !$user_info['is_admin']) die('Admin priveleges required.');

$bad_countries = $injection_list = $xss_events = $referer_attacks = $ua_attacks = $permitted_uri_chars = $robotstxt_action = '';
$your_host = $your_domain_name = $your_domain_ip = $rand_salt = $your_domain_port = $enity_attacks = $test_robots = '';
$bad_countries = 'XX';
$permitted_uri_chars = 'a-z 0-9~%$,.:;[]&#?/+=_\-';
$injection_list = '&stop=true|&ved=|num_replies=7777777|admin;area=topic_view|attachments|avatars|boarddir|cache|config.inc|imagesdir|scripts|Settings.php|sourcedir|Sources|themedir|Themes/|/css|chr(|chr=|chr%20|%20chr|wget%20|%20wget|wget(|cmd=|%20cmd|cmd%20|roc/self/environ|rush|union|echr(|%20echr|echr%20|echr=|esystem(|esystem%20|exec(|exec%28|cp%20|%20cp|cp(|mdir%20|%20mdir|mdir(|mcd%20|mrd%20|rm%20|%20mcd|%20mrd|%20rm|mcd(|mrd(|rm(|mcd=|mrd=|mv%20|rmdir%20|mv(|rmdir(|chmod(|chmod%20|%20chmod|chmod(|chmod=|chown%20|chgrp%20|chown(|chgrp(|CONCAT|locate%20|locus7|storm7|grep%20|locate(|grep(|diff%20|kill%20|kill(|killall|passwd%20|%20passwd|passwd(|telnet%20|vi(|vi%20|insert%20into|select|sshphp|nigga(|$sesc|%20nigga|nigga%20|fopen|fwrite|%20like|like%20|_REQUEST|_GET|$REQUEST|$GET|.system|HTTP_PHP|&aim|%20getenv|getenv%20|new_password|&icq|/etc/password|/etc/shadow|/etc/groups|/etc/gshadow|HTTP_USER_AGENT|HTTP_HOST|/bin/ps|wget%20|uname\x20-a|/usr/bin/id|/bin/echo|/bin/kill|/bin/|/sbin/|/usr/sbin|/chgrp|/chown|/usr/bin|g\+\+|bin/python|bin/tclsh|bin/nasm|perl%20|traceroute%20|ping%20|.pl|/usr/X11R6/bin/xterm|lsof%20|/bin/mail|.conf|motd%20|HTTP/1.|.inc.php|config.php|cgi-|.eml|file\://|file://|fileditor|window.open|Java|javascript\://|ijavascript://|mg src|img%20src|.jsp|ftp.exe|xp_enumdsn|xp_availablemedia|xp_filelist|shell|nc.exe|.htpasswd|servlet|/etc/passwd|webadmin|wwwacl|~root|~ftp|.jsp|admin_|.history|bash_history|.bash_history|~nobody|server-info|server-status|reboot%20|nstview|remview|remoteview|halt%20|pcom|powerdown%20|/home/ftp|/home/www|secure_site, ok|chunked|org.apache|/servlet/con|<script|/robot.txt|/robots.txt|/perl|mod_gzip_status|db_mysql.inc|.inc|select%20from|select from|drop%20|getenv|http_|_php|php_|phpget|phpinfo()|phpwriter|<?|?>|sql=|%2527|<br|cc:|bcc:|\0|\r|\n|"%20or%200=0%20--|or%200=0%20--|"%20or%200=0%20#|or%200=0%20#|"%20or%20"x"="x|"%20or%201=1--|or%201=1--|"%20or%20"a"="a|")%20or%20("a"="a|hi"%20or%20"a"="a|hi"%20or%201=1%20--|hi")%20or%20("a"="a|c99shell|r57shell|99.txt|.txt|C99.PHP|crystalshell|phpshell|dtool|fetch%20|curl%20|lynx%20|ls%20-|/var/tmp|cd%20|_SERVER|$SERVER|$POST|rundll32|PHP_SELF|<iframe|<a href|<javascript|alert(|<img|<embed|<object|[php|%5bphp|%20src|%2f|%3f|%3a|%40|%3d|%26|%3c|%3e|%22|%23|%7b|%7d|%7c|%5c|%5e|%7e|%5b|%5d|%60|%25|%27|\x3b|\x2f|\x3f|\x3a|\x40|\x3d|\x26|\x3c|\x3e|\x22|\x23|\x7b|\x7d|\x7c|\x5c|\x5e|\x7e|\x5b|\x5d|\x60|\x25|\x27';
$xss_events = 'alert(|<applet|<a href|base|<behavior|<bgsound|<blink|<body|<div|<embed|eval|exec|<expression|file(|file (|FileInputStream|flash|fopen|<form|<frame|fsockopen|fromCharCode|<head|<html|<iframe|<ilayer|<input|<img|src=|src
=|<javascript|javascript:|javascript\:|window\.|document\.|document.write|\.cookie|<layer|<link|<lowsrc|<meta|<object|onabort|onactivate|onafterprint|onafterupdate|onbeforeactivate|onbeforecopy|onbeforecut|onbeforedeactivate|onbeforeeditfocus|onbeforepaste|onbeforeprint|onbeforeunload|onbeforeupdate|onblur|onbounce|oncellchange|onchange|onclick|oncontextmenu|oncontrolselect|oncopy|oncut|ondataavailable|ondatasetchanged|ondatasetcomplete|ondblclick|ondeactivate|ondrag|ondrop|onerror|onfilterchange|onfinish|onfocus|onhelp|onkeydown|onkeypress|onkeyup|onlayoutcomplete|onload|onlosecapture|onmousedown|onmouseenter|onmouseleave|onmousemove|onmouseout|onmouseover|onmouseup|onmousewheel|onmove|onpaste|onpropertychange|onreadystatechange|onreset|onresize|onresizeend|onresizestart|onrowenter|onrowexit|onrowsdelete|onrowsinserted|onscroll|onselect|onselectionchange|onselectstart|onstart|onstop|onsubmit|onunload|passthru|<plaintext|<?|?>|phpinfo|Redirect|<script|<scr\0ipt|</script|<style|.system|system(|<textarea|<title|unlink|<vbscript|xml|xss';
$referer_attacks = '<?|?>|drop table| href|<applet|<iframe|<meta|<script|/script>|<style|[url=|[/url|.php++|result:+%0|result:+%1|result:+%8|result:+%9|result:+%a|result:+%b|result:+%c|result:+%d|result:+%e|result:+%f|vbscript|javascript';
$ua_attacks = '<?|?>|droptable| href|iframe|<script|/script>|<a|/a>|[url=';
$enity_attacks = 'base64_decode|die(|die%28|echo(|echo%28|eval(|eval%28|exec(|exec%28|include(|include%28|<methodCall|</methodCall|<name|</name|<param|</param|passthru(|passthru%28|%5b|[php|%5bphp|<php|[/php|php_uname(|php_uname%28|<script|</script|<value|</value|%2f|%26|%22|%27|\x2f|\x26|\x22|\x27';
$test_robots = 'Googlebot|Mediapartners-Google|AdsBot-Google|Yahoo! Slurp|Yahoo! SearchMonkey|bingbot|msnbot|MS Search';
$your_ip  = '00.00.00.00';
if ((isset($_SERVER['REMOTE_ADDR'])) && (!empty($_SERVER['REMOTE_ADDR'])))
	$your_ip = $_SERVER['REMOTE_ADDR'];
$your_host = 'www.yourhost.com';
if (function_exists('is_callable') && ($_SERVER['REMOTE_ADDR'] != '') && ($_SERVER['REMOTE_ADDR'])) {
	if ((gethostbyaddr($_SERVER['REMOTE_ADDR'])) && (gethostbyaddr($_SERVER['REMOTE_ADDR']) != ''))
	$your_host = gethostbyaddr($_SERVER['REMOTE_ADDR']); }
$your_domain_name = 'www.yourdomain.com';
if ((isset($_SERVER['SERVER_NAME'])) && (!empty($_SERVER['SERVER_NAME'])))
	$your_domain_name = $_SERVER['SERVER_NAME'];
$your_domain_ip = '00.00.00.00';
if ((isset($_SERVER['SERVER_ADDR'])) && (!empty($_SERVER['SERVER_ADDR'])))
	$your_domain_ip = $_SERVER['SERVER_ADDR'];
// Running on IIS?
if ((isset($_SERVER['LOCAL_ADDR'])) && (!empty($_SERVER['LOCAL_ADDR'])))
	$your_domain_ip = $_SERVER['LOCAL_ADDR'];
$rand_salt = forumfirewall_install_gen_salty();
if (empty($rand_salt) || (strlen($rand_salt) < 4)) {
	$rand_salt = forumfirewall_install_gen_salty();
	if (empty($rand_salt) || (strlen($rand_salt) < 4)) $rand_salt = 'salt'; }
$your_domain_port = '80';
if ((isset($_SERVER['SERVER_PORT'])) && (!empty($_SERVER['SERVER_PORT'])))
	$your_domain_port = $_SERVER['SERVER_PORT'];
if ($your_domain_name !== 'www.yourdomain.com')
	$robotstxt_action = forumfirewall_install_check_robot_txt($your_domain_name.':'.$your_domain_port);

if (isset($smcFunc)) {
	if (function_exists('db_extend')) {
		db_extend('packages');
		db_extend();
	} else {
		require_once($sourcedir . '/Subs-Db-mysql.php');
		db_extend('packages');
		db_extend(); }

	//  remove old verision modsettings
	if ((isset($modSettings['forumfirewall_goodgroup']))) {
		$smcFunc['db_query']('', '
			DELETE FROM {db_prefix}settings WHERE variable = "forumfirewall_goodgroup"
		');
	}

	//  Add scheduled task for smf 2.0
	$query = $smcFunc['db_query']('', '
		SELECT id_task FROM {db_prefix}scheduled_tasks WHERE task = "forumfirewall"
	');

	if ($smcFunc['db_num_rows']($query) == 0)
		$smcFunc['db_query']('', '
			INSERT INTO {db_prefix}scheduled_tasks (id_task, next_time, time_offset, time_regularity, time_unit, disabled, task)
			VALUES (NULL, 0, 0, 1, "d", 0, "forumfirewall")'
		);

	$query = $smcFunc['db_query']('', '
		SELECT id_task FROM {db_prefix}scheduled_tasks WHERE task = "scnforumfirewall"
	');

	if ($smcFunc['db_num_rows']($query) == 0)
		$smcFunc['db_query']('', '
			INSERT INTO {db_prefix}scheduled_tasks (id_task, next_time, time_offset, time_regularity, time_unit, disabled, task)
			VALUES (NULL, 0, 0, 1, "w", 0, "scnforumfirewall")'
		);

	$query = $smcFunc['db_query']('', '
		SELECT id_task FROM {db_prefix}scheduled_tasks WHERE task = "prgforumfirewall"
	');

	if ($smcFunc['db_num_rows']($query) == 0)
		$smcFunc['db_query']('', '
			INSERT INTO {db_prefix}scheduled_tasks (id_task, next_time, time_offset, time_regularity, time_unit, disabled, task)
			VALUES (NULL, 0, 0, 1, "d", 0, "prgforumfirewall")'
		);

	// add 2.0 mod settings
		$smcFunc['db_insert']('ignore',
			$db_prefix . 'settings',
				array('variable' => 'string', 'value' => 'string',
				),
				array(
					array('forumfirewall_enable', '0'),
					array('forumfirewall_enable_block', '0'),
					array('forumfirewall_logging', '1'),
					array('forumfirewall_cache_duration', '20'),
					array('forumfirewall_salt', $rand_salt),
					array('forumfirewall_enable_email', '0'),
					array('forumfirewall_enable_ua', '0'),
					array('forumfirewall_enable_dos', '0'),
					array('forumfirewall_good_ua', ''),
					array('forumfirewall_trigger', '.65'),
					array('forumfirewall_longterm_ban', '2'),
					array('forumfirewall_enable_check_ip', '0'),
					array('forumfirewall_enable_proxy', '0'),
					array('forumfirewall_enable_admin', '0'),
					array('forumfirewall_admin_ip_lo', $your_ip),
					array('forumfirewall_admin_ip_hi', $your_ip),
					array('forumfirewall_admin_domain', $your_host),
					array('forumfirewall_enable_robots', '0'),
					array('forumfirewall_test_robots', $test_robots),
					array('forumfirewall_robotstxt_action', (empty($robotstxt_action)?'':$robotstxt_action)),
					array('forumfirewall_enable_rmtport', '0'),
					array('forumfirewall_enable_svrport', '0'),
					array('forumfirewall_good_ser_ports', $your_domain_port),
					array('forumfirewall_enable_inj', '0'),
					array('forumfirewall_uri_chars', $permitted_uri_chars),
					array('forumfirewall_exploits', $injection_list),
					array('forumfirewall_enable_xxs', '0'),
					array('forumfirewall_xxs', $xss_events),
					array('forumfirewall_enable_header', '0'),
					array('forumfirewall_referer_attack', $referer_attacks),
					array('forumfirewall_ua_attack', $ua_attacks),
					array('forumfirewall_entity_attack', $enity_attacks),
					array('forumfirewall_enable_country', '0'),
					array('forumfirewall_in_geoip', '0'),
					array('forumfirewall_country_id', 'Cf-Ipcountry'),
					array('forumfirewall_bad_countries', $bad_countries),
					array('forumfirewall_real_ip', 'HTTP_CF_CONNECTING_IP'),
					array('forumfirewall_enable_bypass', '0'),
					array('forumfirewall_header_id', 'Cf-Connecting-Ip'),
					array('forumfirewall_domain', $your_domain_name),
					array('forumfirewall_ip', $your_domain_ip),
					array('forumfirewall_timelimit', '7'),
				),
				array('variable')
			);

	//  check for old database
	$old_table_exists = $smcFunc['db_list_tables'](false, $db_prefix . 'log_forumfirewall');

	//  add new 2.0 database
	if (empty($old_table_exists)) {
		$smcFunc['db_create_table']($db_prefix.'log_forumfirewall',
			array(
				array(
					'name' => 'id',
					'type' => 'int',
					'size' => 11,
					'null' => false,
					'default' => '',
					'auto' => true,
					'unsigned' => true,
				),
				array(
					'name' => 'ip',
					'type' => 'varchar',
					'size' => 16,
					'null' => false,
					'default' => '',
					'auto' => false,
					'unsigned' => false,
				),
				array(
					'name' => 'date',
					'type' => 'varchar',
					'size' => 19,
					'null' => false,
					'default' => '0000-00-00 00:00:00',
					'auto' => false,
					'unsigned' => false,
				),
				array(
					'name' => 'http_headers',
					'type' => 'text',
					'size' => '',
					'null' => false,
					'auto' => false,
					'unsigned' => false,
				),
				array(
					'name' => 'result',
					'type' => 'varchar',
					'size' => 255,
					'null' => false,
					'default' => '',
					'auto' => false,
					'unsigned' => false,
				),
			),
			array( 
				array(
					'type' => 'primary',
					'columns' => array('id')
				),
				array(
					'type' => 'index',
					'columns' => array('ip'),
					'size' => 15,
				),
			),
			'ignore'
		);
	} else {  //  Upgrade from old version
		if (isset($smcFunc['db_change_column'])) {
			// Change headers
			$smcFunc['db_change_column']($db_prefix . 'log_forumfirewall', 'http_headers',
				array(
					'name' => 'http_headers',
					'type' => 'text',
				),
				array(
					'no_prefix' => true,
				)
			);
			// Second time to make sure
			$smcFunc['db_change_column']($db_prefix . 'log_forumfirewall', 'http_headers',
				array(
					'name' => 'http_headers',
					'type' => 'text',
				),
				array(
					'no_prefix' => true,
				)
			);
			// Change date
			$smcFunc['db_change_column']($db_prefix . 'log_forumfirewall', 'date',
				array(
					'name' => 'date',
					'size' => 19,
				),
				array(
					'no_prefix' => true,
				)
			);

	}	}
} else {
	$lastRun = '';
	$lastRun = time();

	if ((isset($modSettings['forumfirewall_goodgroup']))) {
	db_query("DELETE FROM {$db_prefix}settings 
            WHERE variable = 'forumfirewall_goodgroup'", __FILE__, __LINE__);
	}

	// add mod settings
	db_query("INSERT IGNORE INTO
		{$db_prefix}settings
			(variable, value)
		VALUES	('forumfirewall_enable', '0'),
				('forumfirewall_enable_block', '0'),
				('forumfirewall_logging', '1'),
				('forumfirewall_cache_duration', '20'),
				('forumfirewall_salt', '$rand_salt'),
				('forumfirewall_enable_email', '0'),
				('forumfirewall_enable_ua', '0'),
				('forumfirewall_enable_dos', '0'),
				('forumfirewall_good_ua', ''),
				('forumfirewall_trigger', '.65'),
				('forumfirewall_longterm_ban', '2'),
				('forumfirewall_enable_check_ip', '0'),
				('forumfirewall_enable_proxy', '0'),
				('forumfirewall_enable_admin', '0'),
				('forumfirewall_admin_ip_lo', '$your_ip'),
				('forumfirewall_admin_ip_hi', '$your_ip'),
				('forumfirewall_admin_domain', '$your_host'),
				('forumfirewall_enable_robots', '0'),
				('forumfirewall_test_robots', '$test_robots'),
				('forumfirewall_robotstxt_action', '$robotstxt_action'),
				('forumfirewall_enable_rmtport', '0'),
				('forumfirewall_enable_svrport', '0'),
				('forumfirewall_good_ser_ports', '$your_domain_port'),
				('forumfirewall_enable_inj', '0'),
				('forumfirewall_uri_chars', '$permitted_uri_chars'),
				('forumfirewall_exploits', '$injection_list'),
				('forumfirewall_enable_xxs', '0'),
				('forumfirewall_xxs', '$xss_events'),
				('forumfirewall_enable_header', '0'),
				('forumfirewall_referer_attack', '$referer_attacks'),
				('forumfirewall_ua_attack', '$ua_attacks'),
				('forumfirewall_entity_attack', '$enity_attacks'),
				('forumfirewall_enable_country', '0'),
				('forumfirewall_in_geoip', '0'),
				('forumfirewall_country_id', 'Cf-Ipcountry'),
				('forumfirewall_bad_countries', '$bad_countries'),
				('forumfirewall_real_ip', 'HTTP_CF_CONNECTING_IP'),
				('forumfirewall_enable_bypass', '0'),
				('forumfirewall_header_id', 'Cf-Connecting-Ip'),
				('forumfirewall_domain', '$your_domain_name'),
				('forumfirewall_ip', '$your_domain_ip'),
				('forumfirewall_lastRun', '$lastRun')
			", __FILE__, __LINE__);

//  check for old database
$query_old_table = db_query("SHOW TABLES 
	LIKE '{$db_prefix}log_forumfirewall'
	",__FILE__,__LINE__);

$old_table_exists = mysql_num_rows($query_old_table);
mysql_free_result($query_old_table);

//  add new database
if (!$old_table_exists) {
	db_query("CREATE TABLE IF NOT EXISTS
		{$db_prefix}log_forumfirewall (
		`id` INT(11) NOT NULL auto_increment,
		`ip` varchar(16) NOT NULL,
		`date` varchar(19) NOT NULL default '0000-00-00 00:00:00',
		`http_headers` text NOT NULL,
		`result` varchar(255) NOT NULL default '',
		INDEX (`ip`(15)),
		PRIMARY KEY (`id`)
	)", __FILE__, __LINE__);
	} else {  //  Upgrade from old beta version
		// Change headers
		db_query("ALTER TABLE
			{$db_prefix}log_forumfirewall
			CHANGE COLUMN `http_headers` `http_headers` text NOT NULL default ''
			", __FILE__, __LINE__);
		// Second time to make sure
		db_query("ALTER TABLE
			{$db_prefix}log_forumfirewall
			CHANGE COLUMN `http_headers` `http_headers` text NOT NULL default ''
			", __FILE__, __LINE__);
		// Change date
		db_query("ALTER TABLE
			{$db_prefix}log_forumfirewall
			CHANGE COLUMN `date` `date` varchar(19) NOT NULL default '0000-00-00 00:00:00'
			", __FILE__, __LINE__);
	}
}
//  Try to make ffcache directory writable
if (function_exists('chmod')) {
	@chmod($boarddir.'/ffcache', 0755);

	if (substr(__FILE__, 1, 2) != ':\\') {  //  Linux
		if (!is_writable($boarddir.'/ffcache') && !@chmod($boarddir.'/ffcache', 0755))
				@chmod($boarddir.'/ffcache', 0777);
	} else {   //  Windows
		@chmod($boarddir.'/ffcache', 0777);
		@chmod($boarddir.'/ffcache/index.php', 0777);
		@chmod($boarddir.'/ffcache/.htaccess', 0777);
}	}

function forumfirewall_install_gen_salty() {
	$random_chars = $x = '';
	$characters = array(
'A','B','C','D','^','&','E','s', 't', 'u', 'v','L','M','N','P','Q','W','X','Y','Z','7','8','9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h','j', 'k', 'm', 'n', 'p', 'q', 'r', 'w', 'x', 'y', 'z','@','1','R','S','T','U','V','2','3','4','5','6', '!', '(', ')','#','F','G','H','J','K','$','%','*',);
	$keys = array();

	mt_srand(forumfirewall_install_make_seedy());
	while(count($keys) < 4) {
	    $x = mt_rand(0, count($characters)-1);
	    if(!in_array($x, $keys)) {
	      $keys[] = $x;
	}	}

	foreach($keys as $key) {
	   $random_chars .= $characters[$key]; }
	unset($characters, $key, $keys);
	return $random_chars;
}
function forumfirewall_install_make_seedy() {
  list($usec, $sec) = explode(' ', microtime());
  return (float) $sec + ((float) $usec * 100000);
}

//  Thank you sphider-1.3.5 Ando Saabas 2005-2007
function forumfirewall_install_check_robot_txt($forumfirewall_install_url) {

	$forumfirewall_install_url = 'http://'.$forumfirewall_install_url."/robots.txt";
	$forumfirewall_url_status = forumfirewall_install_url_status($forumfirewall_install_url);

	if ($forumfirewall_url_status['state'] == "ok") {
		$robot = file($forumfirewall_install_url);
		if (!$robot) {
			$contents = forumfirewall_install_getFileContents($forumfirewall_install_url);
			$file = $contents['file'];
			$robot = explode("\n", $file);
		}

		/* Init permissions hash */
		$permissionHash = array();
		
		/* Init current agent */
		$currentAgent = $results = '';
		
		/* Iterate over each line in robots file. */
		foreach ($robot as $line) {
			/**
			 * If the user agent is initialized, and it's not * or our
			 * user agent then we'll ignore it.
			 */
			if(!($currentAgent === '' || $currentAgent === '*')) {	
					continue;
			}
			
			/* Ignore any commented lines. */
			if(strpos(trim($line), '#') === 0) {
				continue;
			} else {
				/* Check for embedded comments, throw them out as well. */
				$commentSeparationArray = array();
				$commentSeparationArray = explode('#', $line);
				$line = $commentSeparationArray[0];
			}
			
			/* Extract key answer pair from each line. */
			@list($key, $answr) = explode(':', $line);

			/* If we have a user agent line, then we can change the current agent. */
			$pos = strpos(strtolower($key), 'user-agent');
			if ($pos !== false) {
				$pos = strpos(strtolower($answr), '*');
				if ($pos !== false) {
					$currentAgent ='*';
				} else {
					$currentAgent =trim($answr);
					$permissionHash[$currentAgent]['disallow'] = array(); }
			/* If we have a disallow directive, push it onto permission hash. */
			} else if (strtolower($key) == 'disallow') {
				if(trim($answr) != '')
					$permissionHash[$currentAgent]['disallow'][] = trim($answr);
			}
		}

		unset($line);
		/**
		 *	Put together action array.
		 */

		foreach ($permissionHash['*']['disallow'] as $permissionHashs) {
			$count = 0;
			if (preg_match("/action=*([a-z 0-9]+) */", $permissionHashs, $regs))
				$results .= $regs[$count] . '|';
			$count = $count + 1;
			}
		unset($permissionHash, $permissionHashs, $regs);
		$results = substr($results, 0, -1);

		
		/* Return the disallows */
		return $results;
	}
}


/*
check if file is available and in readable form
*/
function forumfirewall_install_url_status($forumfirewall_install_url) {
	global $index_pdf, $index_doc, $index_xls, $index_ppt;
	$urlparts = parse_url($forumfirewall_install_url);
	$path = $urlparts['path'];
	$host = $urlparts['host'];
	if (isset($urlparts['query']))
		$path .= "?".$urlparts['query'];

	if (isset ($urlparts['port'])) {
		$port = (int) $urlparts['port'];
	} else
		if ($urlparts['scheme'] == "http") {
			$port = 80;
		} else
			if ($urlparts['scheme'] == "https") {
				$port = 443;
			}

	if ($port == 80) {
		$portq = "";
	} else {
		$portq = ":$port";
	}

	$all = "*/*"; //just to prevent "comment effect" in get accept
	$request = "HEAD $path HTTP/1.1\r\nHost: $host$portq\r\nAccept: $all\r\nUser-Agent: *\r\n\r\n";

	if (substr($forumfirewall_install_url, 0, 5) == "https") {
		$target = "ssl://".$host;
	} else {
		$target = $host;
	}

	$fsocket_timeout = 30;
	$errno = 0;
	$errstr = "";
	$fp = @fsockopen($target, $port, $errno, $errstr, $fsocket_timeout);
	$linkstate = "ok";
	if (!$fp) {
		$status['state'] = "NOHOST";
		return $status;
	} else {
		socket_set_timeout($fp, 30);
		fputs($fp, $request);
		$answer = fgets($fp, 4096);
		$regs = Array ();
		if (preg_match("#HTTP/[0-9.]+ (([0-9])[0-9]{2})#", $answer, $regs)) {
			$httpcode = $regs[2];
			$full_httpcode = $regs[1];

			if ($httpcode <> 2 && $httpcode <> 3) {
				$status['state'] = "Unreachable: http $full_httpcode";
				$linkstate = "Unreachable";
			}
		}

		if ($linkstate <> "Unreachable") {
			while ($answer) {
				$answer = fgets($fp, 4096);

				if (preg_match("/Location: *([^\n\r ]+)/", $answer, $regs) && $httpcode == 3 && $full_httpcode != 302) {
					$status['path'] = $regs[1];
					$status['state'] = "Relocation: http $full_httpcode";
					fclose($fp);
					return $status;
				}

				if (preg_match("/Last-Modified: *([a-z0-9,: ]+)/i", $answer, $regs)) {
					$status['date'] = $regs[1];
				}

				if (preg_match("/Content-Type:/i", $answer)) {
					$content = $answer;
					$answer = '';
					break;
				}
			}
			$socket_status = socket_get_status($fp);
			if (preg_match("/Content-Type: *([a-z\/.-]*)/i", $content, $regs)) {
				if ($regs[1] == 'text/html' || $regs[1] == 'text/' || $regs[1] == 'text/plain') {
					$status['content'] = 'text';
					$status['state'] = 'ok';
				} else if ($regs[1] == 'application/pdf' && $index_pdf == 1) {
					$status['content'] = 'pdf';
					$status['state'] = 'ok';                                 
				} else if (($regs[1] == 'application/msword' || $regs[1] == 'application/vnd.ms-word') && $index_doc == 1) {
					$status['content'] = 'doc';
					$status['state'] = 'ok';
				} else if (($regs[1] == 'application/excel' || $regs[1] == 'application/vnd.ms-excel') && $index_xls == 1) {
					$status['content'] = 'xls';
					$status['state'] = 'ok';
				} else if (($regs[1] == 'application/mspowerpoint' || $regs[1] == 'application/vnd.ms-powerpoint') && $index_ppt == 1) {
					$status['content'] = 'ppt';
					$status['state'] = 'ok';
				} else {
					$status['state'] = "Not text or html";
				}

			} else
				if ($socket_status['timed_out'] == 1) {
					$status['state'] = "Timed out (no reply from server)";

				} else
					$status['state'] = "Not text or html";

		}
	}
	fclose($fp);
	return $status;
}
function forumfirewall_install_getFileContents($forumfirewall_install_url) {
	$urlparts = parse_url($forumfirewall_install_url);
	$path = $urlparts['path'];
	$host = $urlparts['host'];
	if ($urlparts['query'] != "")
		$path .= "?".$urlparts['query'];
	if (isset ($urlparts['port'])) {
		$port = (int) $urlparts['port'];
	} else
		if ($urlparts['scheme'] == "http") {
			$port = 80;
		} else
			if ($urlparts['scheme'] == "https") {
				$port = 443;
			}

	if ($port == 80) {
		$portq = "";
	} else {
		$portq = ":$port";
	}

	$all = "*/*";

	$request = "GET $path HTTP/1.0\r\nHost: $host$portq\r\nAccept: $all\r\nUser-Agent: *\r\n\r\n";

	$fsocket_timeout = 30;
	if (substr($forumfirewall_install_url, 0, 5) == "https") {
		$target = "ssl://".$host;
	} else {
		$target = $host;
	}


	$errno = 0;
	$errstr = "";
	$fp = @fsockopen($target, $port, $errno, $errstr, $fsocket_timeout);

	if (!$fp) {
		$contents['state'] = "NOHOST";
		return $contents;
	} else {
		if (!fputs($fp, $request)) {
			$contents['state'] = "Cannot send request";
			return $contents;
		}
		$data = null;
		socket_set_timeout($fp, $fsocket_timeout);
		do{
			$status = socket_get_status($fp);
			$data .= fgets($fp, 8192);
		} while (!feof($fp) && !$status['timed_out']) ;

		fclose($fp);
		if ($status['timed_out'] == 1) {
			$contents['state'] = "timeout";
		} else
			$contents['state'] = "ok";
		$contents['file'] = substr($data, strpos($data, "\r\n\r\n") + 4);
	}
	return $contents;
}

?>