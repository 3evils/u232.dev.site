[b]Nombre[/b]: ForumFirewall
[b]Versión[/b]: 1.1.4
[b]Probado con[/b]: SMF 2.0
[b]Autor[/b]: J.Miller a/k/a butchs
[b]Web[/b]: [url=http://www.ECRTcc.com]East Coast Rolling Thunder car club[/url]
[b]EMail[/b]: [email]J.Miller@POBox.com[/email]

[hr]
Bienvenido a Forum Firewall.  El modulo Firewall escrito para SMF 2.0.

Forum Firewall ofrece 13 an�lisis para la gesti�n avanzada del foro, que lo protegen contra los intentos de hacking (pirateo). Forum Firewall es un complemento a las herramientas anti-hacking existentes  y no debe ser la �nica medida de protecci�n.

Un esquema de protecci�n ideal es el siguiente:
[list type=decimal]
[li]Proxy Firewall.[/li]
[li]Protecci�n .htaccess para el bloqueo de direcciones ip maliciosas, CrawlProtect y GeoIP.[/li]
[li]Mod Forum Firewall.[/li]
[li]Mod Bad Behavior.[/li]
[li]Stop Spammer.[/li]
[/list]
Esta protecci�n podr�a no detener a un atacante determinado, pero por lo general les llevara a buscar objetivos mas f�ciles.

[hr]
Una vez visto lo anterior, permitamos hablar ahora sobre el mod Forum Firewall. Las caracter�sticas de esta versi�n son las siguientes:
[list]
[li]Compatible con CloudFlare y otros Proxys.[/li]
[li]Comprueba el estado de register globals y magic quotes.[/li]
[li]Acepta registros o bloquea infracciones.[/li]
[li]Detecta y autom�ticamente descodifica utf8 para su examen.[/li]
[li]Protege contra pirateo cookie administrador.[/li]
[li]Protege contra suplantaci�n ip administrador.[/li]
[li]Enviar un correo electr�nico al administrador nunca, en intentos DOS o por cada infracci�n.[/li]
[li]Cifrado de cacha incorporado. Se recomienda utilizar esta funci�n ya que Forum Firewall utiliza la cacha para determinar si se trata de una infracci�n DOS. El m�nimo definido es de 20 segundos.[/li]
[li]Protecci�n DOS. Observa User-Agent y si esta  bloqueado no se le permitir el acceso.  Ademas, hay una funci�n donde se observa a que velocidad (hits por segundo) el visitante rastrea el sitio y lo compara con una lista para despu�s prohibir o marcar al visitante en funci�n de esta configuraci�n. Incluye la posibilidad de prohibir (ban) usando el sistema de prohibiciones de SMF.[/li]
[li]Validaci�n de direcciones IP - Comprueba todas las direcciones ip en la lista IP Proxy de visitantes.[/li]
[li]Protecci�n Cross Site Scripting. El Mod observa las cookies de usuarios entrantes y confirma que no est�n infectadas. Ademas hay un an�lisis autom�tico en Tareas Programadas que inspecciona los archivos de im�genes adjuntas, iconos gestuales (smilies) y carpetas de imagen de la plantilla una vez por semana para comprobar que no haya infecciones. Esta ultima caracter�stica proporciona un mensaje de advertencia.
Si tiene infecciones las posibilidades de haberse extendido son mayores de lo que piensa y los archivos php podr�an estar infectados.[/li]
[li]Inyecci�n SQL - Todos los URI son inspeccionados para detectar signos de caracteres uri no permitidos e intentos de inyecci�n SQL. Si encuentra uno, habr� una notificaci�n.[/li]
[li]Protecci�n contra ataques HTTP Header.[/li]
[li]Protecci�n contra Suplantaci�n de Puerto.[/li]
[li]C�digos de Pa�s - Esta funci�n es limitada. Funcionará con servidores basados en GeoIP y CloudFlare.[/li]
[li]Interfaz Proxy - Comprobará la direcci�n ip de los visitantes con la configuraci�n del proxy para evitar intentos bypass. Por favor tenga en cuenta que actualmente esto solo funciona con una direcci�n ip est�tica.[/li]
[/list]
[hr]

Saludos (translated by papones)