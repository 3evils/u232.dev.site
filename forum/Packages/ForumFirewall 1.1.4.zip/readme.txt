[b]Name[/b]: ForumFirewall
[b]Version[/b]: 1.1.4
[b]Tested with[/b]: SMF 1.1.14 & SMF 2.0 Gold
[b]Author[/b]: J.Miller a/k/a butchs
[b]Website[/b]: [url=http://www.ECRTcc.com]East Coast Rolling Thunder car club[/url]
[b]EMail[/b]: [email]J.Miller@POBox.com[/email]

[hr]
Welcome to Forum Firewall.  The Firewall package written for SMF 2.0 RC5.

Forum Firewall offers 13 tests for the advanced forum operator that protect against hacking attempts.  Forum Firewall is written as a supplement to existing anti hacking methods and should not be the only line of protection.  An ideal protection scheme is as follows:
[list type=decimal]
[li]Proxy Firewall.[/li]
[li]Htaccess protection such as blocking nasty ip addresses, CrawlProtect and GeoIP.[/li]
[li]Forum Firewall mod.[/li]
[li]Bad Behavior mod.[/li]
[li]Project Honeypot.[/li]
[li]Stop Spammer.[/li]
[/list]

The above protection will not stop a determined hacker but it just may send them looking for easier targets.

[hr]

Now that we have all that behind us lets talk about the Forum Firewall mod.  The features in this version are as follows:
[list]
[li]Compatible with CloudFlare and other Proxys.[/li]
[li]Checks the status of register globals & magic quotes.[/li]
[li]Either logs or blocks violations.[/li]
[li]Detects and automatically decodes utf8 for testing.[/li]
[li]Protects against admin cookie hacking.[/li]
[li]Protects against admin ip spoofing.[/li]
[li]Will send an email to the admin never, on DOS attempt or every violation.[/li]
[li]Built in encrypted cache. It is recommended that you you this feature since it uses the cache to determine if there is a DOS violation. Minimum set point is 20 seconds.[/li]
[li]DOS Protection. Looks at the UA and if it is blocked it will not allow access.  Plus there is a feature where it looks at the rate (hits per second) that the visitor hits the site and compares it against a whitelist and then bans or flags the visitor based on the settings.  Includes the ability to ban through the SMF banning system.[/li]
[li]IP address validation - Checks all the IP addresses in the visitors IP proxy list.[/li]
[li]Cross Site Scripting Protection. The mod looks at incoming visitors cookies and confirms that they are not infected. Plus there is an automatic scan in Scheduled Tasks that inspects you image files in the attachments, smilies and theme image folders once a week for infections. The latter feature will only give you a warning message. This is because if you have an infections chances are that it is greater than you think and the php files are infected.[/li]
[li]SQL Injection - All uri's are inspected for disallowed URI characters and signs of sql injection attempts. If one is found there will be a notification.[/li]
[li]HTTP Header Attack Protection.[/li]
[li]Port Spoofing Protection.[/li]
[li]Country Codes - This feature is limited. It will work with server based GeoIP and CloudFlare.[/li]
[li]Proxy Interface - Will correct the visitors ip address against the proxy settings and there is a setting for bypass prevention. Please note that at this time this will only work with a static ip address.[/li]
[/list]
[hr]

[b]Current download version index:[/b]
[list]
[li]1.0 - initial release October 24, 2010, SMF approval revision January 08, 2011.[/li]
[li]1.0.1 - January 16, 2011 - Fixed sorting issue with permissions.  Improved DNS check.[/li]
[li]1.0.2 - January 22, 2011 - Added some suggestions by Arantor & PhobosK.  Fixed Undefined variable: result & forumfirewall_data found by busterone.[/li]
[li]1.0.3 - January 23, 2011 - Fixed typo.[/li]
[li]1.0.4 - January 25, 2011 - Improved obfuscation. Fixed Undefined index: referer found by Blade_Runner.[/li]
[li]1.0.5 - February 13, 2011 - SMF 2.0 RC5 and 1.1.13 upgrade.  Bug fixes reported by BigGuy and DarkBlizz.[/li]
[li]1.0.6 - February 19, 2011 - Bug fixes and added "Review Proxy List" option and visitor ip address in email notification.[/li]
[li]1.0.7 - February 20, 2011 - Bug fix found by Lou.[/li]
[li]1.0.8 - February 27, 2011 - Minor improvements.[/li]
[li]1.0.9 - April 08, 2011 - Added more error descriptions.  Improved SMF 1.1.x language handling.  Fixed referrer error.  Improved cache setup. Spanish Translation - thanks xaquin.[/li]
[li]1.0.10 - April 10, 2011 - Changes for mod_security compatibility - thanks Darkness*[/li]
[li]1.1.0 - June 12, 2011 - Improved warning page honeypot[/li]
[li]1.1.1 - June 26, 2011 - Cannot redeclare (MattH41), Can't have a default valueFile (evanoliver), Banned will not function unless blocking is enabled[/li]
[li]1.1.2 - July 16, 2011 - Corrected Permanent bans thanks digit.  Improved whitelist, added ddos test, portuguese + brazilian translations - thanks Darkness_Black, spanish translation additions - thanks xaquin.  New test.[/li]
[li]1.1.3 - July 17, 2011 - Random DB not exist error workaround (SMF 2.0 Bug 0002196), Corrected portuguese + brazilian translations - thanks Darkness_Black.[/li]
[li]1.1.4 - August 21, 2011 - Whitelist bugs fixed, new goos bot added, possible cloudflare error avoided, modification.english-utf8 added.[/li]
[/list]

[hr]

[center][b]Terms of use[/b][/center]
[hr]
By downloading and/or using this MOD you agree to adhere to the following conditions for all versions of the  Forum Firewall MOD:
[list]
[li]Copyright info & link must remain intact!  They only can be removed via Author/Creators approval.[/li]
[li]The Author/Creator is not responsible for any incompatibilities of this mod with your forum.[/li]
[li]You are FREE to use and customize this MOD on your Forum(s) as per the conditions of these terms however, in no way can the Author/Creator of this MOD be held responsible under any circumstances.[/li]
[li]Commercial resale of this mod is prohibited without express written permission from the Author/Creator.[/li]
[li]You are FREE to redistribute this MOD in its original, released state ONLY![/li]
[li]These terms can be changed or appended at any time by the Author/Creator without any prior notice.[/li]
[/list]