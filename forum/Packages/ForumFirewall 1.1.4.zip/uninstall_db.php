<?php
/**********************************************************************************
* uninstall_db.php - PHP template to delete the scheduled task
* Version 1.0.2 by JMiller a/k/a butchs
* (http://www.eastcoastrollingthunder.com) 
*********************************************************************************
* This program is distributed in the hope that it is and will be useful, but
* WITHOUT ANY WARRANTIES; without even any implied warranty of MERCHANTABILITY
* or FITNESS FOR A PARTICULAR PURPOSE.
**********************************************************************************/

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')) {
	require_once(dirname(__FILE__) . '/SSI.php'); }

// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF')) die('<b>Error:</b> Cannot uninstall - please verify you put this in the same place as SMF\'s index.php.');

global $user_info, $db_prefix;

if ((SMF == 'SSI') && !$user_info['is_admin']) die('Admin priveleges required.');

if(isset($smcFunc)) {
	global $smcFunc;

	//  Delete Scheduled Tasks
	$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}scheduled_tasks WHERE task = "forumfirewall"
	');

	$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}scheduled_tasks WHERE task = "scnforumfirewall"
	');

	$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}scheduled_tasks WHERE task = "prgforumfirewall"
	');
	// Force mod off
	$smcFunc['db_insert']('replace',
		$db_prefix . 'settings',
			array('variable' => 'string', 'value' => 'string',
			),
			array(
				array('forumfirewall_enable', '0'),
			),
			array('variable')
		);

} else {
	// Force mod off
	db_query("REPLACE INTO
		{$db_prefix}settings
		(variable, value)
		VALUES	('forumfirewall_enable', '0')
			", __FILE__, __LINE__);
}

?>