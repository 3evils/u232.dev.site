[b]Name[/b]: ForumFirewall
[b]Version[/b]: 1.1.4
[b]Tested with[/b]: SMF 1.1.13 & SMF 2.0
[b]Author[/b]: J.Miller a/k/a butchs
[b]Website[/b]: [url=http://www.ECRTcc.com]East Coast Rolling Thunder car club[/url]
[b]EMail[/b]: [email]J.Miller@POBox.com[/email]

[hr]
Welcome to Forum Firewall.  The Firewall package written for SMF 2.0 RC5.

Forum Firewall offers 13 tests for the advanced forum operator that protect against hacking attempts.  Forum Firewall is written as a supplement to existing anti hacking methods and should not be the only line of protection.  An ideal protection scheme is as follows:
[list type=decimal]
[li]Proxy Firewall.[/li]
[li]Htaccess protection such as blocking nasty ip addresses, CrawlProtect and GeoIP.[/li]
[li]Forum Firewall mod.[/li]
[li]Bad Behavior mod.[/li]
[li]Project Honeypot.[/li]
[li]Stop Spammer.[/li]
[/list]

The above protection will not stop a determined hacker but it just may send them looking for easier targets.

[hr]

Now that we have all that behind us lets talk about the Forum Firewall mod.  The features in this version are as follows:
[list]
[li]Compatible with CloudFlare and other Proxys.[/li]
[li]Checks the status of register globals & magic quotes.[/li]
[li]Either logs or blocks violations.[/li]
[li]Detects and automatically decodes utf8 for testing.[/li]
[li]Protects against admin cookie hacking.[/li]
[li]Protects against admin ip spoofing.[/li]
[li]Will send an email to the admin never, on DOS attempt or every violation.[/li]
[li]Built in encrypted cache. It is recommended that you you this feature since it uses the cache to determine if there is a DOS violation. Minimum set point is 20 seconds.[/li]
[li]DOS Protection. Looks at the UA and if it is blocked it will not allow access.  Plus there is a feature where it looks at the rate (hits per second) that the visitor hits the site and compares it against a whitelist and then bans or flags the visitor based on the settings.  Includes the ability to ban through the SMF banning system.[/li]
[li]IP address validation - Checks all the IP addresses in the visitors IP proxy list.[/li]
[li]Cross Site Scripting Protection. The mod looks at incoming visitors cookies and confirms that they are not infected. Plus there is an automatic scan in Scheduled Tasks that inspects you image files in the attachments, smilies and theme image folders once a week for infections. The latter feature will only give you a warning message. This is because if you have an infections chances are that it is greater than you think and the php files are infected.[/li]
[li]SQL Injection - All uri's are inspected for disallowed URI characters and signs of sql injection attempts. If one is found there will be a notification.[/li]
[li]HTTP Header Attack Protection.[/li]
[li]Port Spoofing Protection.[/li]
[li]Country Codes - This feature is limited. It will work with server based GeoIP and CloudFlare.[/li]
[li]Proxy Interface - Will correct the visitors ip address against the proxy settings and there is a setting for bypass prevention. Please note that at this time this will only work with a static ip address.[/li]
[/list]
[hr]

[b]Current download version index:[/b]
[list]
[li]1.0 - initial release October 24, 2010, SMF approval revision January 08, 2011.[/li]
[li]1.0.1 - January 16, 2011 - Fixed sorting issue with permissions.  Improved DNS check.[/li]
[li]1.0.2 - January 22, 2011 - Added some suggestions by Arantor & PhobosK.  Fixed Undefined variable: result & forumfirewall_data found by busterone.[/li]
[li]1.0.3 - January 23, 2011 - Fixed typo.[/li]
[li]1.0.4 - January 25, 2011 - Improved obfuscation. Fixed Undefined index: referer found by Blade_Runner.[/li]
[li]1.0.5 - February 13, 2011 - SMF 2.0 RC5 and 1.1.13 upgrade.  Bug fixes reported by BigGuy and DarkBlizz.[/li]
[li]1.0.6 - February 19, 2011 - Bug fixes and added "Review Proxy List" option and visitor ip address in email notification.[/li]
[li]1.0.7 - February 20, 2011 - Bug fix found by Lou.[/li]
[li]1.0.8 - February 27, 2011 - Minor improvements.[/li]
[li]1.0.9 - April 08, 2011 - Added more error descriptions.  Improved SMF 1.1.x language handling.  Fixed referrer error.  Improved cache setup. Spanish Translation - thanks xaquin.[/li]
[li]1.0.10 - April 10, 2011 - Changes for mod_security compatibility - thanks Darkness*[/li]
[li]1.1.0 - June 12, 2011 - Improved warning page honeypot[/li]
[li]1.1.1 - June 26, 2011 - Cannot redeclare (MattH41), can't have a default valueFile (evanoliver), Banned will not function unless blocking is enabled[/li]
[li]1.1.2 - July 16, 2011 - Corrected Permanent bans thanks digit.  Improved whitelist, added ddos test, portuguese + brazilian translations - thanks Darkness_Black, spanish translation additions - thanks xaquin.  New test.[/li]
[li]1.1.3 - July 17, 2011 - Corrected portuguese + brazilian translations - thanks Darkness_Black.[/li]
[li]1.1.4 - August 21, 2011 - New goos bot added, possible cloudflare error avoided, modification.english-utf8 added.[/li]

[/list]
[hr]

[center][b]Terms of use[/b][/center]
[hr]
By downloading and/or using this MOD you agree to adhere to the following conditions for all versions of the  Forum Firewall MOD:
[list]
[li]Copyright info & link must remain intact!  They only can be removed via Author/Creators approval.[/li]
[li]The Author/Creator is not responsible for any incompatibilities of this mod with your forum.[/li]
[li]You are FREE to use and customize this MOD on your Forum(s) as per the conditions of these terms however, in no way can the Author/Creator of this MOD be held responsible under any circumstances.[/li]
[li]Commercial resale of this mod is prohibited without express written permission from the Author/Creator.[/li]
[li]You are FREE to redistribute this MOD in its original, released state ONLY![/li]
[li]These terms can be changed or appended at any time by the Author/Creator without any prior notice.[/li]
[/list]

[hr]
[hr]

[b]Nombre[/b]: ForumFirewall
[b]Versión[/b]: 1.0.9
[b]Probado con[/b]: SMF 2.0 RC5
[b]Autor[/b]: J.Miller a/k/a butchs
[b]Web[/b]: [url=http://www.ECRTcc.com]East Coast Rolling Thunder car club[/url]
[b]EMail[/b]: [email]J.Miller@POBox.com[/email]

[hr]
Bienvenido a Forum Firewall.  El módulo Firewall escrito para SMF 2.0 RC5.

Forum Firewall ofrece 13 análisis para la gestión avanzada del foro, que lo protegen contra los intentos de hacking (pirateo). Forum Firewall es un complemento a los métodos anti-hacking existentes  y no debe ser la única línea de protección. Un esquema de protección ideal es el siguiente:
[list type=decimal]
[li]Proxy Firewall.[/li]
[li]Protección .htaccess para el bloqueo de direcciones ip maliciosas, CrawlProtect y GeoIP.[/li]
[li]Mod Forum Firewall.[/li]
[li]Mod Bad Behavior.[/li]
[li]Proyecto Honeypot.[/li]
[li]Stop Spammer.[/li]
[/list]
Esta protección podría no detener a un atacante determinado, pero por lo general les llevará a buscar objetivos más fáciles.

[hr]
Una vez visto lo anterior, permítanos hablar ahora sobre el mod Forum Firewall. Las características de esta versión son las siguientes:
[list]
[li]Compatible con CloudFlare y otros Proxys.[/li]
[li]Comprueba el estado de register globals y magic quotes.[/li]
[li]Acepta registros o bloquea infracciones.[/li]
[li]Detecta y automáticamente descodifica utf8 para su examen.[/li]
[li]Protege contra pirateo cookie administrador.[/li]
[li]Protege contra suplantación ip administrador.[/li]
[li]Enviará un correo electrónico al administrador nunca, en intentos DOS o por cada infracción.[/li]
[li]Cifrado de caché incorporado. Se recomienda utilizar esta función ya que Forum Firewall utiliza la caché para determinar si se trata de una infracción DOS. El mínimo definido es de 20 segundos.[/li]
[li]Protección DOS. Observa User-Agent y si está bloqueado no se le permitirá el acceso.  Además, hay una función donde se observa a que velocidad (hits por segundo) el visitante rastrea el sitio y lo compara con una lista para después prohibir o marcar al visitante en función de esta configuración. Incluye la posibilidad de prohibir (ban) usando el sistema de prohibiciones de SMF.[/li]
[li]Validación de direcciones IP - Comprueba todas las direcciones ip en la lista IP Proxy de visitantes.[/li]
[li]Protección Cross Site Scripting. El Mod observa las cookies de usuarios entrantes y confirma que no estén infectadas. Además hay un análisis automático en Tareas Programadas que inspecciona los archivos de imágenes adjuntas, iconos gestuales (smilies) y carpetas de imagen de la plantilla una vez por semana para comprobar que no haya infecciones. Esta última característica proporciona sólo un mensaje de advertencia. Si tiene infecciones las posibilidades de haberse extendido son mayores de lo que piensa y los archivos php podrían estar infectados.[/li]
[li]Inyección SQL - Todos los URI son inspeccionados para detectar signos de caracteres uri no permitidos e intentos de inyección SQL. Si encuentra uno, habrá una notificación.[/li]
[li]Protección contra ataques HTTP Header.[/li]
[li]Protección contra Suplantación de Puerto.[/li]
[li]Códigos de País - Esta función es limitada. Funcionará con servidores basados en GeoIP y CloudFlare.[/li]
[li]Interfaz Proxy - Comprobará la dirección ip de los visitantes con la configuración del proxy para evitar intentos bypass. Por favor tenga en cuenta que actualmente esto sólo funciona con una dirección ip estática.[/li]
[/list]
[hr]

[center][b]Términos de uso[/b][/center]
[hr]
Al descargar y/o utilizar este MOD usted acepta cumplir los siguientes requisitos para todas las versiones del MOD Forum Firewall:
[list]
[li]Información de Copyright y enlace deben permanecer intactas!  Solamente pueden retirarse con la aprobación del Autor/Creador.[/li]
[li]El Autor/Creador no es responsable de cualquier incompatibilidad de este mod con su foro.[/li]
[li]Es LIBRE de usar y personalizar este MOD en su(s) Foro(s) manteniendo las condiciones de estos términos sin embargo, de ninguna manera el Autor/Creador de este MOD se hace responsable bajo cualquier otra circunstancia.[/li]
[li]La reventa comercial de este mod está prohibida sin un permiso expreso y por escrito del Autor/Creador.[/li]
[li]Es libre de redistribuir este MOD, pero SOLAMENTE en su estado original![/li]
[li]Estos términos pueden ser cambiados o ampliados por el Autor/Creador sin previo aviso.[/li]
[/list]
[hr]
