[center][size=14pt][b]Leet Easter Egg[/b][/size][/center]
[hr]
[table][tr]
[td][b]Author:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=1][b]SMF Customization Team[/b][/url][/td]
[/tr][/table]
[table][tr]
[td][b]Supported Languages:[/b] English[/td]
[/tr][/table]
[table][tr][td]
[url=http://custom.simplemachines.org/mods/index.php?mod=1337][b]Link To Mod[/b][/url] | [url=http://www.simplemachines.org/community/index.php?topic=256480.0][b]Mod Discussion[/b][/url] | [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=1][b]Other SMF Customization Team Mods[/b][/url][/td]
[/tr][/table]
[hr]
[color=blue][b]Summary:[/b][/color]
The popular 'Leet' Easter Egg was removed from SMF 2.x, for when a user reaches 1337 posts.  This mod restores it back for SMF 2.x.

By the same token
If your using SMF 1.1.x, and don't like the Easter Egg, use this mod to REMOVE the easter egg.

So just clarify
SMF 2.x = Restores it
SMF 1.1.x = Removes it

[color=blue][b]Compatibility:[/b][/color]
Compatible with SMF 2.0 and 1.1

[color=blue][b]Installation Information:[/b][/color]
The Package Manager should work in most cases, if you have problems installing please use the discussion thread as well as [url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation of Mods[/url]

[color=blue][b]Change Log:[/b][/color]
[size=8pt][b]Version 1.1 - March 09 2010[/b]
- fixed a bug that was preventing uninstalling the mod.
- added user-friendly message for non tested versions.
[size=8pt][b]Version 1.0 - August 19, 2008[/b]
- Initial release
[/size]