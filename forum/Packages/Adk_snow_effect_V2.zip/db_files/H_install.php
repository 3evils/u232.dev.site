<?php
/********************************************************
* Adk Snow Effect           
* Version: 2.0
* Official support: http://www.smfpersonal.net 
* Author: enik
* Update and Optimization: ^HeRaCLeS^ 
* 2011
/**********************************************************/

	$direct_install = false;

if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')){
	require_once(dirname(__FILE__) . '/SSI.php');
	$direct_install = true;
}
elseif (!defined('SMF'))
	die('Adk Snow Effect no puede conectarse con smf');

//Hooks Integration
$hooks = array(
	'integrate_pre_include' => '$sourcedir/Subs-ADK_Snoweffect.php',
	'integrate_admin_areas' => 'AdminADK_Snoweffect',
	'integrate_load_theme'  =>  'ADK_Snoweffect',
);


//Loading....
foreach($hooks AS $hook => $call)
	add_integration_function($hook,$call);

	if($direct_install)
	echo'Listo... Adk Snow Effect a sido instalado Correctamente. Felicidades!';

?>