[center][size=18pt][font=tahoma][b][color=#006666]Adk Snow Effect 2.0 by[/color][/b][/font][/size][/center]

[center][url=http://www.smfpersonal.net/][img]http://www.allmxcars.com/enik/adk-team.png[/img][/url][/center]

[img]http://www.smfpersonal.net/famfamfam/user.png[/img] [b]Autor/Author:[/b]
     [url=http://www.smfpersonal.net/profiles/enik-u417.html][color=#9A0ABC][b]enik[/b][/color][/url]

[img]http://www.smfpersonal.net/famfamfam/user.png[/img] [b]Actualizaci�n y Optimizaci�n/Update and Optimization:[/b]
     [url=http://www.smfpersonal.net/profiles/heracles-u259.html][color=#9A0ABC][b]^HeRaCLeS^[/b][/color][/url]
     
[img]http://www.smfpersonal.net/famfamfam/page_white_flash.png[/img] [b]Caracter�sticas:[/b]
     Esta aplicaci�n nos permitira poner un efecto de nieve en nuestro sitio.
     [b]Opciones[/b]
          [b]o[/b] Activar/desactivar el mod.
          [b]o[/b] Elegir color de la nieve
          [b]o[/b] Cambiar el dise�o de la nieve.
          [b]o[/b] Cambiar la velocidad de la nieve.
          [b]o[/b] Activar/desactivar la acumulacion de nieve al pie de p�gina.
          [b]o[/b] Activar/desactivar el movimiento de la nieve en direcci�n al mouse.

     Las opciones de este mod se encuentran en: [i]Centro de Administraci�n � Configuraci�n del Foro � Adk Snow Effect[/i]

     Copyright 2011 by SMF Personal @ visita [url=http://www.smfpersonal.net]www.smfpersonal.net[/url] para soporte oficial. 

     Si tu quieres ayudarnos, por favor visita nuestra seccion de contribuciones: [url=http://www.smfpersonal.net/about.html;sa=contritube-spanish]Contribuir[/url]

[hr]
[img]http://www.smfpersonal.net/famfamfam/page_white_flash.png[/img] [b]Features:[/b]
     This application will allow us to make a snow effect on our site.
     [b]Opciones[/b]
          [b]o[/b] Enable/Disable the mod.
          [b]o[/b] Change the color of snow.
          [b]o[/b] Change the design of the snow.
          [b]o[/b] Change the speed of the snow.
          [b]o[/b] Enable/Disable accumulation of snow off the bottom of the page.
          [b]o[/b] Enable/Disable the tracking of the snow in the direction of the mouse.


     The options of this mod are in: [i]Administration Center � Configuration � Adk Snow Effect[/i]

     Copyright 2011 by SMF Personal @ visit [url=http://www.smfpersonal.net]www.smfpersonal.net[/url] for official support. 

     If you want help, please visit our contributions section: [url=http://www.smfpersonal.net/about.html;sa=contribute]Contribute[/url]

[hr]

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Idiomas/Languages:[/b]
     [b]o[/b] English
     [b]o[/b] English-utf8
     [b]o[/b] Spanish_es
     [b]o[/b] Spanish_es-utf8
     [b]o[/b] Spanish_latin
     [b]o[/b] Spanish_latin-utf8

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Compatibilidad/Compatibility:[/b]
     [b]o[/b] SMF 2.0 Gold
     [b]o[/b] SMF 2.0.1

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Desarrollador/Developer:[/b]
     [url=http://www.smfpersonal.net][b]Adk-Team[/b][/url]

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Usando/Using:[/b]
     [url=http://schillmania.com][b]SnowStorm[/b][/url]
