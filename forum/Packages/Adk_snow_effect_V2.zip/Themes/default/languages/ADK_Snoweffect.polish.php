<?php
/********************************************************
* Adk Snow Effect           
* Version: 2.0
* Official support: http://www.smfpersonal.net 
* Author: enik
* Update and Optimization: ^HeRaCLeS^ 
* 2011
* Polish translation by phantom
/**********************************************************/

$txt['TitleAdkTeam'] = base64_decode('TW9kcyBieSA8YSB0YXJnZXQ9Il9ibGFuayIgaHJlZj0iaHR0cDovL3d3dy5zbWZwZXJzb25hbC5uZXQvIj48c3BhbiBzdHlsZT0iY29sb3I6IzAwNjY2NiI+QWRrIFRlYW08L3NwYW4+PC9hPg==');
$txt['Adk_Seffectcode'] = base64_decode('Jm5ic3A7Jm5ic3A7Jm5ic3A7Jm5ic3A7JiM4MjI2OyA8YSB0YXJnZXQ9Il9ibGFuayIgaHJlZj0iaHR0cDovL3d3dy5zbWZwZXJzb25hbC5uZXQvIj48Yj5BZGsgU25vdyBFZmZlY3Q8L2I+PC9hPg==');
$txt['Adkseffect_donate'] = '
	<div style="text-align:center;" class="smalltext">
		Adk efekt �niegu utworzony przez <a href="http://www.smfpersonal.net" target="blank">SMFPersonal</a><br />
		<a href="http://www.smfpersonal.net/about.html;sa=contribute" target="blank">Wesprzyj</a>
	</div>
';
$txt['Adkseffect_name'] = 'Adk efekt �niegu';
$txt['Adkseffect_desc'] = '
	Ta modyfikacja pozwoli doda� efekt �niegu na naszej stronie.
	<br /><b>Opcje:</b>
	<br />��� W��cz/wy��cz modyfikacje.
	<br />��� Zmie� kolor �niegu.
	<br />��� Zmie� wygl�d �niegu.
	<br />��� Zmie� szybko�� �niegu.
	<br />��� W��cz/wy��cz gromadzenie si� �niegu na dole strony.
	<br />��� W��cz/wy��cz �ledzenie myszy przez �nieg.
';
$txt['enable_adk_snow_effect'] = '<strong>W��cz</strong> <strong style="color:red">Adk efekt �niegu</strong>:';
$txt['ADK_SeStick'] = '<strong>Wy��cz gromadzenie �niegu</strong>:';
$txt['ADK_SeMouse'] = '<strong>Wy��cz �ledzenie myszy</strong>:';
$txt['ADK_Secolor'] = '<strong>Zmie� kolor �niegu</strong>:';
$txt['ADK_SeChart'] = '<strong>Zmie� szybko�� �niegu</strong>:';
$txt['ADK_SeVelo'] = '<strong>Zmie� szybko�� �niegu</strong>:';
$txt['ADK_SeVelo_Default'] = 'Domy�lnie';
$txt['ADK_SeVelo_slow'] = 'Wolno';
$txt['ADK_SeVelo_median'] = '�rednio';
$txt['ADK_SeVelo_fast'] = 'Szybko';
$txt['Adk_efChart_Default'] = 'Domy�lny';
$txt['Adk_efChart_bull'] = 'Wz�r: �';
$txt['Adk_efChart_middot'] = 'Wz�r: �';
$txt['Adk_efChart_curren'] = 'Wz�r: �';
$txt['Adk_efChart_times'] = 'Wz�r: �';
$txt['Adk_efChart_ast'] = 'Wz�r: *';
$txt['Adk_efColor_Default'] = 'Domy�lny';
$txt['Adk_efColor_black'] = 'Czarny';
$txt['Adk_efColor_silver'] = 'Szary';
$txt['Adk_efColor_white'] = 'Bia�y';
$txt['Adk_efColor_yellow'] = '��ty';
$txt['Adk_efColor_orange'] = 'Pomara�czowy';
$txt['Adk_efColor_red'] = 'Czerwony';
$txt['Adk_efColor_pink'] = 'R�owy';
$txt['Adk_efColor_purple'] = 'Fioletowy';
$txt['Adk_efColor_green'] = 'Zielony';
$txt['Adk_efColor_teal'] = 'Turkusowy';
$txt['Adk_efColor_lime_green'] = 'Jasny zielony';
$txt['Adk_efColor_blue'] = 'Niebieski';
$txt['Adk_efColor_blue1'] = 'Jasny niebieski';
$txt['Adk_efColor_navy'] = 'Granatowy';
$txt['Adk_efColor_maroon'] = 'Br�zowy';
$txt['Adk_efColor_brown'] = 'Ciemny br�zowy';
$txt['Adk_efColor_beige'] = 'Jasny br�zowy';
?>