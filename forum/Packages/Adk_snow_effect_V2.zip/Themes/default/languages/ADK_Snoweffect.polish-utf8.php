<?php
/********************************************************
* Adk Snow Effect           
* Version: 2.0
* Official support: http://www.smfpersonal.net 
* Author: enik
* Update and Optimization: ^HeRaCLeS^ 
* 2011
* Polish translation by phantom
/**********************************************************/

$txt['TitleAdkTeam'] = base64_decode('TW9kcyBieSA8YSB0YXJnZXQ9Il9ibGFuayIgaHJlZj0iaHR0cDovL3d3dy5zbWZwZXJzb25hbC5uZXQvIj48c3BhbiBzdHlsZT0iY29sb3I6IzAwNjY2NiI+QWRrIFRlYW08L3NwYW4+PC9hPg==');
$txt['Adk_Seffectcode'] = base64_decode('Jm5ic3A7Jm5ic3A7Jm5ic3A7Jm5ic3A7JiM4MjI2OyA8YSB0YXJnZXQ9Il9ibGFuayIgaHJlZj0iaHR0cDovL3d3dy5zbWZwZXJzb25hbC5uZXQvIj48Yj5BZGsgU25vdyBFZmZlY3Q8L2I+PC9hPg==');
$txt['Adkseffect_donate'] = '
	<div style="text-align:center;" class="smalltext">
		Adk efekt śniegu utworzony przez <a href="http://www.smfpersonal.net" target="blank">SMFPersonal</a><br />
		<a href="http://www.smfpersonal.net/about.html;sa=contribute" target="blank">Wesprzyj</a>
	</div>
';
$txt['Adkseffect_name'] = 'Adk efekt śniegu';
$txt['Adkseffect_desc'] = '
	Ta modyfikacja pozwoli dodać efekt śniegu na naszej stronie.
	<br /><b>Opcje:</b>
	<br />&nbsp;&nbsp;&#8226; Włącz/wyłącz modyfikacje.
	<br />&nbsp;&nbsp;&#8226; Zmień kolor śniegu.
	<br />&nbsp;&nbsp;&#8226; Zmień wygląd śniegu.
	<br />&nbsp;&nbsp;&#8226; Zmień szybkość śniegu.
	<br />&nbsp;&nbsp;&#8226; Włącz/wyłącz gromadzenie się śniegu na dole strony.
	<br />&nbsp;&nbsp;&#8226; Włącz/wyłącz śledzenie myszy przez śnieg.
';
$txt['enable_adk_snow_effect'] = '<strong>Włącz</strong> <strong style="color:red">Adk efekt śniegu</strong>:';
$txt['ADK_SeStick'] = '<strong>Wyłącz gromadzenie śniegu</strong>:';
$txt['ADK_SeMouse'] = '<strong>Wyłącz śledzenie myszy</strong>:';
$txt['ADK_Secolor'] = '<strong>Zmień kolor śniegu</strong>:';
$txt['ADK_SeChart'] = '<strong>Zmień szybkość śniegu</strong>:';
$txt['ADK_SeVelo'] = '<strong>Zmień szybkość śniegu</strong>:';
$txt['ADK_SeVelo_Default'] = 'Domyślnie';
$txt['ADK_SeVelo_slow'] = 'Wolno';
$txt['ADK_SeVelo_median'] = 'Średnio';
$txt['ADK_SeVelo_fast'] = 'Szybko';
$txt['Adk_efChart_Default'] = 'Domyślny';
$txt['Adk_efChart_bull'] = 'Wzór: &bull;';
$txt['Adk_efChart_middot'] = 'Wzór: &middot;';
$txt['Adk_efChart_curren'] = 'Wzór: &curren;';
$txt['Adk_efChart_times'] = 'Wzór: &times;';
$txt['Adk_efChart_ast'] = 'Wzór: *';
$txt['Adk_efColor_Default'] = 'Domyślny';
$txt['Adk_efColor_black'] = 'Czarny';
$txt['Adk_efColor_silver'] = 'Szary';
$txt['Adk_efColor_white'] = 'Biały';
$txt['Adk_efColor_yellow'] = 'Żółty';
$txt['Adk_efColor_orange'] = 'Pomarańczowy';
$txt['Adk_efColor_red'] = 'Czerwony';
$txt['Adk_efColor_pink'] = 'Różowy';
$txt['Adk_efColor_purple'] = 'Fioletowy';
$txt['Adk_efColor_green'] = 'Zielony';
$txt['Adk_efColor_teal'] = 'Turkusowy';
$txt['Adk_efColor_lime_green'] = 'Jasny zielony';
$txt['Adk_efColor_blue'] = 'Niebieski';
$txt['Adk_efColor_blue1'] = 'Jasny niebieski';
$txt['Adk_efColor_navy'] = 'Granatowy';
$txt['Adk_efColor_maroon'] = 'Brązowy';
$txt['Adk_efColor_brown'] = 'Ciemny brązowy';
$txt['Adk_efColor_beige'] = 'Jasny brązowy';
?>