<?php
/********************************************************
* Adk Snow Effect           
* Version: 2.0
* Official support: http://www.smfpersonal.net 
* Author: enik
* Update and Optimization: ^HeRaCLeS^ 
* 2011
/**********************************************************/

$txt['TitleAdkTeam'] = base64_decode('TW9kcyBieSA8YSB0YXJnZXQ9Il9ibGFuayIgaHJlZj0iaHR0cDovL3d3dy5zbWZwZXJzb25hbC5uZXQvIj48c3BhbiBzdHlsZT0iY29sb3I6IzAwNjY2NiI+QWRrIFRlYW08L3NwYW4+PC9hPg==');
$txt['Adk_Seffectcode'] = base64_decode('Jm5ic3A7Jm5ic3A7Jm5ic3A7Jm5ic3A7JiM4MjI2OyA8YSB0YXJnZXQ9Il9ibGFuayIgaHJlZj0iaHR0cDovL3d3dy5zbWZwZXJzb25hbC5uZXQvIj48Yj5BZGsgU25vdyBFZmZlY3Q8L2I+PC9hPg==');
$txt['Adkseffect_donate'] = '
	<div style="text-align:center;" class="smalltext">
		Adk Snow Effect By <a href="http://www.smfpersonal.net" target="blank">SMFPersonal</a><br />
		<a href="http://www.smfpersonal.net/about.html;sa=contribute" target="blank">Contribute</a>
	</div>
';
$txt['Adkseffect_name'] = 'Adk Snow Effect';
$txt['Adkseffect_desc'] = '
	This application will allow us to make a snow effect on our site.
	<br /><b>Options:</b>
	<br />&nbsp;&nbsp;&#8226; Enable/Disable the mod.
	<br />&nbsp;&nbsp;&#8226; Change the color of snow.
	<br />&nbsp;&nbsp;&#8226; Change the design of the snow.
	<br />&nbsp;&nbsp;&#8226; Change the speed of the snow.
	<br />&nbsp;&nbsp;&#8226; Enable/Disable accumulation of snow off the bottom of the page.
	<br />&nbsp;&nbsp;&#8226; Enable/Disable the tracking of the snow in the direction of the mouse.
';
$txt['enable_adk_snow_effect'] = '<strong>Enable</strong> <strong style="color:red">Adk snow effect</strong>:';
$txt['ADK_SeStick'] = '<strong>Disable Snow accumulation</strong>:';
$txt['ADK_SeMouse'] = '<strong>Disable your Mouse Tracking</strong>:';
$txt['ADK_Secolor'] = '<strong>Change the color of snow</strong>:';
$txt['ADK_SeChart'] = '<strong>Change the design of the snow</strong>:';
$txt['ADK_SeVelo'] = '<strong>Change the speed of the snow</strong>:';
$txt['ADK_SeVelo_Default'] = 'Default';
$txt['ADK_SeVelo_slow'] = 'Slow';
$txt['ADK_SeVelo_median'] = 'Median';
$txt['ADK_SeVelo_fast'] = 'Fast';
$txt['Adk_efChart_Default'] = 'Default';
$txt['Adk_efChart_bull'] = 'Design: &bull;';
$txt['Adk_efChart_middot'] = 'Design: &middot;';
$txt['Adk_efChart_curren'] = 'Design: &curren;';
$txt['Adk_efChart_times'] = 'Design: &times;';
$txt['Adk_efChart_ast'] = 'Design: *';
$txt['Adk_efColor_Default'] = 'Default';
$txt['Adk_efColor_black'] = 'Black';
$txt['Adk_efColor_silver'] = 'Gray';
$txt['Adk_efColor_white'] = 'White';
$txt['Adk_efColor_yellow'] = 'Yellow';
$txt['Adk_efColor_orange'] = 'Orange';
$txt['Adk_efColor_red'] = 'Red';
$txt['Adk_efColor_pink'] = 'Pink';
$txt['Adk_efColor_purple'] = 'Purple';
$txt['Adk_efColor_green'] = 'Green';
$txt['Adk_efColor_teal'] = 'Teal';
$txt['Adk_efColor_lime_green'] = 'Lime Green';
$txt['Adk_efColor_blue'] = 'Blue';
$txt['Adk_efColor_blue1'] = 'Light Blue';
$txt['Adk_efColor_navy'] = 'Navy Blue';
$txt['Adk_efColor_maroon'] = 'Brown';
$txt['Adk_efColor_brown'] = 'Dark Brown';
$txt['Adk_efColor_beige'] = 'Light Brown';
?>