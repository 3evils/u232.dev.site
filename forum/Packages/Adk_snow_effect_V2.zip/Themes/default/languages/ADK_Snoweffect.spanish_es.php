<?php
/********************************************************
* Adk Snow Effect           
* Version: 2.0
* Official support: http://www.smfpersonal.net 
* Author: enik
* Update and Optimization: ^HeRaCLeS^ 
* 2011
/**********************************************************/

$txt['TitleAdkTeam'] = base64_decode('TW9kcyBieSA8YSB0YXJnZXQ9Il9ibGFuayIgaHJlZj0iaHR0cDovL3d3dy5zbWZwZXJzb25hbC5uZXQvIj48c3BhbiBzdHlsZT0iY29sb3I6IzAwNjY2NiI+QWRrIFRlYW08L3NwYW4+PC9hPg==');
$txt['Adk_Seffectcode'] = base64_decode('Jm5ic3A7Jm5ic3A7Jm5ic3A7Jm5ic3A7JiM4MjI2OyA8YSB0YXJnZXQ9Il9ibGFuayIgaHJlZj0iaHR0cDovL3d3dy5zbWZwZXJzb25hbC5uZXQvIj48Yj5BZGsgU25vdyBFZmZlY3Q8L2I+PC9hPg==');
$txt['Adkseffect_donate'] = '
	<div style="text-align:center;" class="smalltext">
		Adk Snow Effect By <a href="http://www.smfpersonal.net" target="blank">SMFPersonal</a><br />
		<a href="http://www.smfpersonal.net/about.html;sa=contritube-spanish" target="blank">Contribuir</a>
	</div>
';
$txt['Adkseffect_name'] = 'Adk Snow Effect';
$txt['Adkseffect_desc'] = '
	Esta aplicaci�n nos permitira poner un efecto de nieve en nuestro sitio.
	<br /><b>Opciones:</b>
	<br />&nbsp;&nbsp;&#8226; Activar/desactivar el mod.
	<br />&nbsp;&nbsp;&#8226; Elegir color de la nieve
	<br />&nbsp;&nbsp;&#8226; Cambiar el dise�o de la nieve.
	<br />&nbsp;&nbsp;&#8226; Cambiar la velocidad de la nieve.
	<br />&nbsp;&nbsp;&#8226; Activar/desactivar la acumulacion de nieve al pie de p�gina.
	<br />&nbsp;&nbsp;&#8226; Activar/desactivar el movimiento de la nieve en direcci�n al mouse.
';
$txt['enable_adk_snow_effect'] = '<strong>Activar</strong> <strong style="color:red">Adk Snow Effect</strong>:';
$txt['ADK_SeStick'] = '<strong>Desactivar Acumulaci�n de nieve</strong>:';
$txt['ADK_SeMouse'] = '<strong>Desactivar Seguimiento de Mouse</strong>:';
$txt['ADK_Secolor'] = '<strong>Cambiar el color de la nieve</strong>:';
$txt['ADK_SeChart'] = '<strong>Cambiar el dise�o de la nieve</strong>:';
$txt['ADK_SeVelo'] = '<strong>Cambiar la velocidad de la nieve</strong>:';
$txt['ADK_SeVelo_Default'] = 'Default';
$txt['ADK_SeVelo_slow'] = 'Lenta';
$txt['ADK_SeVelo_median'] = 'Mediana';
$txt['ADK_SeVelo_fast'] = 'Rapida';
$txt['Adk_efChart_Default'] = 'Default';
$txt['Adk_efChart_bull'] = 'Dise�o: &bull;';
$txt['Adk_efChart_middot'] = 'Dise�o: &middot;';
$txt['Adk_efChart_curren'] = 'Dise�o: &curren;';
$txt['Adk_efChart_times'] = 'Dise�o: &times;';
$txt['Adk_efChart_ast'] = 'Dise�o: *';
$txt['Adk_efColor_Default'] = 'Default';
$txt['Adk_efColor_black'] = 'Negro';
$txt['Adk_efColor_silver'] = 'Gris';
$txt['Adk_efColor_white'] = 'Blanco';
$txt['Adk_efColor_yellow'] = 'Amarillo';
$txt['Adk_efColor_orange'] = 'Naranja';
$txt['Adk_efColor_red'] = 'Rojo';
$txt['Adk_efColor_pink'] = 'Rosa';
$txt['Adk_efColor_purple'] = 'Violeta';
$txt['Adk_efColor_green'] = 'Verde';
$txt['Adk_efColor_teal'] = 'Verde azulado';
$txt['Adk_efColor_lime_green'] = 'Verde lima';
$txt['Adk_efColor_blue'] = 'Azul';
$txt['Adk_efColor_blue1'] = 'Azul Claro';
$txt['Adk_efColor_navy'] = 'Azul marino';
$txt['Adk_efColor_maroon'] = 'Marr�n';
$txt['Adk_efColor_brown'] = 'Marr�n Oscuro';
$txt['Adk_efColor_beige'] = 'Marr�n Claro';
?>