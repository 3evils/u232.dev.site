<?php
/**************************************************************************
* AddMoreSpiders.php											*
***************************************************************************/

// Manual Install?
// If the user is manually installing allow them to upload install.php 
// providing its in the same directory as SMF, allow the install to proceed, 
if(!defined('SMF'))
	include_once('SSI.php');

// Globals
global $db_prefix, $context;

// If we're uninstalling, we can get out of here.
if(!empty($context['uninstalling']))
	return;
	
// Make sure we have access to install packages
if(!array_key_exists('db_add_column', $smcFunc))
	db_extend('packages');

$addSpider = array(
	// The big cheese spiders detected by SMF by default 				 		Website							Description								Recently Seen ?
//	array('Google', 'Googlebot'),										http://www.google.com					The main spider used by Google				Yes 06/08
//	array('Msn', 'MsnBot'),											http://www.msn.com					The main spider used by MSN					Yes 06/08
//	array('Yahoo!', 'Slurp'),											http://www.yahoo.com					Worlds most aggressive spider					Yes 06/08

	// MAJOR spiders							 				Website							Description								Recently Seen ?
	array('Ask', 'Teoma'),									// http://www.ask.com					Spider for Ask Search Engine					Yes 06/08
	array('Baidu', 'Baiduspider'),							// http://www.baidu.com				Spider for Chinese search engine				Yes 06/08
	array('GigaBot', 'Gigabot'),							// http://www.gigablast.com				Another heavily travelled spider				Yes 06/08
	array('Google-AdSense', 'Mediapartners-Google'),		// http://www.google.com				Spider related to Adsense/Adwords				Yes 06/08
	array('Google-Adwords', 'AdsBot-Google'),				// http://www.google.com				Spider related to Adwords					Yes 06/08
	array('Google-SA', 'gsa-crawler'),						// http://www.google.com				Google Search Appliance Spider				Yes 06/08
	array('Google-Image', 'Googlebot-Image'),				// http://www.google.com				Spider for google image search				Yes 06/08
	array('InternetArchive', 'ia_archiver-web.archive.org'),// http://www.archive.org				Way back When machine Spider				Yes 06/08
	array('Alexa', 'ia_archiver'),							// http://www.alexa.com				*Must be detected after Internet Archive			Yes 06/08
	array('Omgili', 'omgilibot'),							// http://www.omgili.com				Extremely aggressive Messageboard/forum Spider	Yes 06/08
	array('Speedy Spider', 'Speedy Spider'),				// http://www.entireweb.com				Entire web spider							Yes 06/08
	array('Yahoo', 'yahoo'),								// http://www.yahoo.com				For Yahoo Publisher Network  (a variety in use)		Yes 06/08
	array('Yahoo JP', 'Y!J'),								// http://www.yahoo.co.jp				Spider for Yahoo Japan						No

	// Checkers/Testers/Robots						 				Website							Description								Recently Seen ?
	array('DeadLinksChecker', 'link validator'),			// http://www.dead-links.com/			Checks your site for dead/bad links				Yes 06/08
	array('W3C Validator', 'W3C_Validator'),				// http://validator.w3.org				Checks standards validity of any html/xhtml page		Yes 06/08
	array('W3C CSSValidator', 'W3C_CSS_Validator'),			// http://jigsaw.w3.org/css-validator/		Checks standards validity of css stylesheets		Yes 06/08
	array('W3C FeedValidator', 'FeedValidator'),			// http://validator.w3.org/feed/ 			Checks standards validity of atom/rss feeds		Yes 06/08
	array('W3C LinkChecker', 'W3C-checklink'),				// http://validator.w3.org/checklink			Checks links on any html/xhtml page are valid 		Yes 06/08
	array('W3C mobileOK', 'W3C-mobileOK'),					// http://www.w3.org/2006/07/mobileok-ddc	Checks page for how good it is for mobiles			Yes 06/08
	array('W3C P3PValidator', 'P3P Validator'),				// http://www.w3.org/P3P/validator.html		Checks something??						Yes 06/08
	
	// Feed readers								 				Website							Description								Recently Seen ?
	array('Bloglines', 'Bloglines'),						// http://www.bloglines.com				Spider for blog/rich web content (owned by Ask)		Yes 06/08
	array('Feedburner', 'Feedburner'),						// http://www.feedburner.com			Another RSS feed reader					Yes 06/08

	// Website Thumbnail/Snapshot/Thumbshot takers		 				Website							Description								Recently Seen ?
	array('SnapBot', 'Snapbot'),							// http://www.snap.com					Shapshots provider						Yes 06/08
	array('Picsearch', 'psbot'),							// http://www.picsearch.com				Picture/Image Search Engine					Yes 06/08
	array('Websnapr', 'Websnapr'),							// http://www.websnapr.com				Snapshot/site screenshot taker				Yes 06/08
	
	// More MINOR Spiders/Robots					 				Website							Description								Recently Seen ?
	array('AllTheWeb', 'FAST-WebCrawler'), 					// http://www.alltheweb.com				Spider for alltheweb (now owned by Yahoo)			No
	array('Altavista', 'Scooter'),							// http://www.altavista.com				Another Major Search Engine spider				No
	array('Asterias', 'asterias'),							// http://www.aol.com					Media Spider							Yes 06/08
	array('192bot', '192.comAgent'),						// http://www.192.com					Spider to index for 192.com					No
	array('AbachoBot', 'ABACHOBot'),						// http://www.abacho.com				Spider for multi language search engine/translator	Yes 06/08
	array('Abdcatos', 'abcdatos'),							// http://www.abcdatos.com/botlink/		Spider for Italian Search Engine				Yes 06/08
	array('Acoon', 'Acoon'),								// http://www.acoon.de					Spider for small search engine					Yes 06/08
	array('Accoona', 'Accoona'),							// http://www.accoona.com				Spider for Accoona						Yes 06/08
	array('BecomeBot', 'BecomeBot'),						// http://www.become.com				Shopping/Products type search engine			Yes 06/08
	array('BlogRefsBot', 'BlogRefsBot'),					// http://www.blogrefs.com/about/bloggers	Blogs related spider						Yes 06/08
	array('Daumoa', 'Daumoa'),								// http://ws.daum.net/aboutkr.html			South Korean Search Engine Spider				Yes 06/08
	array('DuckDuckBot', 'DuckDuckBot'),					// http://duckduckgo.com/duckduckbot.html	Spider for small search engine					Yes 06/08
	array('Exabot', 'Exabot'),								// http://www.exalead.com				Spider for small search engine					Yes 06/08
	array('Furl', 'Furlbot'),								// http://www.furl.net					Spider for Furl social bookmarking site			Yes 06/08
	array('FyperSpider', 'FyberSpider'),					// http://www.fybersearch.com			Spider for Small Search Engine				Yes 06/08
	array('Geona', 'GeonaBot'),								// http://www.geona.com				Spider for another small search engine			Yes 06/08
	array('GirafaBot', 'Girafabot'),						// http://www.girafa.com/				Thumbshot provider						Yes 06/08
	array('GoSeeBot', 'GoSeeBot'),							// http://www.gosee.com/bot.html			Spider for small search engine 				Yes 06/08
	array('Ichiro', 'ichiro'),								// http://help.goo.ne.jp/door/crawler.html		Spider for Japanese search engine				Yes 06/08
	array('LapozzBot', 'LapozzBot'),						// http://www.lapozz.hu				 	Spider for Hungarian search engine				Yes 06/08
	array('Looksmart', 'WISENutbot'),						// http://www.looksmart.com				Spider related to advertising 					Yes 06/08
	array('Lycos', 'Lycos_Spider'),							// http://www.lycos.com				Spider for search engine					No
	array('Majestic12', 'MJ12bot/v2'),						// http://www.majestic12.co.uk/			Distributed Search Engine Project				Yes 06/08
	array('MLBot', 'MLBot'),								// http://www.metadatalabs.com/			Media indexing spider						Yes 06/08
	array('MSRBOT', 'msrbot'),								// http://research.microsoft.com/research/sv/msrbot/  	Microsoft Research bot				No
	array('MSR-ISRCCrawler', 'MSR-ISRCCrawler'),			// http://www.microsoft.com/research/	  	Another Microsoft Research bot				Yes 06/08
	array('Naver', 'NaverBot'),								// http://www.naver.com				South Korean Search Engine Spider				Yes 06/08
	array('Naver', 'Yeti'),									// http://www.naver.com				Another NaverBot for the South Korean Search Engine	Yes 06/08
	array('NoxTrumBot', 'noxtrumbot'),						// http://www.noxtrum.com				Spider for Spanish search engine				Yes 06/08
	array('OmniExplorer', 'OmniExplorer_Bot'),				// http://www.omni-explorer.com/			Spider								Yes 06/08
	array('OnetSzukaj', 'OnetSzukaj'),						// http://szukaj.onet.pl					Polish Search Engine Spider					Yes 06/08
	array('ScrubTheWeb', 'Scrubby'),						// http://www.scrubtheweb.com			Spider for Scrub the web					Yes 06/08
	array('SearchSight', 'SearchSight'),					// http://www.searchsite.com				Another search engine						Yes 06/08
	array('Seeqpod', 'Seeqpod'),							// http://www.seeqpod.com		 		Spider for search engine (the google for mp3 files)	Yes 06/08
	array('Shablast', 'ShablastBot'),						// http://www.shablast.com				Spider for a small search engine				Yes 06/08
	array('SitiDiBot', 'SitiDiBot'),						// http://www.sitidi.net					Spider for italian Sitidi search engine			Yes 06/08
	array('Slider', 'silk/1.0'),							// http://www.slider.com				Spider for Slider, but it only spiders DMOZ entries	Yes 06/08
	array('Sogou', 'Sogou'),								// http://www.sogou.com				Spider for Chinese search engine				Yes 06/08
	array('Sosospider', 'Sosospider'),						// http://help.soso.com/webspider.htm		Non-english search engine					Yes 06/08
	array('StackRambler', 'StackRambler'),					// http://www.rambler.ru/doc/robots.shtml		Spider for Russian portal/search engine  			Yes 06/08
	array('SurveyBot', 'SurveyBot'),						// http://www.domaintools.com			Probe for website statistics (WhoIs  Source)		Yes 06/08
	array('Touche', 'Touche'),								// http://www.touche.com.ve				Another small search engine					Yes 06/08
	array('Walhello', 'appie'),								// http://www.wahello.com/				Spider for wahello						No
	array('WebAlta', 'WebAlta'), 							// http://www.webalta.net				Russian Search Engine						Yes 06/08
	array('Wisponbot', 'wisponbot'), 						// http://www.wispon.com				Korean Search Engine						Yes 06/08
	array('YacyBot', 'yacybot'),							// http://www.yacy.com			 		Crawler for distributed search engine			Yes 06/08
	array('YodaoBot', 'YodaoBot'),							// http://www.yodao.com				Spider for Chinese Search Engine				Yes 06/08
	
	// Google-Wanna-Be's - Spiders/Robots for Startups		 				Website							Description								Recently Seen ?
	array('Charlotte', 'Charlotte'),						// http://www.searchme.com/support/ 		Spider for new search engine (in beta)		  	Yes 06/08
	array('DiscoBot', 'DiscoBot'),							// http://discoveryengine.com/discobot.html	Spider for new search engine startup			Yes 06/08
	array('EnaBot', 'EnaBot'),								// http://www.enaball.com/crawler.html		Experimental new spider					Yes 06/08
	array('Gaisbot', 'Gaisbot'),							// http://gais.cs.ccu.edu.tw/robot.php		Spider for search engine startup				Yes 06/08
	array('Kalooga', 'kalooga'),							// http://www.kalooga.com				Spider for new media search engine (in beta)		Yes 06/08
	array('ScoutJet', 'ScoutJet'),							// http://www.scoutjet.com/				Spider for new search engine (by the DMOZ founders)	Yes 06/08
	array('TinEye', 'TinEye'),								// http://tineye.com/crawler.html			Spider for search engine startup				Yes 06/08
	array('Twiceler', 'twiceler'),							// http://www.cuill.com/twiceler/robot.html	Experimental Spider, (aggressive)				Yes 06/08

	// Software								 				Website							Description								Recently Seen ?
	array('GSiteCrawler', 'GSiteCrawler'),					// http://www.gsitecrawler.com/			Windows Based Sitemap Generator Software		Yes 06/08
	array('HTTrack', 'HTTrack'),							// http://www.httrack.com				HTTrack Website Copier - Offline Browser		Yes 06/08
	array('Wget', 'Wget'),									// http://www.gnu.org/software/wget/		GNU software to retrieve files				Yes 06/08
	// Reason for detecting these: They can be very intensive. So seeing them in use, enables you to block if necessary.

);

	// Correction from v1.0
	// Alexa/InternetArchive use similar 
	$smcFunc['db_query']('', '
		DELETE FROM {db_prefix}spiders
		WHERE spider_name = {string:spider_name}
			AND user_agent = {string:user_agent}
		',
		array(
			'spider_name' => 'InternetArchive',
			'user_agent' => 'ia_archiver',
		)
	);
	
	// Grab all the existing spiders to match against
	$request = $smcFunc['db_query']('', '
		SELECT user_agent
		FROM {db_prefix}spiders',
		array()
	);

	$knownspiders = array();
	if ($smcFunc['db_num_rows']($request) != 0)
	{	
		// Store all found spiders in an array
		while ($row = $smcFunc['db_fetch_assoc']($request))
			$knownspiders[] = $row['user_agent'];
	}
	
// Now go through spider in the mo
foreach($addSpider as $spider)
{
	// If doesn't already exist in the table, then add it
	if(!in_array($spider[1], $knownspiders))
	{
		// Now add each spider
		$smcFunc['db_insert']('ignore',
			'{db_prefix}spiders',
			array('spider_name' => 'string', 'user_agent' => 'string', 'ip_info' => 'string'),
			array($spider[0], $spider[1], ''),
			array('spider_name', 'user_agent', 'ip_info')
		);
	}
}

//Unset everything
unset($knownspiders, $addSpider, $spider);

// If we're using SSI, tell them we're done
if(SMF == 'SSI')
	echo 'Database changes are complete!';

?>