[center][hr][color=red][size=16pt][b]MORE SPIDERS v1.2[/b][/size][/color]
[url=http://custom.simplemachines.org/mods/index.php?action=profile;u=63186][b]By Karl Benson[/b][/url]
[hr][url=http://custom.simplemachines.org/mods/index.php?mod=1157][b]Link to Mod[/b][/url] | [url=http://www.simplemachines.org/community/index.php?topic=233636.0][b]Support Topic[/b][/url] | [url=http://www.adrevenueshare.com/donate][b]Donate[/b][/url][hr][/center]

[color=blue][b][size=12pt][u]Compatibility[/u][/size][/b][/color]
For SMF 2.0 Beta 3 Public, 2.0 Beta 3.1 (and above)
It will not work for ANY earlier versions.

[color=blue][b][size=12pt][u]Introduction[/u][/size][/b][/color]
Adds 77 more spiders/crawlers/bots to your Spiders section in SMF

[color=blue][b][size=12pt][u]Features[/u][/size][/b][/color]
o 83 Spiders belonging to search engines, validators, checkers, crawlers, bots, software, etc.
- Including; Ask, Baidu, GigaBot, Google-AdSense, Google-Adwords, Google-SA, Google-Image, InternetArchive, Alexa, Omgili, Speedy Spider, Yahoo, Yahoo JP, DeadLinksChecker, W3C Validator, W3C CSSValidator, W3C FeedValidator, W3C LinkChecker, W3C mobileOK, W3C P3PValidator, Bloglines, Feedburner, SnapBot, Picsearch, Websnapr, AllTheWeb, Altavista, Asterias, 192bot, AbachoBot, Abdcatos, Acoon, Accoona, BecomeBot, BlogRefsBot, Daumoa, DuckDuckBot, Exabot, Furl, FyperSpider, Geona, GirafaBot, GoSeeBot, Ichiro, LapozzBot, Looksmart, Lycos, Majestic12, MLBot, MSRBOT, MSR-ISRCCrawler, Naver, Naver, NoxTrumBot, OmniExplorer, OnetSzukaj, ScrubTheWeb, SearchSight, Seeqpod, Shablast, SitiDiBot, Slider, Sogou, Sosospider, StackRambler, SurveyBot, Touche, Walhello, WebAlta, Wisponbot, YacyBot, YodaoBot, Charlotte, DiscoBot, EnaBot, Gaisbot, Kalooga, ScoutJet, TinEye, Twiceler, GSiteCrawler, HTTrack, Wget
(Remember SMF detects most Google/Yahoo/MSN bots by default)

It appears that most sites offering spider/bot lists have tonnes of inactive ones. I'm putting together my own lists by detecting them in the wild on my own sites. Plus any that get reported to me (after I've checked them out).

So if there are any ACTIVE ones I'm missing? Please let me know in the support topic.

[color=blue][b][size=12pt][u]Installation[/u][/size][/b][/color]
Any previous versions of the mod does NOT need to be uninstalled.
This mod adds a row for each spider in the database only. It will ignore adding ones which already exist.
No theme edits required. No language strings to translate or editing. It adds database rows only.

Install and your done.
Note: Click uninstall to remove the mod from your mod list. But it won't remove the spiders from your database. You'll need to remove each one from your SMF Search Engines/Spider section.

For manual installation, just upload AddMoreSpiders.php to your SMF directory and run it in your browser (then delete the file).

[b]Useful Links[/b]
[url=http://www.adrevenueshare.com/parser]SMF Package Parser[/url] (No you won't need this for this mod)
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]

[color=blue][b][size=12pt][u]Donate[/u][/size][/b][/color]
Has this modification helped you? Support the developer by [url=http://www.adrevenueshare.com/donate][color=red][b]Donating[/b][/color][/url]

[color=blue][b][size=12pt][u]Support[/u][/size][/b][/color]
Please use the modification thread for support with this modification.
(Please don't ask me to do the edits for you)

[color=blue][b][size=12pt][u]Changelog[/u][/size][/b][/color]
[b]1.0 - 9th April 2008[/b]
o Initial release.
[b]1.1 - 4th May 2008[/b]
o Fixed Alexa/InternetArchive
o 25 More Spiders added (which have been detected [url=http://www.youposted.com/]on my forum[/url] in the past month)
[b]1.2 - 20th June 2008[/b]
o Added a handful of new spiders which have been detected in the past month