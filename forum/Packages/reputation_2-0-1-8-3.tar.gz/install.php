<?php
if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
else if(!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php and SSI.php files.');

if((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin priveleges required.');

db_extend('packages');

// If this mod is new to your forum, clear the karma log.
$rows = $smcFunc['db_list_columns']('{db_prefix}members');

if(!isset($rows['karma_disabled']))
	$smcFunc['db_query']('', '
		DELETE FROM {db_prefix}log_karma
		WHERE 1=1',
		array()
	);

// Settings table
$smcFunc['db_insert']('ignore',
	'{db_prefix}settings',
	array('variable' => 'string', 'value' => 'string'),
	array(
		array('karmaBarPower', '100'),
		array('karmaBarPoints', '1000'),
		array('karmaMaxBars', '12'),
		array('karmaSuperBar', '7'),
		array('karmaSpreadAround', '3'),
		array('karmaValuePost', '1'),
		array('karmaValueThread', '3'),
		array('karmaMaxPerDay', '10'),
		array('karmaRegistration', '100'),
		array('karmaBirthday', '100'),
		array('karmaNegativeDescription', 'is looked down upon.'),
		array('karmaDisabledDescription', 'hides in shadows.'),
		array('karmaDescriptions', 'has no influence.
barely matters.
is working their way up.
might someday be someone...
is on the verge of being accepted.
is a rising star!
has a powerful will.
is a force to reckon with.
has great potential!
has an aura about them.
is leading the good life!
is awe-inspiring!'),
	),
	array('variable')
);

$smcFunc['db_query']('', '
	UPDATE {db_prefix}settings
	SET value = {string:rep}
	WHERE variable = {string:karma}',
	array(
		'rep' => 'Reputation:',
		'karma' => 'karmaLabel'
	)
);

// Members column
$members_column = array('name' => 'karma_disabled', 'type' => 'tinyint', 'size' => 3, 'null' => false, 'default' => '0');
$smcFunc['db_add_column']('{db_prefix}members', $members_column);

$members_column_e = array('type' => 'int', 'size' => 8);
$smcFunc['db_change_column']('{db_prefix}members', 'karma_good', $members_column_e);
$smcFunc['db_change_column']('{db_prefix}members', 'karma_bad', $members_column_e);

// Scheduled Tasks row
$request = $smcFunc['db_query']('', '
	SELECT id_task
	FROM {db_prefix}scheduled_tasks
	WHERE id_task != {int:zero}
	ORDER BY id_task DESC
	LIMIT 1',
	array(
		'zero' => 0
	)
);

list ($task_id) = $smcFunc['db_fetch_row']($request);

$time_next = time() + 7200; // Start two hours from now
$time_next = $time_next - ($time_next % 3600); // But round it down to the hour

$smcFunc['db_insert']('ignore',
	'{db_prefix}scheduled_tasks',
	array(
		'id_task' => 'int',
		'next_time' => 'int',
		'time_offset' => 'int',
		'time_regularity' => 'int',
		'time_unit' => 'string',
		'disabled' => 'int',
		'task' => 'string',
	),
	array(
		$task_id,
		$time_next,
		'0',
		'1',
		'd',
		0,
		'karma_birthdays',
	),
	array('id_task')
);

// Karma Log columns
$karma_column_1 = array('name' => 'comment', 'type' => 'varchar', 'size' => 300, 'null' => false);
$smcFunc['db_add_column']('{db_prefix}log_karma', $karma_column_1);

$karma_column_2 = array('name' => 'action_type', 'type' => 'varchar', 'size' => 15, 'null' => false);
$smcFunc['db_add_column']('{db_prefix}log_karma', $karma_column_2);

$karma_column_3 = array('name' => 'topic', 'type' => 'int', 'size' => 12, 'null' => false);
$smcFunc['db_add_column']('{db_prefix}log_karma', $karma_column_3);

$karma_column_4 = array('name' => 'title', 'type' => 'varchar', 'size' => 256, 'null' => false);
$smcFunc['db_add_column']('{db_prefix}log_karma', $karma_column_4);

$karma_column_5 = array('name' => 'message', 'type' => 'int', 'size' => 12, 'null' => false);
$smcFunc['db_add_column']('{db_prefix}log_karma', $karma_column_5);

$karma_column_e = array('type' => 'int', 'size' => 8);
$smcFunc['db_change_column']('{db_prefix}log_karma', "action", $karma_column_e);

// Remove the old karma index
$smcFunc['db_remove_index']('{db_prefix}log_karma', 'primary');

// And add the new ones!
$new_index = array(
	'columns' => array('id_executor', 'topic', 'message'),
	'type' => 'primary',
);

$smcFunc['db_add_index']('{db_prefix}log_karma', $new_index);

$hooks = array(
	'integrate_actions' => 'reputation_action',
	'integrate_profile_areas' => 'reputation_profile',
	'integrate_load_permissions' => 'reputation_permissions'
	);

foreach ($hooks as $hook => $function)
	add_integration_function($hook, $function);

if(SMF == 'SSI')
	echo 'Database changes are complete!';
?>