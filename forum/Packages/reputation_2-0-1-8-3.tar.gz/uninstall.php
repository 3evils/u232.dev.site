<?php
if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
else if(!defined('SMF'))
	die('<b>Error:</b> Cannot uninstall - please verify you put this in the same place as SMF\'s index.php and SSI.php files.');

if((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin priveleges required.');

db_extend('packages');

// Settings table
$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}settings
	WHERE variable IN ({array_string:vars})',
	array(
		'vars' => array(
			'karmaBarPower',
			'karmaBarPoints',
			'karmaMaxBars',
			'karmaSuperBar',
			'karmaSpreadAround',
			'karmaValuePost',
			'karmaValueThread',
			'karmaMaxPerDay',
			'karmaRegistration',
			'karmaBirthday',
			'karmaNegativeDescription',
			'karmaDisabledDescription',
			'karmaDescriptions',
		)
	)
);

$smcFunc['db_query']('', '
	UPDATE {db_prefix}settings
	SET value = {string:rep}
	WHERE variable = {string:karma}',
	array(
		'rep' => 'Karma:',
		'karma' => 'karmaLabel'
	)
);

/* Scheduled Tasks row
$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}scheduled_tasks
	WHERE task = {string:karma}',
	array(
		'karma' => 'karma_birthdays',
	)
);

$smcFunc['db_query']('', '
	ALTER TABLE {db_prefix}log_karma
	DROP COLUMN action_type',
''
);
$smcFunc['db_query']('', '
	ALTER TABLE {db_prefix}log_karma
	DROP COLUMN topic',
''
);
$smcFunc['db_query']('', '
	ALTER TABLE {db_prefix}log_karma
	DROP COLUMN title',
''
);
$smcFunc['db_query']('', '
	ALTER TABLE {db_prefix}log_karma
	DROP COLUMN message',
''
);
$smcFunc['db_query']('', '
	ALTER TABLE {db_prefix}members
	DROP COLUMN karma_disabled',
''
); */

// Remove the old karma index
			$smcFunc['db_query']('', '
				ALTER TABLE {db_prefix}log_karma
				DROP PRIMARY KEY',
				'security_override'
			);

// And add the new!
		$smcFunc['db_query']('', '
			ALTER TABLE {db_prefix}log_karma
			ADD PRIMARY KEY (id_executor)',
			'security_override'
		);
		
		$smcFunc['db_query']('', '
			ALTER TABLE {db_prefix}log_karma
			ADD PRIMARY KEY (id_target)',
			'security_override'
		);

// Clear out the old karma log... and start fresh
$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}log_karma
	WHERE 1=1',
	array()
);

$hooks = array(
	'integrate_actions' => 'reputation_action',
	'integrate_profile_areas' => 'reputation_profile',
	'integrate_load_permissions' => 'reputation_permissions'
	);

foreach ($hooks as $hook => $function)
	remove_integration_function($hook, $function);

if(SMF == 'SSI')
	echo 'Database changes are complete!';
?>