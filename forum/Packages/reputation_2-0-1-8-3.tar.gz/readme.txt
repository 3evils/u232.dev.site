[hr]
[center][color=red][size=16pt][b]Advanced Reputation System v1.8.3[/b][/size][/color][/center]
[hr]

[b][color=blue]Introduction[/color][/b]
A full Karma System replacement, with adjustable reputation settings and an in-post rate/comment popup box.

[b][color=blue]Features[/color][/b]
o Reputation sent is now based on the giver's reputation
o Popup box can be activated in posts wherein reputation can be sent with a comment
o Members can view their own reputation by going to action=profile;sa=reputation
o :: Moderators (or anyone with permission) can delete reputation actions on this screen
o Reputation can be given per post, per thread, on account birthday, and on registration
o and more!

[b][color=blue]Support[/color][/b]
Please use the modification thread for support with this modification. Personal messages for support are discouraged.

[b][color=blue]Languages[/color][/b]
o English
o English UTF-8
o Russian [color=orange]by Ben K[/color]
o Spanish UTF-8 [color=purple]by Hefesto[/color]
o Turkish [color=green]by Mythcomeback | Burak[/color]
o Turkish UTF-8 [color=green]by Mythcomeback | Burak[/color]
o German UTF-8 [color=blue]by Ryoki[/color]
If you have any translations for any other languages, I would be grateful if you would send them to me via PM or in the Mod's topic.

[hr]
[center][color=red][size=16pt][b]Important Instructions![/b][/size][/color][/center]
[hr]

Before using this mod, [b]uninstall all other Karma-changing mods[/b]. This mod changes so much that most other Karma mods will be incompatible.
 
After installing, go into [b]Configuration > Features & Options > Core Features[/b] and make sure Reputation is turned on. Then, go to [b]Members > Permissions > General Permissions[/b] and select which membergroups you want to [u]be able to give positive reputation[/u]. Click 'Advanced Options' and make sure Add Permission is selected in the bottom left dropdown box. In the bottom right, select 'Can +reputation other users' and click 'Set Permission'. Repeat for 'Can -reputation other users' and 'Disable display of own reputation'. Then select your [b]Moderator[/b] groups and give them the permission to 'Delete reputuation actions'.

That's about it! There are a dozen or so settings under [b]Configuration > Figures & Options > Reputation[/b] that you can mess around with, and six images that you can change if you feel like it.

[hr]
[center][color=red][size=16pt][b]One More Thing![/b][/size][/color][/center]
[hr]

To install this modification in any theme other than Default, please [b]click the box next to "Install in Other Themes"[/b] at the bottom of this page and check the applicable themes. [b]This release only works for Curve-based themes. A compatibility pack will be released in the near future.[/b]