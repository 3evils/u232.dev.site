<?php

$txt['markItUp_settings'] = 'Альтернативный BBC-редактор [markItUp!]';
$txt['markItUp_skin'] = 'Скин редактора';
$txt['markItUp_editor'] = 'Замена стандартного редактора';
$txt['markItUp_editor_select'] = 'Только в форме быстрого ответа|В формах быстрого и полного ответа';
$txt['image_desc'] = 'Описание';
$txt['image_url'] = 'Адрес';
$txt['hyperlink_text'] = 'Анкор';
$txt['yellow_green'] = 'Жёлто-зелёный';
$txt['smileys'] = 'Смайлы';
$txt['list_item'] = 'Элемент списка';
$txt['table_generator'] = 'Генератор таблицы';
$txt['table_text'] = 'Вставьте сюда ваш текст...';
$txt['table_question_cols'] = 'Сколько столбцов?';
$txt['table_question_rows'] = 'Сколько строк?';
$txt['calculator'] = 'Калькулятор';
$txt['calculator_error'] = 'Значение выделенного выражения подсчитать невозможно:';
$txt['latex'] = 'Формула';
$txt['current_day'] = 'Текущая дата и время';
$txt['alphabetic_sort'] = 'Отсортировать выделенные строчки по алфавиту';
$txt['text_replace'] = 'Замена в тексте';
$txt['text_replace_what'] = 'Что ищем?';
$txt['text_replace_with'] = 'На что меняем?';
$txt['text_replace_done'] = 'Выполнено!';
$txt['clean'] = 'Очистить выделенный текст от BB-тегов';
$txt['quick_reply_desc_add'] = ' У некоторых кнопок есть альтернативные варианты вставки — для этого перед нажатием на кнопку зажмите <em>Alt</em>.';
$txt['groups_use_markItUp'] = 'Группы, которые могут использовать markItUp';
$txt['permissionname_use_markItUp'] = 'Использование редактора markItUp';
$txt['permissionhelp_use_markItUp'] = 'Разрешить этой группе пользователей работать с редактором markItUp.';

?>