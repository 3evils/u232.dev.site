<?php
// Version: 1.2: AdvancedNews

// Important! Before editing these language files please read the text at the top of index.english.php.

$txt['permissionname_view_news'] = 'View Forum News';
$txt['permissionhelp_view_news'] = 'By checking this, you are allowing members in this membergroup to view your forums news.';
$txt['cannot_view_news'] = 'Sorry, it appears you do not have permission to view the News page.';
$txt['advanced_news_page_disabled'] = 'Sorry, it appears the News page has been disabled.';
$txt['advanced_news_title'] = 'Advanced News';
$txt['disable_advanced_news_page'] = 'Disable News Page';
$txt['advanced_news_desc'] = 'Edit Advanced News Settings';
$txt['advanced_news_settings_title'] = 'Advanced News Settings';

?>