<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
{
	$ssi = true;
	require_once(dirname(__FILE__) . '/SSI.php');
}
elseif (!defined('SMF'))
	exit('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

add_integration_function('integrate_pre_include', '$sourcedir/AdvancedNews.php');
add_integration_function('integrate_load_theme', 'advanced_news_load_theme');
add_integration_function('integrate_actions', 'advanced_news_actions');
add_integration_function('integrate_load_permissions', 'advanced_news_load_permissions');
add_integration_function('integrate_modify_modifications', 'advanced_news_modify_modifications');
add_integration_function('integrate_admin_areas', 'advanced_news_admin_areas');
add_integration_function('integrate_menu_buttons', 'advanced_news_menu_buttons');

if (!empty($ssi))
	echo 'Database installation complete!';

?>