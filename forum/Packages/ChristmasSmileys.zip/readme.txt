[center][font=times new roman][size=24pt][color=#654321]Christmas Smileys[/color][/size][/font]
[table]
[tr][td][right][b]Created By:[/b] [/right][/td][td][url=http://www.simplemachines.org/community/index.php?action=profile;u=200419]-=[Vyorel]=-[/url]
([url=http://custom.simplemachines.org/mods/index.php?action=search;author=200419]View my other mods here[/url])[/td][/tr]
[tr][td][right][b]Latest Version:[/b] [/right][/td][td]1.0[/td][/tr]
[/table]
[b]My Website[/b]: [url=http://www.xerom-zone.ro]www.Xerom-Zone.ro[/url]
[/center]

[font=times new roman][size=14pt][color=#654321]Summary[/color][/size][/font]

This package contains 37 Christmas Smileys.

You can install it using the package manager and then use the Smileys and message icons menu (Smileys and Message Icons -> smiley sets new smiley set) to import the smiley's.

[center][url=http://www.xerom-zone.ro/imghost/pt-813223559603.html][img]http://www.xerom-zone.ro/imghost/dt-813223559603.png[/img][/url][/center]


[font=times new roman][size=14pt][color=#654321]Disclaimer[/color][/size][/font]
This Avatars are copyrighted to www.freeemoticonsandsmileys.com and all right are reserved.