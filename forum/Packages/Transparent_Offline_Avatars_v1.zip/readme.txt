Transparent Offline Avatars is a modification which uses Javascript to set a specified transparency level on member's avatars if they are offline. This doesnt affect any XHTML or CSS validation in any way.

Created by Anthony Calandra/Project Evolution - 2010.