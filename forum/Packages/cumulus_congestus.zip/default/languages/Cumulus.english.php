<?php

$txt['cumulus_title'] = 'Cumulus Congestus';
$txt['cumulus_desc'] = 'Here you can change settings of Cumulus Congestus mod.';
$txt['cumulus_show'] = 'Show "Popular Topics" cloud within Info Center?';
$txt['cumulus_show_help'] = 'To display "Popular Topics" cloud within php/html block of any portal you can use cumulus_show() function.';
$txt['cumulus_type'] = 'Cloud type';
$txt['cumulus_cloud_types'] = array('WP-Cumulus', 'Tagnetic Poetry', 'TagCanvas (HTML5)');
$txt['cumulus_ignoreboards'] = 'Ignored boards';
$txt['cumulus_count'] = 'Number of topics in the cloud';
$txt['cumulus_variant'] = 'Criterion of popularity rating';
$txt['cumulus_variants'] = array('Number views', 'Number replies');
$txt['cumulus_variants_for_sc'] = array('Number views', 'Number comments');
$txt['cumulus_style'] = 'Block title appearance style';
$txt['cumulus_styles'] = array('Don\'t use title', 'Curve style', 'BlocWeb style', 'Core style');
$txt['cumulus_height'] = 'Flash height';
$txt['cumulus_tcolor'] = 'The default link color';
$txt['cumulus_tcolor2'] = 'Second link color <div class="smalltext">If supplied, links will get a color from a gradient between both colors based on their popularity.</div>';
$txt['cumulus_hicolor'] = 'Tag mouseover/hover color';
$txt['cumulus_tspeed'] = 'Rotation speed <div class="smalltext">From 0 to 100 (0 = disabled).</div>';
$txt['cumulus_maxfont'] = 'Maximal font size';
$txt['cumulus_minfont'] = 'Minimanl font size';
$txt['cumulus_scale'] = 'Tagsize scale';
$txt['cumulus_alert'] = 'To display popular topics please install the latest version of Flash Player.';
$txt['cumulus_number_postfix'] = '6 characters';
$txt['cumulus_single'] = 'Most Popular Topic';
$txt['cumulus_ssi_not_found'] = 'SSI.php not found. Please verify SSI.php is exists (in root directory of your forum).';
$txt['cumulus_compat'] = 'Compatibility mode';
$txt['cumulus_compat_mods'] = array('Disable', 'Tagging System', 'Topic Rating Bar', 'Simple Classifieds');
$txt['cumulus_topics'] = 'Popular Topics';
$txt['cumulus_tags'] = 'Tag Cloud';

?>