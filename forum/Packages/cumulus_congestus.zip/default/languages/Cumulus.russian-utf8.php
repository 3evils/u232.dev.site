<?php

$txt['cumulus_title'] = 'Cumulus Congestus';
$txt['cumulus_desc'] = 'Здесь можно изменить настройки блока популярных тем, отображающегося на главной странице форума.';
$txt['cumulus_show'] = 'Показывать облако популярных тем в Информационном центре';
$txt['cumulus_show_help'] = 'Для вывода популярных тем в блоке какого-нибудь портала используйте функцию cumulus_show().';
$txt['cumulus_type'] = 'Тип облака';
$txt['cumulus_cloud_types'] = array('WP-Cumulus', 'Tagnetic Poetry', 'TagCanvas (HTML5)');
$txt['cumulus_ignoreboards'] = 'Игнорируемые разделы';
$txt['cumulus_count'] = 'Количество тем в облаке';
$txt['cumulus_variant'] = 'Критерий оценки популярности';
$txt['cumulus_variants'] = array('Количество просмотров', 'Количество ответов');
$txt['cumulus_variants_for_sc'] = array('Количество просмотров', 'Количество комментариев');
$txt['cumulus_style'] = 'Стиль оформления заголовка блока <div class="smalltext">Выбор зависит от используемой темы.</div>';
$txt['cumulus_styles'] = array('Не использовать заголовок', 'Как в теме Curve', 'Как в темах BlocWeb', 'Как в теме Core');
$txt['cumulus_height'] = 'Высота flash';
$txt['cumulus_tcolor'] = 'Цвет ссылок в блоке';
$txt['cumulus_tcolor2'] = 'Цвет для градиента <div class="smalltext">Если задан цвет для градиента, цвет каждой ссылки будет зависеть от её «веса» и будет располагаться на линии градиента, заданного этими двумя цветами.</div>';
$txt['cumulus_hicolor'] = 'Цвет ссылок при наведении';
$txt['cumulus_tspeed'] = 'Скорость вращения ссылок в облаке <div class="smalltext">От 0 до 100 (0 — отключить).</div>';
$txt['cumulus_maxfont'] = 'Максимальный размер шрифта';
$txt['cumulus_minfont'] = 'Минимальный размер шрифта';
$txt['cumulus_scale'] = 'Масштаб размера тегов';
$txt['cumulus_alert'] = 'Для отображения популярных тем необходимо установить Flash Player 9 или более поздней версии.';
$txt['cumulus_number_postfix'] = '6 символов';
$txt['cumulus_single'] = 'Самая популярная тема';
$txt['cumulus_ssi_not_found'] = 'SSI.php не найден. Пожалуйста, убедитесь в его существовании (в корне форума).';
$txt['cumulus_compat'] = 'Режим совместимости с другими модами';
$txt['cumulus_compat_mods'] = array('Не использовать', 'Tagging System', 'Topic Rating Bar', 'Simple Classifieds');
$txt['cumulus_topics'] = 'Популярные темы';
$txt['cumulus_tags'] = 'Облако тегов';

?>