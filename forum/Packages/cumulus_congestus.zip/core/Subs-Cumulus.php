<?php
/*******************************************************************************
* Cumulus Congestus � 2011-2012, Bugo										   *
********************************************************************************
* Subs-Cumulus.php															   *
********************************************************************************
* License http://creativecommons.org/licenses/by-nc-nd/3.0/deed.ru CC BY-NC-ND *
* Support and updates for this software can be found at	http://dragomano.ru    *
*******************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

// For portal blocks etc
function cumulus_show()
{
	echo cumulus();
}

// Main function
function cumulus($notitle = true)
{
	global $txt, $modSettings, $boarddir, $smcFunc, $db_character_set, $sourcedir, $context, $scripturl, $settings;
	
	loadLanguage('Cumulus');

	// Default values
	$modSettings['cumulus_count']   = !empty($modSettings['cumulus_count']) ? $modSettings['cumulus_count'] : 0;
	$modSettings['cumulus_height']  = !empty($modSettings['cumulus_height']) ? $modSettings['cumulus_height'] : 150;
	$modSettings['cumulus_tcolor']  = !empty($modSettings['cumulus_tcolor']) ? $modSettings['cumulus_tcolor'] : '000000';
	$modSettings['cumulus_tcolor2'] = !empty($modSettings['cumulus_tcolor2']) ? $modSettings['cumulus_tcolor2'] : '000099';
	$modSettings['cumulus_hicolor'] = !empty($modSettings['cumulus_hicolor']) ? $modSettings['cumulus_hicolor'] : 'ff0000';
	$modSettings['cumulus_tspeed']  = !empty($modSettings['cumulus_tspeed']) ? $modSettings['cumulus_tspeed'] : 0;
	$modSettings['cumulus_maxfont'] = !empty($modSettings['cumulus_maxfont']) ? $modSettings['cumulus_maxfont'] : 32;
	$modSettings['cumulus_minfont'] = !empty($modSettings['cumulus_minfont']) ? $modSettings['cumulus_minfont'] : 22;
	$modSettings['cumulus_scale'] = !empty($modSettings['cumulus_scale']) ? $modSettings['cumulus_scale'] : 50;

	if (file_exists($boarddir . '/SSI.php'))
		require_once($boarddir . '/SSI.php');
	else
		return '<div class="information error">' . $txt['cumulus_ssi_not_found'] . '</div>';
	
	// Number of topics to display
	$num = $modSettings['cumulus_count'];

	if (!empty($modSettings['cumulus_ignoreboards']))
	{
		global $scripturl;
		
		$ignore_boards = explode(",", preg_replace("/[^0-9,]/", "", $modSettings['cumulus_ignoreboards']));
		foreach ($ignore_boards as $key => $value)
			if ($value == "")
				unset($ignore_boards[$key]);
				
		if (!empty($modSettings['recycle_board']))
			$ignore_boards[] = $modSettings['recycle_board'];
	
		$request = $smcFunc['db_query']('', '
			SELECT t.id_topic
			FROM {db_prefix}boards AS b
				INNER JOIN {db_prefix}topics AS t ON (b.id_board = t.id_board)
			WHERE t.id_board NOT IN ({array_int:ignore_boards})
				AND {query_wanna_see_board}
				AND {query_see_board}
			ORDER BY t.id_topic DESC
			LIMIT {int:limit}',
			array(
				'ignore_boards' => $ignore_boards,
				'limit' => $num,
			)
		);
		
		$id_topics = array();
		while ($row = $smcFunc['db_fetch_assoc']($request))
			$id_topics[] = $row['id_topic'];

		$smcFunc['db_free_result']($request);

		$request = $smcFunc['db_query']('', '
			SELECT m.subject, t.num_views, t.num_replies, t.id_topic
			FROM {db_prefix}topics AS t
				INNER JOIN {db_prefix}messages AS m ON (m.id_msg = t.id_first_msg)
			WHERE t.id_topic IN ({array_int:topic_list})
			LIMIT {int:limit}',
			array(
				'topic_list' => $id_topics,
				'limit' => $num,
			)
		);
		$topics = array();
		while ($row = $smcFunc['db_fetch_assoc']($request))
		{
			censorText($row['subject']);

			if (!empty($modSettings['cumulus_variant']))
			{
				if (!empty($row['num_replies']))
					$topics[] = array(
						'id' => $row['id_topic'],
						'subject' => $row['subject'],
						'num_replies' => $row['num_replies'],
						'num_views' => $row['num_views'],
						'href' => $scripturl . '?topic=' . $row['id_topic'] . '.0',
					);
			}
			else
			{
				if (!empty($row['num_views']))
					$topics[] = array(
						'id' => $row['id_topic'],
						'subject' => $row['subject'],
						'num_replies' => $row['num_replies'],
						'num_views' => $row['num_views'],
						'href' => $scripturl . '?topic=' . $row['id_topic'] . '.0',
					);
			}
		}
		$smcFunc['db_free_result']($request);
	}
	else
	{
		$topics = !empty($modSettings['cumulus_variant']) ? ssi_topTopicsReplies($num, 'array') : ssi_topTopicsViews($num, 'array');
	}
	
	$urls = $tc_urls = array();

	foreach ($topics as $topic)
	{
		$size = $topic['num_views'];
		if ($size < $modSettings['cumulus_minfont']) $size = $modSettings['cumulus_minfont'];
		if ($size > $modSettings['cumulus_maxfont']) $size = $modSettings['cumulus_maxfont'];
		$subject = $context['character_set'] != 'UTF-8' ? iconv($db_character_set, "UTF-8", $topic['subject']) : $topic['subject'];
		$urls[] = '<a href="' . $topic['href'] . '" style="' . $size . '">' . $subject . '</a>';
		$tc_urls[] = '<li><a href="' . $topic['href'] . '">' . $subject . '</a></li>';
	}
	
	$ts = $sourcedir . '/Tags2.php';
	if (!empty($modSettings['cumulus_compat']))
	{
		// Tagging System?
		if ($modSettings['cumulus_compat'] == 1 && file_exists($ts) && isset($txt['smftags_menu']))
		{
			loadLanguage('Tags');
			$urls = $tc_urls = array();
			require_once($ts);
			$txt['cumulus_topics'] = $txt['cumulus_tags'];
			
			if (function_exists('ViewTags'))
			{
				ViewTags();
				foreach ($context['tags_topics'] as $i => $topic)
				{
					if (!empty($topic['ID_TAG']) && !empty($topic['tag']))
					{
						$tag = $context['character_set'] != 'UTF-8' ? iconv($db_character_set, "UTF-8", $topic['tag']) : $topic['tag'];
						$urls[] = '<a href="' . $scripturl . '?action=tags;tagid=' . $topic['ID_TAG'] . '" style="' . $size . '">' . $tag . '</a>';
						$tc_urls[] = '<li><a href="' . $scripturl . '?action=tags;tagid=' . $topic['ID_TAG'] . '">' . $tag . '</a></li>';
					}
				}
			}
		}

		// Topic Rating Bar?
		if ($modSettings['cumulus_compat'] == 2 && file_exists($sourcedir . '/Subs-TopicRating.php'))
		{
			$urls = $tc_urls = array();
			$txt['cumulus_topics'] = $txt['tr_top_topics'];
			$context['top_rating'] = array();
			$ignore_boards = array();
			
			if (!empty($modSettings['recycle_board']))
				$ignore_boards[] = $modSettings['recycle_board'];
			
			$query = $smcFunc['db_query']('', '
				SELECT tr.id, tr.total_votes, tr.total_value, ms.subject
				FROM {db_prefix}topic_ratings AS tr
					INNER JOIN {db_prefix}topics AS t ON (t.id_topic = tr.id)
					INNER JOIN {db_prefix}messages AS ms ON (ms.id_msg = t.id_first_msg)
					INNER JOIN {db_prefix}boards AS b ON (b.id_board = t.id_board)
				WHERE ' . (!empty($ignore_boards) ? 't.id_board NOT IN ({array_int:ignore_boards}) AND ' : '') . '
					{query_wanna_see_board}
					AND {query_see_board}
				LIMIT {int:limit}',
				array(
					'ignore_boards' => $ignore_boards,
					'limit' => $num
				)
			);
			
			while ($row = $smcFunc['db_fetch_assoc']($query))
			{
				$style = number_format($row['total_value'] / $row['total_votes'], 2) * 10;
				$urls[] = '<a href="' . $scripturl . '?topic=' . $row['id'] . '.0" style="' . $style . '">' . $row['subject'] . '</a>';
				$tc_urls[] = '<li><a href="' . $scripturl . '?topic=' . $row['id'] . '.0">' . $row['subject'] . '</a></li>';
			}
			
			$smcFunc['db_free_result']($query);
		}

		// Simple Classifieds?
		if ($modSettings['cumulus_compat'] == 3 && file_exists($sourcedir . '/Classifieds/Classifieds-Subs.php'))
		{
			$urls = $tc_urls = array();
			$txt['cumulus_topics'] = $txt['popular_classifieds'];
			$size = (int) $modSettings['cumulus_minfont'];
			
			$request = $smcFunc['db_query']('', '
				SELECT id, title, type, num_views, num_comments
				FROM {db_prefix}bbs
				WHERE status = {int:is_approved}
				ORDER BY {raw:order} DESC
				LIMIT {int:limit}',
				array(
					'is_approved' => 1,
					'order' => empty($modSettings['cumulus_variant']) ? 'num_views' : 'num_comments',
					'limit' => (int) $modSettings['cf_recent_items']
				)
			);

			while ($row = $smcFunc['db_fetch_assoc']($request))
			{
				$size = empty($modSettings['cumulus_variant']) ? $row['num_views'] : $row['num_comments'];
				if ($size < $modSettings['cumulus_minfont']) $size = $modSettings['cumulus_minfont'];
				if ($size > $modSettings['cumulus_maxfont']) $size = $modSettings['cumulus_maxfont'];
				$type = '[' . $context['cf_types'][$row['type']] . '] ';
				$urls[] = '<a href="' . $scripturl . '?action=bbs;sa=item;id=' . $row['id'] . '" style="' . $size . '">' . $type . $row['title'] . '</a>';
				$tc_urls[] = '<li><a href="' . $scripturl . '?action=bbs;sa=item;id=' . $row['id'] . '">' . $type . $row['title'] . '</a></li>';
			}

			$smcFunc['db_free_result']($request);
		}
	}
	
	$tags = implode('', array_unique($urls));
	$cumulus = '';
	
	// Top area
	switch ($modSettings['cumulus_style'])
	{

		case 1: // Curve
			$cumulus = '
			<div class="title_barIC">
				<h4 class="titlebg">
					<span class="ie6_header floatleft">
						<img class="icon" src="' . $settings['default_images_url'] . '/tags_cloud.png" alt="' . $txt['cumulus_topics'] . '" />
						' . ($num == 1 ? $txt['cumulus_single'] : $txt['cumulus_topics']) . '
					</span>
				</h4>
			</div>
			<div class="centertext">';
		break;
		
		case 2: // BlocWeb
			$cumulus = '
			<div class="title_bar">
				<h4 class="titlebg">
					' . ($num == 1 ? $txt['cumulus_single'] : $txt['cumulus_topics']) . '
				</h4>
			</div>
		<div class="widgetbox centertext">';
		break;
		
		case 3: // Core
			$cumulus = '
			<div class="infocenter_section">
				<h4 class="titlebg">' . ($num == 1 ? $txt['cumulus_single'] : $txt['cumulus_topics']) . '</h4>
				<div class="windowbg">
					<p class="section">
						<img src="' . $settings['default_images_url'] . '/tags_cloud.png" alt="' . $txt['cumulus_topics'] . '" />
					</p>
					<div class="sectionbody windowbg2 centertext">';
		break;
		
	}
	
	if ($notitle)
		$cumulus = '<div class="centertext">';
	
	$random = rand(1, 1000);
	
	// Output
	if (empty($modSettings['cumulus_type']))
		$cumulus .= '
				<script type="text/javascript" src="' . $settings['default_theme_url'] . '/scripts/swfobject.js"></script>
				<div id="flashcontent' . $random . '">
				' . $txt['cumulus_alert'] . '</div>
				<script type="text/javascript"><!-- // --><![CDATA[
					var cl = new SWFObject("' . $settings['default_theme_url'] . '/scripts/tagcloud.swf", "tagcloud", "100%", "' . $modSettings['cumulus_height'] . '", "9", "#fff");
					cl.addParam("wmode", "transparent");
					cl.addVariable("tcolor", "0x' . $modSettings['cumulus_tcolor'] . '");
					cl.addVariable("tcolor2", "0x' . $modSettings['cumulus_tcolor2'] . '");
					cl.addVariable("hicolor", "0x' . $modSettings['cumulus_hicolor'] . '");
					cl.addVariable("distr", "true");
					cl.addVariable("tspeed", "' . $modSettings['cumulus_tspeed'] . '");
					cl.addVariable("mode", "tags");
					cl.addVariable("tagcloud", "<tags>' . urlencode($tags) . '</tags>");
					cl.write("flashcontent' . $random . '");
				// ]]></script>';
	elseif ($modSettings['cumulus_type'] == 1)
	{
		$cumulus .= '
				<script type="text/javascript" src="' . $settings['default_theme_url'] . '/scripts/swfobject.js"></script>
				<div id="flashcontent' . $random . '">
				<p style="display:none">' . urldecode($tags) . '</p></div>
				<script type="text/javascript"><!-- // --><![CDATA[
					var rnumber = Math.floor(Math.random()*9999999);
					var cl = new SWFObject("' . $settings['default_theme_url'] . '/scripts/tagcloud-poetry.swf?r="+rnumber, "tagcloudflash", "100%", "' . $modSettings['cumulus_height'] . '", "9", "#fff");
					cl.addParam("wmode", "transparent");
					cl.addParam("allowScriptAccess", "always");
					cl.addVariable("tagsize", "' . $modSettings['cumulus_scale'] . '");
					cl.addVariable("mode", "tags");
					cl.addVariable("tagcloud", "<tags>' . urlencode($tags) . '</tags>");
					cl.write("flashcontent' . $random . '");
				// ]]></script>';
	}
	else
		$cumulus .= '
				<!--[if lt IE 9]><script type="text/javascript" src="' . $settings['default_theme_url'] . '/scripts/excanvas.js"></script><![endif]-->
				<script src="' . $settings['default_theme_url'] . '/scripts/tagcanvas.min.js" type="text/javascript"></script>
				<script type="text/javascript">
				  window.onload = function() {
					try {
					  TagCanvas.Start("myCanvas","tags",{
						textColour: "#' . $modSettings['cumulus_tcolor'] . '",
						outlineColour: "#' . $modSettings['cumulus_hicolor'] . '",
						reverse: true,
						depth: 0.8,
						maxSpeed: ' . ($modSettings['cumulus_tspeed'] * 0.001) . ',
						wheelZoom: false
					  });
					} catch(e) {
					  // something went wrong, hide the canvas container
					  document.getElementById("myCanvasContainer").style.display = "none";
					}
				  };
				</script>
				<div id="myCanvasContainer">
					<canvas width="600" height="' . $modSettings['cumulus_height'] . '" id="myCanvas"></canvas>
				</div>
				<div id="tags" style="display: none">
					<ul>' . implode('', array_unique($tc_urls)) . '</ul>
				</div>';
	
	if ($notitle == false)
	{
		// Bottom area
		switch ($modSettings['cumulus_style'])
		{
			case 1: // Curve
				$cumulus .= '
				</div>';
			break;
			
			case 2: // BlocWeb
				$cumulus .= '
			</div>';
			break;
			
			case 3: // Core
				$cumulus .= '
						</div>
					</div>
				</div>';
			break;
		}
	}
	else $cumulus .= '</div>';
	
	return $cumulus;
}

// Modification admin area
function cumulus_admin_area(&$admin_areas)
{
	global $txt;
	
	loadLanguage('Cumulus');
		
	$admin_areas['config']['areas']['modsettings']['subsections']['cumulus'] = array($txt['cumulus_title']);
}

function cumulus_modification(&$subActions)
{
	$subActions['cumulus'] = 'cumulus_settings';
}

function cumulus_buffer(&$buffer)
{
	global $txt, $options, $modSettings;
	
	loadLanguage('Cumulus');
	
	$search = '<div id="upshrinkHeaderIC"' . (empty($options['collapse_header_ic']) ? '' : ' style="display: none;"') . '>';
	
	if (!empty($modSettings['cumulus_show']) && $modSettings['cumulus_style'] == 2)
	{
		$search = '<div id="infoc"' . (empty($options['collapse_header_ic']) ? '' : ' style="display: none;"') . '>';
	}
	
	$default = $search . (!empty($modSettings['cumulus_show']) ? cumulus(false) : '');
	$replace = $default;
	
	return (isset($_REQUEST['xml']) ? $buffer : str_replace($search, $replace, $buffer));
}

// Modification page settings
function cumulus_settings()
{
	global $context, $txt, $scripturl, $settings, $modSettings, $db_character_set;
	
	loadLanguage('Cumulus');
	
	$context['page_title'] = $txt['cumulus_title'];
	$context['settings_title'] = $txt['mods_cat_features'];
	$context['post_url'] = $scripturl . '?action=admin;area=modsettings;save;sa=cumulus';
	$context[$context['admin_menu_name']]['tab_data']['tabs']['cumulus'] = array('description' => $txt['cumulus_desc']);
	
	$watch = '<img src="' . $settings['images_url'] . '/warning_watch.gif" alt="" />';
	$mute  = '<img src="' . $settings['images_url'] . '/warning_mute.gif" alt="" />';
	
	$config_vars = array(
		array('check', 'cumulus_show', 'postinput' => !empty($modSettings['cumulus_show']) ? $watch : $mute, 'help' => $txt['cumulus_show_help']),
		array('select', 'cumulus_type', $txt['cumulus_cloud_types']),
		array('select', 'cumulus_compat', $txt['cumulus_compat_mods'])
	);
		
	if (empty($modSettings['cumulus_compat']))
	{
		$config_vars[] = array('text', 'cumulus_ignoreboards', '6" style="width: 30%');
		$config_vars[] = array('select', 'cumulus_variant', $txt['cumulus_variants']);
		$config_vars[] = array('int', 'cumulus_count');
	}
	
	if (!empty($modSettings['cumulus_compat']) && $modSettings['cumulus_compat'] == 3)
	{
		$txt['cumulus_variants'] = $txt['cumulus_variants_for_sc'];
		$config_vars[] = array('select', 'cumulus_variant', $txt['cumulus_variants']);
	}
		
	$config_vars[] = array('select', 'cumulus_style', $txt['cumulus_styles']);
	$config_vars[] = array('int', 'cumulus_height', 'postinput' => 'px');
	$config_vars[] = array('text', 'cumulus_tcolor', 6, 'preinput' => '#', 'postinput' => $txt['cumulus_number_postfix']);
	$config_vars[] = array('text', 'cumulus_tcolor2', 6, 'preinput' => '#', 'postinput' => $txt['cumulus_number_postfix']);
	$config_vars[] = array('text', 'cumulus_hicolor', 6, 'preinput' => '#', 'postinput' => $txt['cumulus_number_postfix']);
	$config_vars[] = array('int', 'cumulus_tspeed');
	$config_vars[] = array('int', 'cumulus_maxfont', 'postinput' => 'pt');
	$config_vars[] = array('int', 'cumulus_minfont', 'postinput' => 'pt');
	
	if (!empty($modSettings['cumulus_type']))
		$config_vars[] = array('int', 'cumulus_scale', 'postinput' => '%');
	
	// Saving?
	if (isset($_GET['save']))
	{
		checkSession();
		saveDBSettings($config_vars);
		redirectexit('action=admin;area=modsettings;sa=cumulus');
	}
	
	prepareDBSettingContext($config_vars);
}

?>