<?php
/*  Copyright 2011 Michael Oestergaard Pedersen

    This file is part of Users Online Today Mod.

    Users Online Today Mod is free software: you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the License,
    or (at your option) any later version.

    Users Online Today Mod is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License along
    with Users Online Today Mod.  If not, see <http://www.gnu.org/licenses/>.
*/

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

global $modSettings;

// Add configuration settings to the database
$uot_variables = array(
			array('name' => 'uot_setting_sortby', 'value' => 'login_time'),
			array('name' => 'uot_setting_sortorder', 'value' => 'descending'),
			array('name' => 'uot_setting_period', 'value' => 'current_day'),
			array('name' => 'uot_setting_canview', 'value' => 'registered')
		);

foreach ($uot_variables as $uot_var)
	if (empty($modSettings[$uot_var['name']]))
		updateSettings(array($uot_var['name'] => $uot_var['value']), false); 

// Add the integration hooks needed by this mod
add_integration_function('integrate_pre_include', '$sourcedir/Subs-UsersOnlineToday.php',TRUE);
add_integration_function('integrate_general_mod_settings','UsersOnlineToday_settings',TRUE);

if (SMF == 'SSI')
	echo 'Installation successful!';

?>
