<?php
/*  Copyright 2011 Michael Oestergaard Pedersen

    This file is part of Users Online Today Mod.

    Users Online Today Mod is free software: you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the License,
    or (at your option) any later version.

    Users Online Today Mod is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License along
    with Users Online Today Mod.  If not, see <http://www.gnu.org/licenses/>.
*/

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot uninstall - please verify you put this in the same place as SMF\'s index.php.');

global $smcFunc, $modSettings;

$uot_variables = array('uot_setting_sortby', 'uot_setting_sortorder', 'uot_setting_period', 'uot_setting_canview');

// Remove settings from database
foreach ($uot_variables as $uot_var)
	$smcFunc['db_query']('','
		DELETE FROM {db_prefix}settings
		WHERE variable = {string:uot_variable}',
		array(
			'uot_variable' => $uot_var,
		)
	);

// Remove variables from modSettings
foreach ($uot_variables as $uot_var)
	if (isset($modSettings[$uot_var]))
		unset($modSettings[$uot_var]); 

// Tell SMF that we have updated $modSettings
updateSettings(array(
	'settings_updated' => time(),
)); 

if (SMF == 'SSI')
	echo 'Uninstallation successful!';

?>
