[center][img]http://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Cc-by_new_white.svg/25px-Cc-by_new_white.svg.png[/img] [img]http://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Cc-nc_white.svg/25px-Cc-nc_white.svg.png[/img] [img]http://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/Cc-nd_white.svg/25px-Cc-nd_white.svg.png[/img][hr][color=red][size=16pt][b]Cumulus Congestus[/b][/size][/color]
[color=blue][b][size=10pt]By Bugo[/size][/b][/color]

[color=green]This mod allows you to display block of popular topics on Board Index of your forum.[/color]
This block based on [url=http://wordpress.org/extend/plugins/wp-cumulus/]WP-Cumulus[/url] plugin for Wordpress.[/center][hr]This work is licensed under a [url=http://creativecommons.org/licenses/by-nc-nd/3.0/]CC BY-NC-ND[/url]