<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')) 
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	exit('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

$hooks = array(
	'integrate_pre_include' => '$boarddir/Sources/Subs-Cumulus.php',
	'integrate_admin_areas' => 'cumulus_admin_area',
	'integrate_modify_modifications' => 'cumulus_modification',
	'integrate_buffer' => 'cumulus_buffer'
);

if (!empty($context['uninstalling']))
	$call = 'remove_integration_function';
else
	$call = 'add_integration_function';

foreach ($hooks as $hook => $function)
	$call($hook, $function);
	
$mod_settings = array(
	'cumulus_show' => true,
	'cumulus_boards' => '',
	'cumulus_variant' => 1,
	'cumulus_count' => 15,
	'cumulus_style' => 1,
	'cumulus_width' => 400,
	'cumulus_height' => 150,
	'cumulus_bgcolor' => 'E9EBEC',
	'cumulus_bgtrans' => true,
	'cumulus_tcolor' => '000000',
	'cumulus_tcolor2' => '000099',
	'cumulus_hicolor' => 'ff0000',
	'cumulus_maxfont' => '22',
	'cumulus_minfont' => '8',
	'cumulus_tspeed' => 60,
	'cumulus_distr' => true,
	'cumulus_cyrillic' => false
);

foreach ($mod_settings as $option => $value)
	if (!isset($modSettings[$option])) updateSettings(array($option => $value));
	
if (SMF == 'SSI')
	echo 'Database changes are complete! Please wait...';

?>