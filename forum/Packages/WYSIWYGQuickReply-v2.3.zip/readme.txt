[center][hr][color=blue][size=16pt][b]WYSIWYG Quick Reply[/b][/size][size=8pt][b] v2.3[/b][/size][/color]
[url=http://custom.simplemachines.org/mods/index.php?action=profile;u=259685][b]~{By PaulpBaker}~[/b][/url]
[size=7pt](Based on Karl Benson's code)[/size]
[hr][b][url=http://custom.simplemachines.org/mods/index.php?mod=1299]Link to Mod[/url][/b] | [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=259685][b]My Mods[/b][/url] | [b][url=http://www.simplemachines.org/community/index.php?topic=251436.0]Support Topic[/url][/b][hr][/center]

[color=blue][b][size=12pt][u]Compatibility[/u][/size][/b][/color]
SMF 2.0

[color=blue][b][size=12pt][u]Description[/u][/size][/b][/color]
Allows for a WYSIWYG quick reply (tieing into per-user options so they can decide whether they want with/without bbcodes and smilies.)

Have some suggestions to make this mod better? Please let me know in the support topic.

[color=blue][b][size=12pt][u]Features[/u][/size][/b][/color]

- Puts SMF 2.x WYSIWYG onto quick reply
- 6 Modes to select your preferred from
- WYSIWYG (with bbc buttons and smilies)
- WYSIWYG (with smilies only) (see note)
- WYSIWYG Only
- Non-WYSIWYG (with bbc buttons and smilies)
- Non-WYSIWYG (with smilies only) (see note)
- Non-WYSIWYG (standard)
- Per user configurable option (set via Profile > Look and Layout)
- Forum-Wide default settable (set via Admin > Current Theme > Member Options)
- For both these links;
  > Configure guest and new user options for this theme
  > Change current options for all members using this theme
- If user nor admin has set the option, it will default to showing the WYSIWYG with bbc buttons and smilies
- Quick reply must be enabled for it to show. [SMF Default setting]
- Supports Languages
- English/English-utf8
- English_British/English_British-utf8
- Brazilian/Brazilian-utf8 support (Thanks to Joomlamz)
- Portuguese/Portuguese-utf8 support (Thanks to Joomlamz)
- Polish/Polish-utf8 support (Thanks to ccbtimewiz)
- Turkish/Turkish-utf8 support (Thanks to [Burak])
- Russian/Russian-utf8 support (Thanks to Bugo)

[color=blue][b][size=12pt][u]Installation[/u][/size][/b][/color]
Any previous versions of this mod MUST be uninstalled BEFORE installing this version.

Install the package on the SMF Default 'Curve' Theme ONLY. Other themes will need manual edits.

[b]Useful Links[/b]
[url=http://sleepycode.com/PackageParser/]SMF Package Parser[/url]
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]

[color=blue][b][size=12pt][u]Support[/u][/size][/b][/color]
Please use the modification thread for support with this modification.
(Please don't ask me to do the edits for you)

[color=blue][b][size=12pt][u]Changelog[/u][/size][/b][/color]
[b]v2.3 - 25th February 2011:[/b] Fixed the quick reply bug again for rc4/rc5 thanks to Bugo
[b]v2.1 - 26th March 2010:[/b] Fixed the 'oEditorHandle' bug (Quote not working on quick reply)
[b]v2.0 - 15th March 2010:[/b] Fixed for RC3