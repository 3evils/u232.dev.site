This mod will add a Reinstall and Delete link to the page that appears after the mod is uninstalled.
Similarly a Uninstall link is added to page which appears after mod is installed .

This enables you to remove and re-install mods quickly.