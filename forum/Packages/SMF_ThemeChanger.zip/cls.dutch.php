<?php
//Last modified: 2012/04/16

// Important! Before editing these language files please read the text at the top of index.english.php.

//Start ClickSafe Menu strings
  $txt['cls-head'] = 'Verander het Thema';
  $txt['cls_title'] = 'ClickSafe Thema-wisselaar';
  $txt['change_theme_check_top'] = 'Plaats Bovenaan';
  $txt['change_theme_check_bot'] = 'Plaats Onderaan<p style="height:150px; margin-top:30px; margin-left:150px;"><a href="http://smf.klikveilig.be/" target="_new" title="ClickSafe Support"><img src="http://smf.klikveilig.be/cgi-bin/support.png"></a><br />English support</p>';
//End ClickSafe Menu strings
?>