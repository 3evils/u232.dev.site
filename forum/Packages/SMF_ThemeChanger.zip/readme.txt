[center][size=16pt][font=tahoma][b][color=#006666]ClickSafe SMF Theme Changer 1.0.1[/color][/b][/font][/size][/center]

[b]Features:[/b]

This mod places a top and/or bottom selection module for SMF themes.
In this way you can easily select any theme.

[img]http://smf.klikveilig.be/cgi-bin/pro-theme-changer-small.png[/img]

Visit [url=http://smf.klikveilig.be][size=11pt][font=tahoma][b][color=#006666]smf.klikveilig.be[/color][/b][/font][/size][/url] for official support. 



