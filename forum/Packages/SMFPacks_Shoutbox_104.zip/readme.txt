[center][color=green][size=18pt]SMFPacks Shoutbox v1.0.4 - NIBOGO[/size][/color]
[color=green]Powerful Shoutbox Mod fully integrated and fully customizable with SMF with a lot of great features!
[/color][/center]
[hr]
[center][url=http://www.smfpacks.com][b]Website[/b][/url] |� [url=http://www.smfpacks.com/donate.php][b]Donate[/b][/url] | [url=http://custom.simplemachines.org/mods/index.php?action=search;author=126412][b]My Mods[/b][/url] | [url=http://custom.simplemachines.org/mods/index.php?mod=1295][b]Link to Mod[/b][/url]
[/center]
[hr]

[b]Important Info[/b]:
o This Mod was created by SMFPacks.com - The #1 Website for the Customization of your SMF.

SMFPacks.com Provides Other Great Packages:
- Reason for Editing Mod.
- Yet Another Global Announcements Mod.
- SMF Social Groups.
- SMF Links Directory.
- SMF Downloads Directory.
- SMF Dynamic Directory.
- Advanced Topic Prefix Mod.
- Advanced Invitations System.
- SMFPacks Shoutbox.
- Move Topic Notification.
- PM to New Members.
- Permissions Info.
- Next Post Level.
- Karma Buttons.
- SMF Multi Quote.
- Attachments in Topics.
- ZuneCard BBCODE.
- and much more visit us on SMFPacks.com

[b]Original Author[/b]:
- makito

[b]Developer:[/b]
- NIBOGO

[b]Features[/b]:
[list]
	[li][i][u]Users[/u][/i]
- Text styles, fonts, colors and backgrounds
- Smileys
- Play sound on new messages
- Disable sound
- /me command
- Auto links converter[/li]
	[li][i][u]Moderators[/u][/i]
- [i]/clear[/i] or [i]/prune[/i] command
- [i][u]Moderation Panel[/u][/i]
�  ~ Edit or delete messages
�  ~ Ban users
�  ~ Message history[/li]
	[li][i][u]Administrators[/u][/i]
- Disable modification
- Auto hide modification
- Disable text features or smileys
- Add or delete font families
- Show new messages at the top or bottom
- Show message box at the top or bottom
- Maximium word's lenght
- Maximium message's lenght
- Minimium message's lenght
- ... and more[/li]
[/list]

[b]Compatibility[/b]:
- 1.1.X
- 2.0

[b]Special Thanks[/b]:
- makito (Original Author of the Mod)
- JCS (Spanish Translator)

[hr]

[size=16px]Changelog:[/size]

[b]1.0.4 - 14 July 2012[/b]
! SSL Links weren't converted property
! IE9 Issues

[b]1.0.3 - 30 June 2011[/b]
! Fixed Moderation actions in pages different than 1. (Thanks to KeeKee for the fix)
! Auto focus on page load.
! Users could be logged while using the shoutbox.
! Shouts with ' couldn't be modified. (Thanks to Akyhne for the fix)

[b]1.0.2 - 29 June 2011[/b]
@ Updated for SMF 2.0