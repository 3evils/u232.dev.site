<?php
 
if (!defined('SMF')) {
	if(file_exists(dirname(__FILE__) . '/SSI.php'))
		include_once(dirname(__FILE__) . '/SSI.php');
	else
		die('<strong>Error</strong>: Please make sure you have SSI.php in your root directory.');
}
 
global $db_prefix, $smcFunc;
db_extend('packages');

$column = array(
	'name' => 'annoyuser',
	'type' => 'tinyint',
	'size' => 3,
	'null' => false,
	'default' => 0,
);
		
$smcFunc['db_add_column']('{db_prefix}members', $column);

?>