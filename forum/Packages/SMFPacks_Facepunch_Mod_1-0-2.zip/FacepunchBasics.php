<?php
/**********************************************************************************
* FacepunchBasics.php															  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro v1.0											  	  	  *
* Copyright (c) 2013 by SMFPacks.com. All rights reserved.					 	  *
* Powered by www.smfpacks.com													  *
* Created by NIBOGO for SMFPacks.com											  *
*																				  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro IS NOT FREE SOFTWARE								  	  *
* THIS ONLY CAN BE USED WITH A VALID LICENCE THAT CAN BE BOUGHT AT SMFPacks.com	  *
* YOU CANNOT REMOVE THE COPYRIGHT EITHER UNLESS YOU PURCHASED THE				  *
* COPYRIGHT FREE VERSION AT SMFPacks.com										  *
*																				  *
**********************************************************************************/
	
	loadLanguage('Facepunch');
	
function rates_in_stats()
{
	global $txt, $scripturl, $modSettings, $user_info, $context, $smcFunc;
	
	if (!empty($modSettings['rates_stats']))
	{
		if (($members = cache_get_data('stats_top_rated_users', 360)) == null)
		{
			$request = $smcFunc['db_query']('', '
				SELECT id_member, rated
				FROM {db_prefix}members
				ORDER BY rated DESC
				LIMIT 10',
				array(
				)
			);
			$members = array();
			while ($row = $smcFunc['db_fetch_assoc']($request))
				$members[$row['id_member']] = $row['rated'];
			$smcFunc['db_free_result']($request);
	
			cache_put_data('stats_top_rated_users', $members, 360);
		}
	
		if (empty($members))
			$members = array(0 => 0);
	
		// Top 10 Rated Users
		$members_result = $smcFunc['db_query']('', '
			SELECT id_member, real_name, rated
			FROM {db_prefix}members
			WHERE id_member IN ({array_int:member_list})
			ORDER BY FIND_IN_SET(id_member, {string:top_topic_posters})
			LIMIT 10',
			array(
				'member_list' => array_keys($members),
				'top_topic_posters' => implode(',', array_keys($members)),
			)
		);
		$context['top_rated_users'] = array();
		$max_num_rated = 1;
		while ($row_members = $smcFunc['db_fetch_assoc']($members_result))
		{
			$context['top_rated_users'][] = array(
				'name' => $row_members['real_name'],
				'id' => $row_members['id_member'],
				'num_posts' => $row_members['rated'],
				'href' => $scripturl . '?action=profile;u=' . $row_members['id_member'],
				'link' => '<a href="' . $scripturl . '?action=profile;u=' . $row_members['id_member'] . '">' . $row_members['real_name'] . '</a>'
			);
	
			if ($max_num_rated < $row_members['rated'])
				$max_num_rated = $row_members['rated'];
		}
		$smcFunc['db_free_result']($members_result);
	
		foreach ($context['top_rated_users'] as $i => $member)
		{
			$context['top_rated_users'][$i]['post_percent'] = round(($member['num_posts'] * 100) / $max_num_rated);
			$context['top_rated_users'][$i]['num_posts'] = $member['num_posts'];
		}
		
		if (($members = cache_get_data('stats_top_rated_topics', 360)) == null)
		{
			$request = $smcFunc['db_query']('', '
				SELECT t.id_topic, t.rates
				FROM {db_prefix}topics AS t
					LEFT JOIN {db_prefix}boards AS b ON (t.id_board = b.id_board)
				WHERE {query_see_board}
				ORDER BY t.rates DESC
				LIMIT 10',
				array(
				)
			);
			$topics = array();
			while ($row = $smcFunc['db_fetch_assoc']($request))
				$topics[$row['id_topic']] = $row['rates'];
			$smcFunc['db_free_result']($request);
	
			cache_put_data('stats_top_rated_topics', $members, 360);
		}
	
		if (empty($topics))
			$topics = array(0 => 0);
	
		// Top 10 Rated Topics
		$topics_rated = $smcFunc['db_query']('', '
			SELECT t.id_topic, m.subject, t.rates
			FROM {db_prefix}topics AS t
				LEFT JOIN {db_prefix}messages AS m ON (m.id_msg = t.id_first_msg)
			WHERE t.id_topic IN ({array_int:member_list})
			ORDER BY FIND_IN_SET(t.id_topic, {string:top_topic_posters})
			LIMIT 10',
			array(
				'member_list' => array_keys($topics),
				'top_topic_posters' => implode(',', array_keys($topics)),
			)
		);
		$context['top_rated_topics'] = array();
		$max_num_rated = 1;
		while ($row_members = $smcFunc['db_fetch_assoc']($topics_rated))
		{
			$context['top_rated_topics'][] = array(
				'id' => $row_members['id_topic'],
				'num_posts' => $row_members['rates'],
				'link' => '<a href="' . $scripturl . '?topic=' . $row_members['id_topic'] . '.0">' . $row_members['subject'] . '</a>'
			);
	
			if ($max_num_rated < $row_members['rates'])
				$max_num_rated = $row_members['rates'];
		}
		$smcFunc['db_free_result']($topics_rated);
	
		foreach ($context['top_rated_topics'] as $i => $t)
		{
			$context['top_rated_topics'][$i]['post_percent'] = round(($t['num_posts'] * 100) / $max_num_rated);
			$context['top_rated_topics'][$i]['num_posts'] = $t['num_posts'];
		}
	}
}
	
function rates_add_actions(&$actionArray)
{
	$actionArray['rate'] = array('Facepunch.php', 'Rate');
	$actionArray['removerate'] = array('Facepunch.php', 'RemoveRate');
	$actionArray['viewrates'] = array('Facepunch.php', 'ViewFacepunch');
	$actionArray['getratebar'] = array('Subs-Facepunch.php', 'GetFacepunchBar');
	
	// Load stats if possible!
	if (isset($_GET['action']) && $_GET['action'] === 'stats')
		rates_in_stats();
}

function rates_admin_areas($admin_areas)
{
	global $txt;
	
	$temp = array();
	foreach ($admin_areas['config']['areas'] as $id => $area)
	{
		$temp[$id] = $area;
		
		if ($id == 'serversettings')
			$temp['rates'] = array(
					'label' => $txt['rates'],
					'file' => 'FacepunchAdmin.php',
					'function' => 'FacepunchAdmin',
					'icon' => 'rate.png',
					'subsections' => array(
						'settings' => array($txt['rates_settings']),
						'boards' => array($txt['rates_boards']),
						'permissions' => array($txt['rates_permissions']),
						'types' => array($txt['rates_types']),
						'add_type' => array($txt['rates_add_type']),
					),
				);
	}
	$admin_areas['config']['areas'] = $temp;
	unset($temp);
}

function rates_add_permissions(&$permissionGroups, &$permissionList, &$leftPermissionGroups, &$hiddenPermissions, &$relabelPermissions)
{
	$permissionList['membergroup']['can_see_rates'] = array(false, 'topic', 'moderate');
	$permissionList['membergroup']['can_own_rate'] = array(false, 'topic', 'moderate');
	$permissionList['membergroup']['can_multiple_rates'] = array(false, 'topic', 'moderate');
}

function rates_profile_areas(&$profile_areas)
{
	global $modSettings, $txt, $context;
	
	if (empty($modSettings['rates_show_rated_posts']))
		return;
	
	$profile_areas['rates'] = array(
		'title' => $txt['rates'],
		'areas' => array(
			'given_rates' => array(
				'file' => 'Subs-Facepunch.php',
				'function' => 'ratesInProfile',
				'label' => $txt['rates_given'],
				'permission' => array(
					'own' => array('profile_view_own'),
					'any' => array('profile_view_any'),
				),
			),
			'received_rates' => array(
				'file' => 'Subs-Facepunch.php',
				'function' => 'ratesInProfile',
				'label' => $txt['rates_received'],
				'permission' => array(
					'own' => array('profile_view_own'),
					'any' => array('profile_view_any'),
				),
			),
		),
	);
}

// Redirect to the function that should take of this!
function rates_remove_member($members)
{
	global $sourcedir;
	
	require_once($sourcedir . '/Subs-Facepunch.php');
	ratesRemoveMember($members);
}

function rates_buttons(&$normal_buttons)
{
	global $board_info, $context, $modSettings, $scripturl, $settings, $txt, $topicinfo, $smcFunc;
	
	if (!empty($modSettings['rates_show_total']) && empty($board_info['only_rate_first']) && allowedTo('can_see_rates'))
	{
		echo 
			'<div id="box_total_rates" class="rates_box">', (empty($modSettings['rates_hide_total_list']) ? '<a href="' . $scripturl . '?action=viewrates;topic=' . $context['current_topic'] . '" rel="facebox">' : ''), '<img src="', $settings['images_url'], '/admin/rate.png" alt="', $txt['rates'], '" /> <span id="total_topic_rates">', $topicinfo['rates'], '</span> ', $txt['rates'], '', (empty($modSettings['rates_hide_total_list']) ? '</a>' : ''), '</div>
	    <br class="clear" />';
    }
}

function rates_return_total($rates, $negative_rates, $id_member)
{
	global $modSettings, $txt;
	
	// It is +2 / -5
	if (!empty($modSettings['rates_show_as']) && $modSettings['rates_show_as'] == 1)
	{
		return '<span class="member_rates_status_' . $id_member . '"><span style="color: green;">+' . $rates . '</span> / <span style="color: red;">-' . $negative_rates . '</span></span>';
	}
	// Or the green and red bar?
	else if (!empty($modSettings['rates_show_as']) && $modSettings['rates_show_as'] == 2)
	{
		$rates_total = $rates + $negative_rates;
		
		if ($rates_total == 0)
			return '<span class="member_rates_status_' . $id_member . '"><div style="border: 1px solid #000; width: 90%; height: 10px; max-width: 100px;" title="' . $txt['rates_no_members'] . '">
					<div style="background-color: grey; width: 100%; float: left; display: block; height: 10px;"></div>
				</div></span>';
		
		$possitive_width = (100 / $rates_total) * $rates;
		
		return '<span class="member_rates_status_' . $id_member . '"><div style="border: 1px solid #000; width: 90%; height: 10px; max-width: 100px;">
					<div title="' . sprintf($txt['rates_possitive_received'], $rates) . '" style="background-color: green; width: ' . $possitive_width . '%; float: left; display: block; height: 10px;"></div><div style="background-color: red; width: ' . (100 - $possitive_width) . '%; float: right; display: block; height: 10px;" title="' . sprintf($txt['rates_negative_received'], $negative_rates) . '"></div>
				</div></span>';
	}
	
	// Just show the total with the right symbol and color
	$rates = $rates - $negative_rates;
	
	if (empty($rates))
		return '<span class="member_rates_status_' . $id_member . '">0</span>';
		
	$color = ($rates > 0) ? 'green' : 'red';
	$symbol = ($rates > 0) ? '+' : '';
	return '<span class="member_rates_status_' . $id_member . '"><span style="color: ' . $color . ';">' . $symbol . $rates . '</span></span>';
}

function rates_box(&$output, $total_rates)
{
	global $topic, $smcFunc, $context, $user_info, $board, $topicinfo, $boardurl, $scripturl, $modSettings, $txt, $board_info, $sourcedir;
	
	// First load everything!
	if (!isset($context['load_rates']))
	{
		require_once($sourcedir . '/Subs-Facepunch.php');
		rates_in_topic();
	}
	
	if (isset($output['member']['custom_fields'][-1]))
		unset($output['member']['custom_fields'][-1]);
		
	// Show how many posts they had been rated
	if (!empty($modSettings['rates_show_rated']))
	{
		unset($output['member']['custom_fields'][-2]);
		
		if (isset($output['member']['rated']))
			$output['member']['custom_fields'][-2] = array('title' => $txt['rates_show_messages'], 'value' => $output['member']['rated'], 'placement' => 0);
	}
	
	if (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] == $board)
		return;
		
	if (!empty($board_info['only_rate_first']) && $output['id'] != $topicinfo['id_first_msg'])
		return;
	
	if (!allowedTo('can_see_rates'))
		return;
	
	// First load everything!
	rates_load_context_info();
	
	// Start building our magic box!
	$magic_box = '<div class="rate_post' . (!empty($modSettings['rates_show_opacity']) ? ' transparency_rates' : '') . '" id="list_of_rates_' . $output['id'] . '">' . build_magic_box($output['id'], false, $output['member']['id']) . '</div>';
	$output['member']['custom_fields'][-1] = array('placement' => 2, 'value' => $magic_box);
	
	if (isset($modSettings['rates_hide']) && $modSettings['rates_hide'] >= $total_rates)
	{
		$co = !empty($modSettings['rates_hide_message']) && trim($modSettings['rates_hide_message']) != '' ? $modSettings['rates_hide_message'] : $txt['rates_default_message'];
		$output['body'] = '<span id="hidden_' . $output['id'] . '">' . $co . ' <a href="javascript:void(0);" onclick="document.getElementById(\'hidden_' . $output['id'] . '\').style.display = \'none\'; document.getElementById(\'body_' . $output['id'] . '\').style.display = \'\'; return false;">' . $txt['rates_show_message'] . '</a></span><div style="display: none;" id="body_' . $output['id'] . '">' . $output['body'] . '</div>';
	}
}

// This is the Facepunch box including the number of rates in each post!
function build_magic_box($id_msg, $is_ajax, $author)
{
	global $topic, $smcFunc, $context, $user_info, $board, $topicinfo, $boardurl, $scripturl, $modSettings, $txt;
	
	// Load all the relevant information
	rates_load_context_info($is_ajax ? $id_msg : null);
	
	// If it is ajax then we should know which is the first msg
	$topicinfo['id_first_msg'] = isset($_GET['first']) && is_numeric($_GET['first']) ? $_GET['first'] : $topicinfo['id_first_msg'];
	
	// Start building our magic box!
	$magic_box = '';
	$id = 0;
	$total_counter = 0;
	$there_are_rates_in_this_post = false;
	foreach ($context['types'] as $id_type => $data)
	{
		$id++;
		
		if ($topicinfo['id_first_msg'] != $id_msg && !empty($data['only_first_post']))
			continue;
		
		$number = 0;
		$voted = false;			
		$style = 'font-size: 10px;';
		if (isset($context['rates_totals'][$id_msg][$id_type]) && !empty($context['rates_totals'][$id_msg][$id_type]))
		{
			if (in_array($user_info['id'], $context['rates_totals'][$id_msg][$id_type]))
			{
				$style .= ' font-weight: bold;';
				$voted = true;
			}
			
			$number = count($context['rates_totals'][$id_msg][$id_type]);
			$total_counter += ($number * $context['types'][$id_type]['post_value']);
			$there_are_rates_in_this_post = true;
		}
		
		if ($voted)
			$data['post_value'] = $data['post_value'] * -1;
		
		if ($data['cannot_rate'] == false)
			$magic_box .= '<a href="' . $scripturl . '?action=rate;topic=' . $topic . '.0;msg=' . $id_msg . ';type=' . $id_type . ';' . $context['session_var'] . '=' . $context['session_id'] . '"' . (!empty($modSettings['rates_with_ajax']) ? ' onclick="return rate(\'' . $id_msg . '\', \'' . $id_type . '\', \'' . $author . '\', \'' . $data['post_value'] . '\');"' : ''). ' title="' . $data['name'] . '">';
			
		$magic_box .= $data['icon'];
		
		if ($data['cannot_rate'] == false)
			$magic_box .= '</a>';
		
		if ($number > 0)
			$magic_box .= ' <span style="' . $style . '">x ' . $number . '</span>';
			
		if ($id != count($context['types']))
			$magic_box .= '&nbsp;&nbsp;&nbsp;&nbsp;';
	}
	
	if ($total_counter > 0)
		$total_counter = '<span style="color: green;">' . $total_counter . '</span>';
	else if ($total_counter < 0)
		$total_counter = '<span style="color: red;">' . $total_counter . '</span>';
	
	if ($there_are_rates_in_this_post)
		$magic_box .= ' (<a href="' . $scripturl . '?action=viewrates' . ($topicinfo['id_first_msg'] === $id_msg ? ';is' : '') . ';msg=' . $id_msg . ';b=' . $board . '" rel="facebox">' . $txt['rates_list_of_raters'] . '</a> | ' . $total_counter . ' ' . $txt['post'] . ' ' . $txt['total'] . ')';
	
	if ($is_ajax)
		die($magic_box);
	else	
		return $magic_box;
}

// Give us some context!
function rates_load_context_info($id_msg = null)
{
	global $topic, $smcFunc, $context, $user_info, $board, $topicinfo, $boardurl, $scripturl;

	if (!isset($context['types']))
	{
	    $dbresult = $smcFunc['db_query']('', '
		SELECT 
			id_type, icon, only_first_post, name, permissions, post_value
		FROM {db_prefix}rates_types
		WHERE enabled = 1
			AND (id_boards = 0 OR FIND_IN_SET({int:board}, id_boards))
		ORDER BY custom_order ASC',
			array(
				'board' => $board
			)
		);
	    
		$context['types'] = array();
		while ($row = $smcFunc['db_fetch_assoc']($dbresult))
		{
			$permissions = explode(',',$row['permissions']);
			$context['types'][$row['id_type']] = array(
				'cannot_rate' => count(array_intersect($user_info['groups'], $permissions)) == 0 && $row['permissions'] != 0,
				'id_type' => $row['id_type'],
				'icon' => '<img src="' . $boardurl . '/rates_types/' . $row['icon'] . '" alt="' . $row['name'] . '" class="rates_va" />',
				'only_first_post' => $row['only_first_post'],
				'name' => $row['name'],
				'post_value' => $row['post_value']
			);
		}
		$smcFunc['db_free_result']($dbresult);
	}
	
	// Now take care of each post with one query!
	if (!isset($context['rates_totals']))
	{
		$context['rates_counter'] = 0;
		$dbrequest = $smcFunc['db_query']('', '
			SELECT id_message, id_type, id_member
			FROM {db_prefix}rates
			WHERE ' . ($id_msg === null ? 'id_topic = {int:topic_id}' : 'id_message = {int:msg}'),
			array(
				'topic_id' => $topic,
				'msg' => $id_msg == null ? 0 : $id_msg
			)
		);
		$context['rates_totals'] = array();
	    while($row = $smcFunc['db_fetch_assoc']($dbrequest))
	    {
	    	$context['rates_totals'][$row['id_message']][$row['id_type']][] = $row['id_member'];
	    	
	    	if ($topicinfo['id_first_msg'] != $row['id_message'] && !empty($context['types'][$row['id_type']]['only_first_post']))
	    		continue;
	    		
	    	$context['rates_counter']++;
	    }
		$smcFunc['db_free_result']($dbrequest);
	}
	
	if (!isset($context['rates_counter']))
		$context['rates_counter'] = 0;
}

function rates_buffer($buffer)
{
	// Return buffer! If below code is changed you'd break everything. I do think you'd leave it alone
	return $buffer;
}
?>