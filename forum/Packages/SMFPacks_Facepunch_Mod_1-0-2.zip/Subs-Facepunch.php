<?php
/**********************************************************************************
* Subs-Facepunch.php															  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro v1.0.2											  	  	  *
* Copyright (c) 2013 by SMFPacks.com. All rights reserved.					 	  *
* Powered by www.smfpacks.com													  *
* Created by NIBOGO for SMFPacks.com											  *
*																				  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro IS NOT FREE SOFTWARE								  	  *
* THIS ONLY CAN BE USED WITH A VALID LICENCE THAT CAN BE BOUGHT AT SMFPacks.com	  *
* YOU CANNOT REMOVE THE COPYRIGHT EITHER UNLESS YOU PURCHASED THE				  *
* COPYRIGHT FREE VERSION AT SMFPacks.com										  *
*																				  *
**********************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

function rates_in_topic()
{
	global $context, $settings, $modSettings, $board_info, $topicinfo;
	
	$context['insert_after_template'] .= '
		<script>!window.jQuery && document.write(unescape(\'%3Cscript src="https://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"%3E%3C/script%3E\'))</script>
		<script src="' . $settings['default_theme_url'] . '/scripts/punch_facebox/facebox.js" type="text/javascript"></script>
		<link href="' . $settings['default_theme_url'] . '/scripts/punch_facebox/facebox.css" media="screen" rel="stylesheet" type="text/css" />
		<script type="text/javascript"><!-- // --><![CDATA[
			jQuery(document).ready(function($) {
		      $(\'a[rel*=facebox]\').facebox({
		        loadingImage : \'' . $settings['default_theme_url'] . '/scripts/punch_facebox/loading.gif\',
		        closeImage   : \'' . $settings['default_theme_url'] . '/scripts/punch_facebox/closelabel.png\',
		      })
		    })';
		
	// AJAX Style Thank You Post
	if (!empty($modSettings['rates_with_ajax']))
	{
		$context['insert_after_template'] .= '
			var total_rates_topic = ' . $topicinfo['rates'] . ';
			var only_first_post = ' . (!empty($board_info['only_rate_first']) ? '1' : '0') . ';
			var check_total = ' . (((!empty($topicinfo['rates']) || !empty($modSettings['rates_with_ajax']) ) && !empty($modSettings['rates_show_total']) && empty($board_info['only_rate_first'])) ? '1' : '0') . ';
			function getElementsByClassName(node,classname) {
			  if (node.getElementsByClassName) { // use native implementation if available
			    return node.getElementsByClassName(classname);
			  } else {
			    return (function getElementsByClass(searchClass,node) {
			        if ( node == null )
			          node = document;
			        var classElements = [],
			            els = node.getElementsByTagName("*"),
			            elsLen = els.length,
			            pattern = new RegExp("(^|\\s)"+searchClass+"(\\s|$)"), i, j;
			
			        for (i = 0, j = 0; i < elsLen; i++) {
			          if ( pattern.test(els[i].className) ) {
			              classElements[j] = els[i];
			              j++;
			          }
			        }
			        return classElements;
			    })(classname, node);
			  }
			}

			function rate(msg_id, type, author, post_value) 
			{
				if (!window.XMLHttpRequest)
					return true;
				
				var rate_box = document.getElementById("list_of_rates_" + msg_id);
				
				ajax_indicator(true);
				
				if (!window.XMLHttpRequest)
					return true;
					
				request = new XMLHttpRequest();
				request.onreadystatechange = function() {
					if (request.readyState != 4)
						return;
					else if (request.responseText != null && request.status == 200)
					{
						if (request.responseText.substr(0, 6) != "ERROR:")
						{
							if (only_first_post == 0 && check_total == 1) 
							{
								document.getElementById(\'box_total_rates\').style.display = "";
								total_rates_topic += parseInt(post_value);
								setInnerHTML(document.getElementById(\'total_topic_rates\'), total_rates_topic);
							}
							rate_box.style.display = "";
							setInnerHTML(rate_box, request.responseText);
							
							if (author != 0)
								reCalculateAllMembersRates(author);
						}
						else
							alert( request.responseText.substr(7) );
						
						ajax_indicator(false);
						return true;
					}
					else {
						return false;
					}
				}
				
				// Load the Request!
				var url = ";ajax";					
				url += ";' . $context['session_var'] . '=' . $context['session_id'] . '";
				request.open("GET", smf_scripturl + "?action=rate;topic=' . $context['current_topic'] . ';first=' . $topicinfo['id_first_msg'] . ';type=" + type + ";msg=" + msg_id + url, true);
				request.send(null);
				return !request;
			}
			
			function reCalculateAllMembersRates(author)
			{
				request = new XMLHttpRequest();
				request.onreadystatechange = function() {
					if (request.readyState != 4)
						return;
					else if (request.responseText != null && request.status == 200)
					{
						var elements = getElementsByClassName(document, \'member_rates_status_\' + author);
						for (var i = 0; i < elements.length; i++)
						{
							setOuterHTML(elements[i], request.responseText);
						}
					}
				}
				request.open("GET", smf_scripturl + "?action=getratebar;author=" + author, true);
				request.send(null);
			}';
	}
	
	$context['insert_after_template'] .= '
		// ]]></script>';
		
	// Tell the other function this not more required!
	$context['load_rates'] = 1;
}

function ratesInProfile()
{
	global $txt, $user_info, $scripturl, $modSettings, $user_info;
	global $context, $user_profile, $sourcedir, $smcFunc, $boardurl;
	global $settings;
	
	$memID = isset($_GET['u']) ? (int) $_GET['u'] : $user_info['id'];
	$context['is_given'] = isset($_GET['area']) && $_GET['area'] == 'given_rates' ? true : false;
	$member_join = $context['is_given'] ? 'id_member_received' : 'id_member';
	$context['html_headers'] .= '
	<script>!window.jQuery && document.write(unescape(\'%3Cscript src="https://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"%3E%3C/script%3E\'))</script>
	<script src="' . $settings['default_theme_url'] . '/scripts/punch_facebox/facebox.js" type="text/javascript"></script>
	<link href="' . $settings['default_theme_url'] . '/scripts/punch_facebox/facebox.css" media="screen" rel="stylesheet" type="text/css" />
	<script type="text/javascript"> 
	    jQuery(document).ready(function($) {
	      $(\'a[rel*=facebox]\').facebox({
	        loadingImage : \'' . $settings['default_theme_url'] . '/scripts/punch_facebox/loading.gif\',
	        closeImage   : \'' . $settings['default_theme_url'] . '/scripts/punch_facebox/closelabel.png\',
	      })
	    })
	</script>';

	// Some initial context.
	$context['start'] = (int) $_REQUEST['start'];
	$context['current_member'] = $memID;

	// Create the tabs for the template.
	$context[$context['profile_menu_name']]['tab_data'] = array(
		'title' => $txt['showPosts'],
		'description' => $txt['showPosts_help'],
		'icon' => 'profile_sm.gif',
		'tabs' => array(
			'messages' => array(
			),
			'topics' => array(
			),
			'attach' => array(
			),
		),
	);

	// Set the page title
	$context['page_title'] = ($context['is_given'] ? $txt['rates_given'] : $txt['rates_received']) . ' - ' . $user_profile[$memID]['real_name'];
	
	// Default to 10.
	if (empty($_REQUEST['viewscount']) || !is_numeric($_REQUEST['viewscount']))
		$_REQUEST['viewscount'] = '10';
		
	// Load the ids of the messages we are looking for!
	$search_for = !$context['is_given'] ? 'rates.id_member_received = {int:current_member}' : 'rates.id_member = {int:current_member}';
	
	// Do the count (if required)
	if (!isset($_GET['total']) || !is_numeric($_GET['total']))
	{
		$request = $smcFunc['db_query']('', '
			SELECT COUNT(1) as total
			FROM {db_prefix}rates AS rates
				INNER JOIN {db_prefix}messages AS m ON (m.id_msg = rates.id_message)' . ($user_info['query_see_board'] == '1=1' ? '' : '
				INNER JOIN {db_prefix}boards AS b ON (b.id_board = rates.id_board AND {query_see_board})') . '
			WHERE ' . $search_for . '
				AND m.approved = {int:is_approved}',
			array(
				'current_member' => $memID,
				'is_approved' => 1
			)
		);
		list ($total) = $smcFunc['db_fetch_row']($request);
		$smcFunc['db_free_result']($request);
	}
	else
		$total = $_GET['total'];
	
	$request = $smcFunc['db_query']('', '
		SELECT rates.id_message, rates.id_type, m.body, m.subject, b.name as board_name, rates.id_board, rates.id_topic, t.icon, t.name AS type_name, rates.timestamp, mem.member_name, mem.id_member
		FROM {db_prefix}rates AS rates
			INNER JOIN {db_prefix}rates_types AS t ON (rates.id_type = t.id_type)
			INNER JOIN {db_prefix}messages AS m ON (m.id_msg = rates.id_message)
			INNER JOIN {db_prefix}members AS mem ON (mem.id_member = rates.' . $member_join . ')
			INNER JOIN {db_prefix}boards AS b ON (b.id_board = rates.id_board' . ($user_info['query_see_board'] == '1=1' ? '' : ' AND {query_see_board}') . ')
		WHERE ' . $search_for . '
			AND m.approved = {int:is_approved}
		ORDER BY rates.timestamp DESC
		LIMIT {int:start},10',
		array(
			'current_member' => $memID,
			'is_approved' => 1,
			'start' => $context['start']
		)
	);
	$i = $context['start'] + 1;
	$context['rate_posts'] = array();
	while($row = $smcFunc['db_fetch_assoc']($request))
    {
    	$context['rate_posts'][] = array(
    		'body' => parse_bbc($row['body']),
    		'counter' => $i++,
    		'time' => timeformat($row['timestamp']) . ' ' . ($context['is_given'] ? strtolower($txt['to']) : $txt['by']) . ' <a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '">' . $row['member_name'] . '</a>',
    		'subject' => '<strong><a href="' . $scripturl . '?board=' . $row['id_board'] . '.0">' . $row['board_name'] . '</a></strong> <strong>/</strong> <strong><a href="' . $scripturl . '?topic=' . $row['id_topic'] . '.msg' . $row['id_message'] . '#msg' . $row['id_message'] . '">' . $row['subject'] . '</a></strong> <div class="floatright"><img src="' . $boardurl . '/rates_types/' . $row['icon'] . '" alt="' . $row['type_name'] . '" /> <strong>' . $row['type_name'] .'</strong></div>'
    		
    	);
    }
	$smcFunc['db_free_result']($request);
	
	$context['page_index'] = constructPageIndex($scripturl . '?action=profile;u=' . $memID . ';area=' . ($context['is_given'] ? 'given_rates' : 'received_rates') . ';total=' . $total, $context['start'], $total, 10);
	
	// Templates
	loadTemplate('Facepunch');
}

function GetFacepunchBar()
{
	global $smcFunc;
	
	if (!isset($_GET['author']) || !is_numeric($_GET['author']) || empty($_GET['author']))
		return null;
		
	$author = (int) $_GET['author'];
	
	$dbrequest = $smcFunc['db_query']('', '
		SELECT rated, rated_negative
		FROM {db_prefix}members
		WHERE id_member = {int:author}',
		array(
			'author' => $author,
		)
	);
	
	if ($smcFunc['db_num_rows']($dbrequest) == 0)
		return null;
	
	list($rated, $rated_negative) = $smcFunc['db_fetch_row']($dbrequest);
	$smcFunc['db_free_result']($dbrequest);
	
	die(rates_return_total($rated, $rated_negative, $author));
}

// BELOW FUNCTIONS TAKE CARE OF LIKES DONE ON TOPICS, MESSAGES AND MEMBERS THAT WERE MERGED, MODIFIED OR REMOVED!
function ratesRemoveMessage($message, $member, $topic)
{
	global $smcFunc, $modSettings;
	
	$dbrequest = $smcFunc['db_query']('', '
	SELECT t.post_value, l.id_member_received, l.id_member, l.id_topic
	FROM {db_prefix}rates AS l
		INNER JOIN {db_prefix}rates_types AS t ON (t.id_type = l.id_type)
	WHERE l.id_message = {int:msg}',
		array(
			'msg' => $message
		)
	);
	
	$topic_value = 0;
	while($row = $smcFunc['db_fetch_assoc']($dbrequest))
    {
    	if ($row['post_value'] == 0)
    		continue;
    		
    	$value = $row['post_value'];
    	$topic_value += ($value * -1);
    		
    	if ($row['id_member_received'] != $row['id_member'])
    	{	
    		$search_for = 'rated';
    		if ($row['post_value'] < 0)
    		{
	    		$search_for = 'rated_negative';
	    		$value *= -1;
    		}
    		
	    	$smcFunc['db_query']('', '
			UPDATE {db_prefix}members
			SET ' . $search_for . ' = ' . $search_for . ' - {int:new_rates}
			WHERE id_member = {int:id_member}
			LIMIT 1',
				array(
					'new_rates' => $value,
					'id_member' => $member
				)
			);
		}
    }
	$smcFunc['db_free_result']($dbrequest);
	
	$smcFunc['db_query']('', '
		UPDATE {db_prefix}topics
		SET rates = rates + {int:new_rates}
		WHERE id_topic = {int:topic}
		LIMIT 1',
		array(
			'new_rates' => $topic_value,
			'topic' => $topic
		)
	);
	
	$smcFunc['db_query']('', '
		DELETE FROM {db_prefix}rates
		WHERE id_message = {int:id_msg}',
		array(
			'id_msg' => $message,
		)
	);
}

function reCalculateRatesRemove($topics)
{
	global $smcFunc;
	
	$dbrequest = $smcFunc['db_query']('', '
	SELECT t.post_value, l.id_member_received, l.id_member, l.id_topic
	FROM {db_prefix}rates AS l
		INNER JOIN {db_prefix}rates_types AS t ON (t.id_type = l.id_type)
	WHERE l.id_topic IN ({array_int:topics})',
		array(
			'topics' => $topics
		)
	);
	
	while($row = $smcFunc['db_fetch_assoc']($dbrequest))
    {
    	if ($row['post_value'] == 0 || $row['id_member_received'] == $row['id_member'])
    		continue;
    		
    	$search_for = 'rated';
    	$value = $row['post_value'];
    	if ($row['post_value'] < 0)
    	{
	    	$search_for = 'rated_negative';
	    	$value *= -1;
    	}
    		
	    $smcFunc['db_query']('', '
		UPDATE {db_prefix}members
		SET ' . $search_for . ' = ' . $search_for . ' - {int:new_rates}
		WHERE id_member = {int:id_member}
		LIMIT 1',
			array(
				'new_rates' => $value,
				'id_member' => $row['id_member']
			)
		);
    }
	$smcFunc['db_free_result']($dbrequest);
	
	$smcFunc['db_query']('', '
		DELETE FROM {db_prefix}rates
		WHERE id_topic IN ({array_int:topics})',
		array(
			'topics' => $topics,
		)
	);
}

function reCalculateRatesExecute($id_old_topic, $id_new_topic, $step, $at)
{
	global $context, $smcFunc, $modSettings;
	
	if ($step == 'onlythis')
	{
		$dbrequest = $smcFunc['db_query']('', '
		SELECT rates
		FROM {db_prefix}messages
		WHERE id_msg = {int:current_message}
		LIMTI 1',
			array(
				'current_message' => $at,
			)
		);
		list($rates) = $smcFunc['db_fetch_row']($dbrequest);
		$smcFunc['db_free_result']($dbrequest);
		
		$smcFunc['db_query']('', '
		UPDATE {db_prefix}rates
		SET id_topic = {int:new_topic}
		WHERE id_message = {int:current_message}',
			array(
				'new_topic' => $id_new_topic,
				'current_message' => $at,
			)
		);
	}
	else
	{
		$dbrequest = $smcFunc['db_query']('', '
		SELECT SUM(rates) AS total
		FROM {db_prefix}messages
		WHERE id_msg >= {int:current_message}
			AND id_topic = {int:old_topic}',
			array(
				'current_message' => $at,
				'old_topic' => $id_old_topic,
			)
		);
		list($rates) = $smcFunc['db_fetch_row']($dbrequest);
		$smcFunc['db_free_result']($dbrequest);
		
		$smcFunc['db_query']('', '
			UPDATE {db_prefix}rates
			SET id_topic = {int:current_topic}
			WHERE id_message >= {int:current_message}
				AND id_topic = {int:old_topic}',
			array(
				'current_topic' => $id_new_topic,
				'current_message' => $at,
				'old_topic' => $id_old_topic,
			)
		);
	}
	
	$smcFunc['db_query']('', '
	UPDATE {db_prefix}topics
	SET rates = rates - {int:new_rates}
	WHERE id_topic = {int:topic}
	LIMIT 1',
		array(
			'topic' => $id_old_topic,
			'new_rates' => $rates
		)
	);
	
	$smcFunc['db_query']('', '
	UPDATE {db_prefix}topics
	SET rates = {int:new_rates}
	WHERE id_topic = {int:topic}
	LIMIT 1',
		array(
			'topic' => $id_new_topic,
			'new_rates' => $rates
		)
	);
}

function reCalculateRatesExecuteSelective($id_old_topic, $id_new_topic, $messages)
{
	global $smcFunc, $modSettings;
	
	$dbrequest = $smcFunc['db_query']('', '
		SELECT SUM(rates) AS total
		FROM {db_prefix}messages
		WHERE id_msg IN ({array_int:split_msgs})',
		array(
			'split_msgs' => $messages
		)
	);
	list($rates) = $smcFunc['db_fetch_row']($dbrequest);
	$smcFunc['db_free_result']($dbrequest);
	
	$smcFunc['db_query']('', '
	UPDATE {db_prefix}topics
	SET rates = rates - {int:new_rates}
	WHERE id_topic = {int:topic}
	LIMIT 1',
		array(
			'topic' => $id_old_topic,
			'new_rates' => $rates
		)
	);
	
	$smcFunc['db_query']('', '
	UPDATE {db_prefix}topics
	SET rates = {int:new_rates}
	WHERE id_topic = {int:topic}
	LIMIT 1',
		array(
			'topic' => $id_new_topic,
			'new_rates' => $rates
		)
	);
	
	$smcFunc['db_query']('', '
		UPDATE {db_prefix}rates
		SET id_topic = {int:new_topic}
		WHERE id_message IN ({array_int:split_msgs})',
		array(
			'new_topic' => $id_new_topic,
			'split_msgs' => $messages,
		)
	);
}

function reCalculateRatesMerge($deleted_topics, $id_topic)
{
	global $smcFunc;
	
	$dbrequest = $smcFunc['db_query']('', '
	SELECT SUM(rates) AS total
	FROM {db_prefix}topics
	WHERE id_topic IN ({array_int:deleted_topics})',
		array(
			'deleted_topics' => $deleted_topics
		)
	);
	list($total) = $smcFunc['db_fetch_row']($dbrequest);
	$smcFunc['db_free_result']($dbrequest);
	
	$smcFunc['db_query']('', '
		UPDATE {db_prefix}rates
		SET rates = rates + {int:value}
		WHERE id_topic = {int:id_topic}
		LIMIT 1',
		array(
			'value' => $total,
			'id_topic' => $id_topic,
		)
	);
	
	$smcFunc['db_query']('', '
		UPDATE {db_prefix}rates
		SET id_topic = {int:id_topic}
		WHERE id_topic IN ({array_int:deleted_topics})',
		array(
			'deleted_topics' => $deleted_topics,
			'id_topic' => $id_topic,
		)
	);
}

// This function takes care when a member is being removed!
function ratesRemoveMember($members)
{
	global $smcFunc;
	
	if (!is_array($members))
		$members = array($members);
		
	for ($i = 0; $i < count($members); $i++)
		$members[$i] = (int) $members[$i];
	
	// Remove all rates done by this guy!
	$dbrequest = $smcFunc['db_query']('', '
	SELECT t.post_value, l.id_member_received, l.id_member, l.id_topic, l.id_message
	FROM {db_prefix}rates AS l
		INNER JOIN {db_prefix}rates_types AS t ON (t.id_type = l.id_type)
	WHERE l.id_member IN ({array_int:users})',
		array(
			'users' => $members,
		)
	);
	
	$topics_array = array();
	$messages_array = array();
	$members_negative_array = array();
	$members_positive_array = array();
	while($row = $smcFunc['db_fetch_assoc']($dbrequest))
    {
    	if ($row['post_value'] == 0)
    		continue;
    		
    	$value = $row['post_value'];
    	if ($row['id_member_received'] != $row['id_member'])
    	{
    		$search_for = 'rated';
    		if ($row['post_value'] < 0)
    		{
	    		if (!isset($members_negative_array[$row['id_member']]))
    				$members_negative_array[$row['id_member']] = 0;
    				
    			$members_negative_array[$row['id_member']] += ($value * -1);
    		}
    		else
    		{
	    		if (!isset($members_positive_array[$row['id_member']]))
    				$members_positive_array[$row['id_member']] = 0;
    				
    			$members_positive_array[$row['id_member']] += $value;
    		}
		}
		
		if (!isset($topics_array[$row['id_topic']]))
			$topics_array[$row['id_topic']] = 0;
			
		$topics_array[$row['id_topic']] += $value;
		
		if (!isset($messages_array[$row['id_topic']]))
			$messages_array[$row['id_topic']] = 0;
			
		$messages_array[$row['id_topic']] += $value;
    }
	$smcFunc['db_free_result']($dbrequest);
	
	// Now update messages
	if (!empty($messages_array))
	{
		foreach ($messages_array as $message => $new_value)
		{
			$smcFunc['db_query']('', '
				UPDATE {db_prefix}messages
				SET rates = rates - {int:new_rates}
				WHERE id_msg = {int:message}
				LIMIT 1',
				array(
					'new_rates' => $new_value,
					'message' => $message
				)
			);
		}
	}
	
	// Now update topics
	if (!empty($topics_array))
	{
		foreach ($topics_array as $topic => $new_value)
		{
			$smcFunc['db_query']('', '
				UPDATE {db_prefix}topics
				SET rates = rates - {int:new_rates}
				WHERE id_topic = {int:topic}
				LIMIT 1',
				array(
					'new_rates' => $new_value,
					'topic' => $topic
				)
			);
		}
	}
	
	// Now update possitive rates
	if (!empty($members_positive_array))
	{
		foreach ($members_positive_array as $member => $new_value)
		{
			$smcFunc['db_query']('', '
				UPDATE {db_prefix}members
				SET rated = rated - {int:new_rates}
				WHERE id_member = {int:member}
				LIMIT 1',
				array(
					'new_rates' => $new_value,
					'member' => $member
				)
			);
		}
	}
	
	// Now update negative rates
	if (!empty($members_negative_array))
	{
		foreach ($members_negative_array as $member => $new_value)
		{
			$smcFunc['db_query']('', '
				UPDATE {db_prefix}members
				SET rated_negative = rated_negative - {int:new_rates}
				WHERE id_member = {int:member}
				LIMIT 1',
				array(
					'new_rates' => $new_value,
					'member' => $member
				)
			);
		}
	}
	
	$smcFunc['db_query']('', '
		DELETE FROM {db_prefix}rates
		WHERE id_member IN ({array_int:users})',
		array(
			'users' => $members,
		)
	);
}
?>