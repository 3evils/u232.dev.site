[center][size=1.45em][color=green]SMFPacks Facepunch Pro Mod - NIBOGO[/color][/size]
[color=green]Advanced Rates System for SMF, including easy navigation and a lot of options to configure.[/color]
[hr]
[url=http://www.smfpacks.com/index.php?action=page;sa=facepunch][b]Link to Mod[/b][/url] | [url=http://www.smfpacks.com/index.php?board=53][b]Support[/b][/url][/center]

[hr]

[b]THIS IS A PAID MOD. YOU SHOULD NOT BE INSTALLING THIS MOD IF YOU DID NOT PAID THE LICENCE FOR IT AT SMFPACKS.COM. IF YOU GOT IT ELSEWHERE PLEASE REPORT IT HERE: [url=http://www.smfpacks.com/contact]CONTACT FORM[/url][/b]