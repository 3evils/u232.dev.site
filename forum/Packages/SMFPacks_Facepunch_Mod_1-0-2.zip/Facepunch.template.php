<?php
/**********************************************************************************
* Facepunch.template.php														  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro v1.0											  	  	  *
* Copyright (c) 2013 by SMFPacks.com. All rights reserved.					 	  *
* Powered by www.smfpacks.com													  *
* Created by NIBOGO for SMFPacks.com											  *
*																				  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro IS NOT FREE SOFTWARE								  	  *
* THIS ONLY CAN BE USED WITH A VALID LICENCE THAT CAN BE BOUGHT AT SMFPacks.com	  *
* YOU CANNOT REMOVE THE COPYRIGHT EITHER UNLESS YOU PURCHASED THE				  *
* COPYRIGHT FREE VERSION AT SMFPacks.com										  *
*																				  *
**********************************************************************************/

function template_rates_above()
{
	global $context, $settings, $options, $txt;

	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=', $context['character_set'], '" />
		<title>', (!empty($context['rates']) ? $txt['rates_topic'] : $txt['rates_members_who']), '</title>';

	if ($context['browser']['is_gecko'])
		echo '
	<style type="text/css"><!--
		.code
		{
			white-space: pre;
		}
	--></style>';

	echo '
	<link rel="stylesheet" type="text/css" href="', $settings['theme_url'], '/css/index.css" />';
	if ($context['browser']['needs_size_fix'])
		echo '
		<link rel="stylesheet" type="text/css" href="', $settings['default_theme_url'], '/fonts-compat.css" />';
		
	echo '
			<script type="text/javascript"><!-- // --><![CDATA[
				var smf_images_url = "', $settings['images_url'], '";
				function doCollapse(id_section)
				{
					var current_header_seo_related = document.getElementById(id_section + "_content").style.display == \'\' ? false : true;
					document.getElementById(id_section + "_image").src = smf_images_url + (!current_header_seo_related ? "/expand.gif" : "/collapse.gif");
					document.getElementById(id_section + "_content").style.display = !current_header_seo_related ? "none" : "";
				}
			// ]]></script>';
			
	echo '
	</head>
	<body>
	<div class="rates_window">';
}

function template_main()
{
	global $context, $settings, $options, $txt, $scripturl, $topic;

	if ($context['is_topic'] && empty($context['rates']))
	{
		echo'
			<div class="windowbg">
				<span class="topslice"><span/></span>
					<div style="padding: 5px; text-align: center;">
						', $txt['rates_no_members'], '
					</div>
				<span class="botslice"><span></span></span>
			</div>';
	}
	elseif (!empty($context['rates']))
	{
		echo '
		<div class="cat_bar">
			<h3 class="catbg">
				<img class="rates_va" src="' . $settings['images_url'] . '/admin/rate.png" alt="" /> ', $txt['rates_topic'], '
			</h3>
		</div>';

		// Now let's set the default class and show the attachs
		$windowclass = 'windowbg';
		foreach ($context['rates'] as $id_message => $rate)
		{
			echo '
			<div class="', $windowclass, '">
				<span class="topslice"><span/></span>
					<div class="floatleft" style="margin-left: 10px;"><a href="', $rate['href'], '">', $rate['avatar'], '</a></div>&nbsp;&nbsp;&nbsp;<a href="', $scripturl, '?topic=', $topic, '.msg', $rate['msg'], '#msg', $rate['msg'], '" title="', $rate['preview'], '" onclick="jQuery(document).trigger(\'close.facebox\');" class="rates_username">', $rate['rates'], ' ', $rate['rates'] == 1 ? $txt['rates_rate'] : $txt['rates'], '</a><br />&nbsp;&nbsp;&nbsp;', $txt['post'], ' ', $txt['by'], ' ', $rate['member'], '
				<span class="botslice"><span></span></span>
			</div>';

			$windowclass = $windowclass == 'windowbg' ? 'windowbg2' : 'windowbg';			
		}
	}
	elseif (!empty($context['message_types']))
	{
		// Now let's set the default class and show the attachs
		$windowclass = 'windowbg';
		foreach ($context['message_types'] as $id_type => $data)
		{
			if (empty($data['members']))
				continue;
				
			echo '
				<div class="cat_bar">
					<h3 class="catbg">
						<span class="ie6_header floatleft"><a href="javascript:doCollapse(\'' . $id_type . '\');">
							<img src="' . $settings['images_url'] . '/collapse.gif" alt="+" id="' . $id_type . '_image" class="icon">
						</a>
						<a href="javascript:doCollapse(\'' . $id_type . '\');">
							', $data['icon'], ' ', $data['name'], ' (', count($data['members']), ' ', $txt['rates'], ')
						</a>
						</span>
					</h3>
				</div>
				<div class="', $windowclass, '" id="' . $id_type . '_content">
					<span class="topslice"><span></span></span>
						<div style="padding: 5px;">';
						
					if (empty($data['members']))
						echo $txt['rates_no_members'];
					else
						foreach ($data['members'] as $mem)
						{
							if (allowedTo('can_remove_rates'))
								echo'
									<a href="', $scripturl, '?action=removerate;topic=', $mem['id_topic'],';type=', $id_type, ';mem=', $mem['id_member'], ';msg=', (int) $_GET['msg'], ';', $context['session_var'], '=', $context['session_id'], '"><img src="', $settings['images_url'], '/icons/quick_remove.gif" alt="', $txt['remove'], '" /> ';
							
							echo $mem['link'], '<br class="clear" />';
						}
							
					echo'
						</div>
					<span class="botslice"><span></span></span>
				</div>';

			$windowclass = $windowclass == 'windowbg' ? 'windowbg2' : 'windowbg';			
		}
	}
}

function template_rates_below()
{
	global $context, $settings, $options, $txt;

	echo '
			</div>
			<div style="display: none !important;" class="smalltext">', theme_copyright(), '</div>				
		</body>
	</html>';
}

function template_rates_boards()
{
	global $context, $settings, $options, $scripturl, $txt;
	
	echo '
	<form name="creator" action="', $scripturl, '?action=admin;area=rates;sa=boards;save" method="post" accept-charset="', $context['character_set'], '"', !empty($context['force_form_onsubmit']) ? ' onsubmit="' . $context['force_form_onsubmit'] . '"' : '', '>
		<div class="cat_bar">
			<h3 class="catbg">
				', $txt['rates_which_boards'], ':
			</h3>
		</div>
		<div class="windowbg2">
			<span class="topslice"><span></span></span>
				<div class="content" align="center">
					<select name="boards[]" size="15" multiple="multiple" style="width: 55%;">
						<option value="0"', (isset($context['all_boards_allow_rates']) ? ' selected="selected"' : ''),'>', $txt['rates_all'], '</option>';
										
						foreach ($context['boards'] as $category)
						{
							echo '
								<option disabled="disabled">----------------------------------------------------</option>
								<option disabled="disabled">', $category['name'], '</option>
								<option disabled="disabled">----------------------------------------------------</option>';
								
									foreach ($category['boards'] as $board)
											echo '
												<option value="' , $board['id'], '" ' , (!isset($context['all_boards_allow_rates']) &&$board['allow_rates'] ? 'selected="selected"' : ''), '> ' . str_repeat('&nbsp;&nbsp;&nbsp; ', $board['child_level']) . '|--- ' , $board['name'], '</option>';
						}
				
				echo '
						</select>
					</div>
				<span class="botslice"><span></span></span>
			</div>
			<br class="clear" />
			<div class="cat_bar">
				<h3 class="catbg">
					', $txt['rates_which_boards_only'], ':
				</h3>
			</div>
			<div class="description">
				', $txt['rates_only_first_desc'], '
			</div>
			<div class="windowbg">
			<span class="topslice"><span></span></span>
				<div class="content" align="center">
					<select name="second_boards[]" size="15" multiple="multiple" style="width: 55%;">
						<option value="0"', (isset($context['all_boards_first']) ? ' selected="selected"' : ''),'>', $txt['rates_only_first_all_boards'], '</option>
						<option value="-10"', (isset($context['all_boards_none_first']) ? ' selected="selected"' : ''),'>', $txt['rates_not_only_first_all_boards'], '</option>';
										
						foreach ($context['boards'] as $category)
						{
							echo '
								<option disabled="disabled">----------------------------------------------------</option>
								<option disabled="disabled">', $category['name'], '</option>
								<option disabled="disabled">----------------------------------------------------</option>';
								
									foreach ($category['boards'] as $board)
											echo '
												<option value="' , $board['id'], '" ' , (!isset($context['all_boards_first']) && $board['only_rate_first'] ? 'selected="selected"' : ''), '> ' . str_repeat('&nbsp;&nbsp;&nbsp; ', $board['child_level']) . '|--- ' , $board['name'], '</option>';
						}
				
				echo '
						</select>
					</div>
				<span class="botslice"><span></span></span>
			</div>
		<br class="clear" />
		<div align="center">
			<input type="submit" class="button_submit" value="', $txt['save'], '" />
			<input type="hidden" name="', $context['session_var'], '" value="', $context['session_id'], '" />
		</div>
	</form>';
}

function template_rates_types()
{
	global $context, $txt, $scripturl, $settings, $smcFunc;
    
    echo '
	<form action="', $scripturl, '?action=admin;area=rates;sa=types;', $context['session_var'], '=', $context['session_id'], '" method="post">
		<table cellspacing="0" cellpadding="10" border="0" align="center" width="85%" class="tborder">
			<tr class="catbg">
				<td align="center">
					', $txt['rates_order'],'
				</td>
				<td align="center">
					', $txt['rates_name'],'
				</td>
				<td align="center">
					', $txt['rates_icon'], '
				</td>
				<td align="center">
                	', $txt['rates_post_value'], '
                </td>
				<td align="center">
					', $txt['rates_enabled'], '
				</td>
                <td align="center">
                	', $txt['rates_only_first_post'], '
                </td>
                <td align="center">
                	', $txt['rates_actions'], '
                </td>
			</tr>';
				
	$windowclass = "windowbg";				
	if (!empty($context['types']))
	{
		foreach($context['types'] as $type)
		{	
			echo '
				<tr class="',$windowclass,'">
                       <td align="center">
                       		<input type="text" size="3" name="order_', $type['id_type'], '" value="', $type['custom_order'], '" />
                       </td>					
                       <td align="center">
                       		', $type['name'], '
                       </td>
                       <td align="center">
                       		', $type['icon'], '
                       </td>
                       <td align="center">
                       		', $type['post_value'], '
                       </td>
                       <td align="center">
                       		', $type['enabled'], '
                       </td>
                       <td align="center">
                       		', $type['only_first_post'], '
                       </td>
                       <td align="center">
                       		', $type['actions'], '
                       </td>
					</tr>';
					
			// Alternate the style class
			$windowclass = ($windowclass == 'windowbg') ? 'windowbg2' : 'windowbg';			
		}
		
		echo'
			<tr>
				<td colspan="6" align="left">
					<input type="submit" value="', $txt['rates_save_order'], '" class="button_submit" />
					<input type="hidden" value="order" name="do" class="button_submit" />
					<input type="hidden" value="', $context['session_id'], '" name="', $context['session_var'], '" class="button_submit" />
				</td>
				<td colspan="1" align="right">
					Original Icons by
						<a href="http://p.yusukekamiyamane.com/">
						 	p.yusukekamiyamane.com
						 </a>
				</td>
			</tr>';
	}
	else
		echo '
			<tr class="',$windowclass,'">
				<td align="center" colspan="6">
					', $txt['rates_nothing'], '
				</td>
			</tr>';

	echo '
		</table>
	</form>';
}

function template_links_permissions()
{
	
}

function template_rates_add()
{
	global $context, $txt, $scripturl, $board_info, $board, $selected_boards, $settings, $boardurl;
	
	echo '
		<form method="post" name="addga" id="addga" action="', $scripturl, '?action=admin;area=rates;sa=add_type" accept-charset="', $context['character_set'], '" onsubmit="submitonce(this);">
			<div class="cat_bar">
				<h3 class="catbg">
					', $context['page_title'], '
				</h3>
			</div>
			<div class="tborder">
				<table border="0" width="100%" cellspacing="1" cellpadding="4" class="bordercolor">			
					<tr class="windowbg">
						<td width="25%"><b>', $txt['rates_enabled'], ':</b></td>
						<td width="75%"><input type="checkbox" name="enabled" value="1"', $context['type_data']['enabled'] ? ' checked="checked"' : '', ' /></td>
					</tr>
					<tr class="windowbg2">
						<td width="25%"><b>', $txt['rates_name'], ':</b></td>
						<td width="75%"><input type="text" name="name" size="30" value="', $context['type_data']['name'], '" /></td>
					</tr>
					<tr class="windowbg">
						<td width="25%"><b>', $txt['rates_icon'], ':</b></td>
						<td width="75%">', $boardurl, '/rates_types/<input type="text" name="icon" size="20" value="', $context['type_data']['icon'], '" /></td>
					</tr>
					<tr class="windowbg2">
						<td width="25%"><b>', $txt['rates_post_value'], ':</b><div class="smalltext">', $txt['rates_post_value_desc'], '</div></td>
						<td width="75%"><input type="text" name="post_value" size="30" value="', $context['type_data']['post_value'], '" /></td>
					</tr>
					<tr class="windowbg">
						<td width="25%"><b>', $txt['rates_only_first_post'], ':</b></td>
						<td width="75%"><input type="checkbox" name="first" value="1"', $context['type_data']['only_first_post'] ? ' checked="checked"' : '', ' /></td>
					</tr>
					<tr class="windowbg2">
						<td width="25%"><b>', $txt['rates_boards'], ':</b></td>
						<td width="75%">
							<select name="boards[]" size="15" multiple="multiple" style="width: 55%;">
									<option value="0" ' ,($context['type_data']['id_boards'] == '0' && $context['type_data']['id_boards'] !== '') ? 'selected="selected"' : '', '>', $txt['rates_all_boards'], '</option>';
							foreach ($context['jump_to'] as $category)
							{
								echo '
									<option disabled="disabled">----------------------------------------------------</option>
									<option disabled="disabled">', $category['name'], '</option>
									<option disabled="disabled">----------------------------------------------------</option>';
								foreach ($category['boards'] as $board)
									echo '
									<option value="' ,$board['id'], '" ' ,(isset($selected_boards[$board['id']])) ? 'selected="selected"' : '', ' > ' . str_repeat('&nbsp;&nbsp;&nbsp; ', $board['child_level']) . '|--- ' . $board['name'] . '</option>';
							}
	echo '
							</select>
						</td>
					</tr>
					<tr class="windowbg">
					    <td width="25%"><b>', $txt['rates_permissions'],':</b></td>
					    <td width="75%">';
					    
					    $permissionsGroups = explode(',',$context['type_data']['permissions']);
					    echo '
					    	<input type="checkbox" name="groups[-1]" value="-1" ', ((in_array(-1,$permissionsGroups) == true) ? ' checked="checked" ' : ''), ' /> ',$txt['membergroups_guests'],'<br />
					    	<input type="checkbox" name="groups[0]" value="0" ', ((in_array(0,$permissionsGroups) == true) ? ' checked="checked" ' : ''), ' /> ',$txt['membergroups_members'],'<br />';
	
					    foreach ($context['groups'] as $group)
					    	echo'
					    		<input type="checkbox" name="groups[', $group['id_group'], ']" value="', $group['id_group'], '" ', ((in_array($group['id_group'],$permissionsGroups) == true) ? ' checked="checked" ' : ''), ' />', $group['group_name'], '<br />';
											
					echo'
							<input id="check_all" class="input_check" type="checkbox" onclick="invertAll(this, this.form, \'groups\');" value="" name="all"/>'.$txt['check_all'].'   
						</td>
					</tr> 
			        <tr>
				        <td colspan="2" align="center">
				            <input type="hidden" name="', $context['session_var'], '" value="', $context['session_id'], '" />      	
					        <input type="submit" class="button_submit" value="', $context['page_title'],'" />
					        <input type="hidden" name="save" value="1" />';
					        
					if (!empty($_REQUEST['pid']))
						echo'
							<input type="hidden" name="type_id" value="', (int) $_REQUEST['pid'], '" />
							<input type="hidden" name="last_post_value" value="', $context['type_data']['post_value'], '" />';
					        
				echo'
					    </td>
				    </tr>
			</table>
		</div>
	</form>';
}

function template_rates_remove()
{
	global $context, $txt, $scripturl, $board_info, $board, $selected_boards, $settings, $boardurl;
	
	echo '
		<form method="post" action="', $scripturl, '?action=admin;area=rates;sa=add_type;remove=', $_GET['remove'], ';confirm;', $context['session_var'], '=', $context['session_id'], '" accept-charset="', $context['character_set'], '" onsubmit="submitonce(this);">
			<div class="windowbg2">
				<span class="topslice"><span></span></span>
					<div class="content" style="color: red; font-weight: bold;">
						', $txt['rates_type_delete_warning'], '
						<div align="center" style="margin-top: 20px;">
							<input type="submit" class="button_submit" value="', $txt['rates_continue'], '" />
						</div>
					</div>
				<span class="botslice"><span></span></span>
			</div>
		</form>';
}

// Template for showing all the posts of the user, in chronological order.
function template_ratesInProfile()
{
	global $context, $settings, $options, $scripturl, $modSettings, $txt;

	echo '
		<div class="cat_bar">
			<h3 class="catbg">
				', $context['is_given'] ? $txt['rates_given'] : $txt['rates_received'], ' - ', $context['member']['name'], '
			</h3>
		</div>
		<div class="pagesection">
			<span>', $txt['pages'], ': ', $context['page_index'], '</span>
		</div>';
		
	$class = 'windowbg';
	if (empty($context['rate_posts']))
	{
		echo'
				<div class="', $class, '">
					<span class="topslice"><span></span></span>
						<div class="content" align="center">
							', $txt['msg_alert_none'], '
						</div>
					<span class="botslice"><span></span></span>
				</div>
			';
	}
	else
	{
		foreach ($context['rate_posts'] as $posts)
		{
			echo'
				<div class="', $class, '">
					<span class="topslice"><span></span></span>
						<div class="content">
							<div class="counter">
								', $posts['counter'], '
							</div>
							', $posts['subject'], '
							<div class="smalltext">
								', $txt['on'], ' ', $posts['time'], '
							</div>
							<div class="list_posts">
								', $posts['body'], '
							</div>
						</div>
					<span class="botslice"><span></span></span>
				</div>';
				
			$class = ($class == 'windowbg') ? 'windowbg2' : 'windowbg';
		}
	}
	
	// Show more page numbers.
	echo '
		<div class="pagesection" style="margin-bottom: 0;">
			<span>', $txt['pages'], ': ', $context['page_index'], '</span>
		</div>';
}
?>