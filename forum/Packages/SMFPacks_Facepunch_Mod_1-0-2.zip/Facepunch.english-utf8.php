<?php
/**********************************************************************************
* Facepunch.english-utf8.php													  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro v1.0											  	  	  *
* Copyright (c) 2013 by SMFPacks.com. All rights reserved.					 	  *
* Powered by www.smfpacks.com													  *
* Created by NIBOGO for SMFPacks.com											  *
*																				  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro IS NOT FREE SOFTWARE								  	  *
* THIS ONLY CAN BE USED WITH A VALID LICENCE THAT CAN BE BOUGHT AT SMFPacks.com	  *
* YOU CANNOT REMOVE THE COPYRIGHT EITHER UNLESS YOU PURCHASED THE				  *
* COPYRIGHT FREE VERSION AT SMFPacks.com										  *
*																				  *
**********************************************************************************/

$txt['rates'] = 'Rates';
$txt['rates_rate'] = 'Rate';
$txt['rates_members_who'] = 'Members Who Rates This';
$txt['rates_topic'] = 'Rates of this Topic';
$txt['rates_error'] = 'Data wasn\'t enough to process the request';
$txt['rates_spam_error'] = 'You only can Rate posts every: %d seconds';
$txt['rates_already'] = 'You already gave Rate to that Post';
$txt['rates_no_yourself'] = 'You can\'t rate your own posts';
$txt['rates_spam'] = 'Allow Rates Every:';
$txt['rates_spam_desc'] = '0 to Disable';
$txt['rates_seconds'] = 'seconds';
$txt['rates_rated'] = 'Rated';
$txt['rates_stats'] = 'Show 10 Rated Topics and Rated Users on Stats';
$txt['rates_mlist'] = 'Show Rated on Member List';
$txt['rates_ajax'] = 'Enable Ajax Liking';
$txt['rates_board'] = 'Allow Rates';
$txt['allow_rate'] = 'Rate Posts';
$txt['rates_disrate_fail'] = 'You can\'t unrate that post';
$txt['rates_unrate'] = 'Unrate';
$txt['rates_no_permission'] = 'No Permission';
$txt['rates_settings'] = 'Rates Settings';
$txt['rates_settings_description'] = 'Here you can configure all the settings related with the Rates system';
$txt['rates_show_rated'] = 'Show Rates Received in Topics';
$txt['rates_show_rated_desc'] = 'Show how many times poster has been rated';
$txt['rates_show_total'] = 'Show Total of Rates in Topics Header';
$txt['rates_hide_total_list'] = 'Hide List of Rates in Topics';
$txt['rates_messageindex'] = 'Show Rates of Topics in Message Index';
$txt['rates_show_rated_profile'] = 'Show Rated in Profile';
$txt['rates_show_rated_pm'] = 'Show Rated in Personal Messages';
$txt['rates_boards'] = 'Boards';
$txt['rates_boards_description'] = 'Here you can configure where Rates would be enabled for boards. Press ctrl (or cmd in mac) to select various boards at the same time. You can also select various boards using shift.';
$txt['rates_permissions'] = 'Permissions';
$txt['rates_all'] = 'Enable Rates in All Boards';
$txt['rates_permissions_description'] = 'Here you can configure who can rate posts easily';
$txt['rate_maintenance'] = 'Maintenance';
$txt['rate_maintenance_description'] = 'Here you can re-calculate all the stats related with Rates. Including re-count rates of each topic, message and profiles.';
$txt['rates_show_messages'] = 'Rated';
$txt['rates_search'] = 'Minimun Rates Required';
$txt['rates_in_topic'] = 'in topic';
$txt['rates_in_post'] = 'in post';
$txt['rates_show_rated_posts'] = 'Show Rated Posts in Profile';
$txt['rates_top_rated_topics'] = 'Top 10 Rated Topics';
$txt['rates_top_rated_users'] = 'Top 10 Rated Users';
$txt['rates_only_first'] = 'Only Allow Rates to First Post';
$txt['rates_only_first_desc'] = 'This overrides the option for each type';
$txt['rates_button'] = 'Location of Rate Button';
$txt['rates_both'] = 'Both';
$txt['rates_buttons'] = 'Buttons';
$txt['rates_counter'] = 'In Counter';
$txt['rates_you'] = 'You';
$txt['rates_rates_this'] = 'rates this';
$txt['rates_rate_this'] = 'rate this';
$txt['rates_and'] = 'and';
$txt['rates_other'] = 'other';
$txt['rates_others'] = 'others';
$txt['rates_with_ajax'] = 'Enable Ajax in Rates (No page refresh)';
$txt['rate_first_post'] = 'Only Allow Rates in First Post';
$txt['rates_which_boards'] = 'Select in which boards rates are allowed';
$txt['rates_which_boards_only'] = 'Select in which boards rates are only allowed in First Post';
$txt['only_rate_first_board'] = 'Only Allow Rates in First Post';
$txt['rates_icons_set'] = 'Select Icons Set to be Used';
$txt['rates_icons_set_desc'] = 'Default uses rate.png and unrate.png, custom uses custom_rate.png and custom_unrate.png';
$txt['rates_default'] = 'Default';
$txt['rates_custom'] = 'Custom';
$txt['rates_minimun_rates'] = 'Minimun Rates Total Required to Rate';
$txt['rates_minimun_rates_desc'] = 'For example: If set to 50 and someone has received +30 rates he won\'t be able to Rate no matter what';
$txt['rates_minimun_error'] = 'Only persons with more than %d rates received can Rate posts';
$txt['rates_not_only_first_all_boards'] = 'All Boards allow rates in all posts';
$txt['rates_only_first_all_boards'] = 'All Boards only allow rates in first post';
$txt['rates_per_day'] = 'per post';

// 2.0 new strings
$txt['rates_no_type'] = 'No type was selected';
$txt['rates_no_type_available'] = 'No type was found, this type could be disabled in this board or you do not have permission to use it';
$txt['rates_types'] = 'Types';
$txt['rates_types_description'] = 'Here you can modify all the rates types in your forum';
$txt['rates_order'] = 'Order';
$txt['rates_name'] = 'Name';
$txt['rates_only_first_post'] = 'Only available in first post';
$txt['rates_icon'] = 'Icon';
$txt['rates_post_value'] = 'Value';
$txt['rates_post_value_desc'] = 'How many points are given to each message for this rate? Use 3 for three positive points, 0 for none or -2 for two negative points';
$txt['rates_enabled'] = 'Enabled';
$txt['rates_nothing'] = 'No types to show';
$txt['rates_actions'] = 'Actions';
$txt['rates_add_type'] = 'Add New Type';
$txt['rates_add_type_desc'] = 'Here you can add new types of rates';
$txt['rates_save_order'] = 'Save Order';
$txt['rates_boards'] = 'Boards';
$txt['rates_all_boards'] = 'All Boards';
$txt['rates_type_no_name'] = 'No name selected';
$txt['rates_type_no_icon'] = 'No icon selected';
$txt['rates_type_delete_warning'] = 'WARNING! THIS IS GOING TO REMOVE ALL LIKES DONE WITH THIS TYPE AND IT IS ALSO GOING TO CHANGE ALL MEMBERS LIKES RECEIVED. IF YOU WANT TO CONTINUE PLEASE KEEP IN MIND THIS TAKES A LOT OF TIME AS A LOT OF STATS MUST BE RE-CALCULATED';
$txt['rates_continue'] = 'Continue';
$txt['can_see_rates'] = 'See Rates in Posts';
$txt['permissionname_can_see_rates'] = 'See Rates in Posts';
$txt['permissionhelp_can_see_rates'] = 'This permission allows a user to see rates in posts even if he cannot rate';
$txt['can_own_rate'] = 'Rate to Own Posts';
$txt['permissionname_can_own_rate'] = 'Rate to Own Posts';
$txt['permissionhelp_can_own_rate'] = 'This permission allows a user to rate his own posts (their rate do not count for user\'s rates total)';
$txt['can_multiple_rates'] = 'Multiple Rates to Same Post';
$txt['permissionname_can_multiple_rates'] = 'Multiple Rates to Same Post';
$txt['permissionhelp_can_multiple_rates'] = 'Allows users to rate with more than one type to the same post';
$txt['can_remove_rates'] = 'Remove All Rates';
$txt['permissionname_can_remove_rates'] = 'Remove Anyone Rates';
$txt['permissionhelp_can_remove_rates'] = 'Allows users to remove anyone rate to any post';
$txt['rates_list_of_raters'] = 'List of Rates';
$txt['rates_no_members'] = 'No rates yet';
$txt['rates_hide'] = 'Hide Content When Post Gets';
$txt['rates_hide_desc'] = 'After a post gets the total of rates specified, or below, post content is going to be hidden';
$txt['rates_hide_example'] = 'For ex: If set as -5 then all posts content with a total rates equal or less-than -5 are going to be hidden. Use 999999 to disable';
$txt['rates_hide_post'] = 'Total Rates';
$txt['rates_hide_message'] = 'Set a custom hidden message';
$txt['rates_hide_message_desc'] = 'If added a custom message is going to be shown when a post is hidden because of rates total';
$txt['rates_default_message'] = 'This message has been hidden due to negative rates.';
$txt['rates_show_message'] = 'Show message';
$txt['rates_possitive_received'] = '%d Possitive Rates Received';
$txt['rates_negative_received'] = '%d Negative Rates Received';
$txt['rates_required'] = 'Required Rates';
$txt['rates_received'] = 'Rates Received';
$txt['rates_given'] = 'Rates Given';
$txt['rates_show_as'] = 'Show Rates Received as';
$txt['rates_show_total'] = 'Total of Rates';
$txt['rates_show_possitive_and_negative'] = 'Positive/Negative Rates';
$txt['rates_show_bar'] = 'Rates Bar';
$txt['rates_show_opacity'] = 'Apply Opacity to Rates Box';
$txt['rates_show_opacity_desc'] = 'Opacity is disabled when mouse is over';
?>