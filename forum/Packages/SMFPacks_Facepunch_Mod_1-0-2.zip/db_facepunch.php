<?php
/**********************************************************************************
* db_facepunch.php																  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro v1.0										  	 		  *
* Copyright (c) 2013 by SMFPacks.com. All rights reserved.					 	  *
* Powered by www.smfpacks.com													  *
* Created by NIBOGO for SMFPacks.com											  *
*																				  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro IS NOT FREE SOFTWARE								  	  *
* THIS ONLY CAN BE USED WITH A VALID LICENCE THAT CAN BE BOUGHT AT SMFPacks.com	  *
* YOU CANNOT REMOVE THE COPYRIGHT EITHER UNLESS YOU PURCHASED THE				  *
* COPYRIGHT FREE VERSION AT SMFPacks.com										  *
*																				  *
**********************************************************************************/
    
	global $smcFunc, $db_prefix, $context, $modSettings;
	
	// Define the Manual Installation Status
    $manual_install = false;

    if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
    {
	   require_once(dirname(__FILE__) . '/SSI.php');
	   $manual_install = true;
    }
    elseif (!defined('SMF'))
	   die('Installer wasn\'t able to connect to SMF! Make sure that you are either installing this via the Package Manager or the SSI.php file is in the same directory.');

    if ($manual_install)
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
	<title>Database Installer</title>
     <link rel="stylesheet" type="text/css" href="Themes/default/css/index.css" />
</head>
<body>
	<br /><br />';
	
	db_extend('packages'); 
	
	if (empty($context['uninstalling']))
	{
		$columns = array(
	    array(
	      'name' => 'id_member',
	      'type' => 'int',
	      'size' => '11',
	      'default' => '0',
	      'null' => false,
	    ),    
	    array(
	      'name' => 'id_message',
	      'type' => 'int',
	      'size' => '11',
	      'default' => '0',
	      'null' => false,
	    ), 
	     array(
	      'name' => 'id_topic',
	      'type' => 'int',
	      'size' => '11',
	      'default' => '10',
	      'null' => false,
	    ),
	    array(
			'name' => 'id_board',
			'type' => 'int',
			'size' => '11',
			'default' => '0',
			'null' => false
		),
		array(
			'name' => 'timestamp',
			'type' => 'int',
			'size' => '11',
			'default' => '0',
			'null' => false
		),
		array(
			'name' => 'id_type',
			'type' => 'int',
			'size' => '11',
			'default' => 1,
			'null' => false
		),
		array(
			'name' => 'id_member_received',
			'type' => 'int',
			'size' => '11',
			'default' => '0',
			'null' => false,
		)
	    );		  
		$smcFunc['db_create_table']('{db_prefix}rates', $columns, array());
		
		$columns = array(
	    array(
	      'name' => 'id_type',
	      'type' => 'int',
	      'size' => '11',
	      'default' => '0',
	      'auto' => true,
	      'null' => false,
	    ),    
	    array(
	      'name' => 'post_value',
	      'type' => 'int',
	      'size' => '11',
	      'default' => '0',
	      'null' => false,
	    ), 
	    array(
	      'name' => 'permissions',
	      'type' => 'text'
	    ),
	    array(
	      'name' => 'id_boards',
	      'type' => 'text'
	    ),
	    array(
	      'name' => 'custom_order',
	      'type' => 'int',
	      'default' => 0,
	      'size' => 11
	    ),
	    array(
	      'name' => 'icon',
	      'type' => 'varchar',
	      'size' => 30
	    ),
	    array(
	      'name' => 'enabled',
	      'type' => 'tinyint',
	      'default' => 1,
	      'size' => 1
	    ),
	    array(
	      'name' => 'only_first_post',
	      'type' => 'tinyint',
	      'default' => 0,
	      'size' => 1
	    ),
	    array(
	      'name' => 'name',
	      'type' => 'varchar',
	      'size' => 30
	    ),
	    );
	    $indexes = array(
	      array(
	        'type' => 'primary',
	        'columns' => array('id_type')
	      ),
	    );	  
		$smcFunc['db_create_table']('{db_prefix}rates_types', $columns, $indexes);
		
		// Insert default values!
		$request = $smcFunc['db_query']('','
		SELECT id_type
		FROM {db_prefix}rates_types
		LIMIT 1');
		
		if ($smcFunc['db_num_rows']($request) == 0)
		{
			$i = 1;
			$smcFunc['db_insert'](
				'insert', '{db_prefix}rates_types',
				array(
					'post_value' => 'int', 'permissions' => 'text', 'id_boards' => 'text', 'custom_order' => 'int', 'icon' => 'string',
					'enabled' => 'int', 'only_first_post' => 'int', 'name' => 'string',
				),
				array(
					array(1, '-1,0,1,2,9', '0', $i++, 'like.png', 1, 0, 'Rate'),
					array(-1, '-1,0,1,2,9', '0', $i++, 'unlike.png', 1, 0, 'Unlike'),
					array(-2, '-1,0,1,2,9', '0', $i++, 'bad_words.png', 1, 0, 'Bad Words'),
					array(-1, '-1,0,1,2,9', '0', $i++, 'tick-red.png', 1, 0, 'Disagree'),
					array(-2, '-1,0,1,2,9', '0', $i++, 'date_previous.png', 0, 0, 'Old'),
					array(0, '-1,0,1,2,9', '0', $i++, 'help.png', 1, 0, 'Help Required'),
					array(-4, '-1,0,1,2,9', '0', $i++, 'lightbulb_off.png', 1, 0, 'Not Brilliant'),
					array(5, '-1,0,1,2,9', '0', $i++, 'lightbulb.png', 1, 0, 'Brilliant'),
					array(1, '-1,0,1,2,9', '0', $i++, 'new.png', 1, 0, 'New'),
					array(0, '-1,0,1,2,9', '0', $i++, 'palette.png', 1, 0, 'Customizable'),
					array(2, '-1,0,1,2,9', '0', $i++, 'rainbow.png', 1, 0, 'Optimistic'),
					array(10, '-1,0,1,2,9', '0', $i++, 'rosette.png', 1, 0, 'Best Solution'),
					array(2, '-1,0,1,2,9', '0', $i++, 'tick.png', 1, 0, 'Agree'),
					array(3, '-1,0,1,2,9', '0', $i++, 'wand.png', 1, 0, 'Magic'),
					array(6, '-1,0,1,2,9', '0', $i++, 'winner.png', 1, 0, 'Winner'),
					array(0, '-1,0,1,2,9', '0', $i++, 'yin-yang.png', 1, 0, 'Different'),
					array(2, '-1,0,1,2,9', '0', $i++, 'thermometer.png', 1, 0, 'Hot'),
					array(0, '-1,0,1,2,9', '0', $i++, 'confused.png', 1, 0, 'Confused'),
					array(3, '-1,0,1,2,9', '0', $i++, 'rock.png', 0, 0, 'Rock'),
				),
				array('id_type')
			);
		}
		$smcFunc['db_free_result']($request);
		
		$smcFunc['db_add_column'] ('{db_prefix}messages', array(
				'name' => 'rates',
				'type' => 'int',
				'size' => '11',
				'default' => '0',
				'null' => false
			)
		);
		
		$smcFunc['db_add_column'] ('{db_prefix}topics', array(
				'name' => 'rates',
				'type' => 'int',
				'size' => '11',
				'default' => '0',
				'null' => false
			)
		);
		
		$smcFunc['db_add_column'] ('{db_prefix}boards', array(
				'name' => 'allow_rates',
				'type' => 'tinyint',
				'size' => '2',
				'default' => '0',
				'null' => false
			)
		);
		
		$smcFunc['db_add_column'] ('{db_prefix}boards', array(
				'name' => 'only_rate_first',
				'type' => 'tinyint',
				'size' => '2',
				'default' => '0',
				'null' => false
			)
		);
		  
	    $smcFunc['db_add_column'] ('{db_prefix}members', array(
				'name' => 'rated',
				'type' => 'int',
				'size' => '11',
				'default' => '0',
				'null' => false
			)
		);
		
		$smcFunc['db_add_column'] ('{db_prefix}members', array(
				'name' => 'last_rate',
				'type' => 'int',
				'size' => '11',
				'default' => '0',
				'null' => false
			)
		);
		
		$smcFunc['db_add_column'] ('{db_prefix}members', array(
				'name' => 'rated_negative',
				'type' => 'int',
				'size' => '11',
				'default' => '0',
				'null' => false
			)
		);
		
		$smcFunc['db_add_column'] ('{db_prefix}membergroups', array(
				'name' => 'min_rates',
				'type' => 'int',
				'size' => '11',
				'default' => '0',
				'null' => false
			)
		);

		$call = 'add_integration_function';
	}
	else
		$call = 'remove_integration_function';
		
	if (empty($modSettings['rates_installed']))
	{
		$rates_settings = array(
			'rates_installed' => time(),
			'rates_with_ajax' => 1,
			'rates_hide' => -999999,
			'rates_show_opacity' => 1,
			'rates_show_as' => 2,
			'rates_show_total' => 1,
			'rates_show_liked' => 1,
			'rates_show_liked_profile' => 1,
			'rates_show_liked_pm' => 1,
			'rates_show_liked_posts' => 1,
			'rates_stats' => 1,
			'rates_mlist' => 1,
			'rates_messageindex' => 1,
		);
		
		updateSettings($rates_settings);
	}
		
	// Integration hooks cause is cooler!
	$hooks = array(
		'integrate_actions' => 'rates_add_actions',
		'integrate_pre_include' => '$boarddir/FacepunchBasics.php',
		'integrate_admin_areas' => 'rates_admin_areas',
		'integrate_load_permissions' => 'rates_add_permissions',
		'integrate_delete_member' => 'rates_remove_member',
		'integrate_display_buttons' => 'rates_buttons',
		'integrate_buffer' => 'rates_buffer',
		'integrate_profile_areas' => 'rates_profile_areas'
	);
	
	foreach ($hooks as $hook => $function)
		$call($hook, $function);
	
	// OK, time to report, output all the stuff to be shown to the user
	if ($manual_install)
	{
		echo '
		<table cellpadding="0" cellspacing="0" border="0" class="tborder" width="800" align="center"><tr><td>
		<div class="titlebg" style="padding: 1ex" align="center">
			SMFPacks Facepunch Pro Mod Database Installer
		</div>
		<div class="windowbg2" style="padding: 2ex">';

		echo '
		<div style="padding-top:30px">
			<b>Your database update has been completed successfully!</b>
			<br /><br />
			Now you should go to the <a href="', $scripturl, '?action=admin;area=facepunch;sesc=' . $context['session_id'] . '">SMFPacks Facepunch Pro Mod</a>.
			<br /><br />';

		if ($doing_manual_install && (is_writable(dirname(__FILE__)) || is_writable(__FILE__)))
			echo '
			<label for="delete_self"><input type="checkbox" id="delete_self" onclick="doTheDelete(this);" /> Delete this file.</label> <i>(doesn\'t work on all servers.)</i>
			<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
				function doTheDelete(theCheck)
				{
					var theImage = document.getElementById ? document.getElementById("delete_upgrader") : document.all.delete_upgrader;
		
					theImage.src = "', $_SERVER['PHP_SELF'], '?delete=1&ts_" + (new Date().getTime());
					theCheck.disabled = true;
				}
			// ]]></script>
			<img src="', $boardurl, '/Themes/default/images/blank.gif" alt="" id="delete_upgrader" />';

		echo '
		</div>
		</td></tr></table>
		<br />
		</body></html>';
    }
	
?>