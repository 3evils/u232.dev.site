<?php
/**********************************************************************************
* Facepunch.php															  		  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro v1.0											  	  	  *
* Copyright (c) 2013 by SMFPacks.com. All rights reserved.					 	  *
* Powered by www.smfpacks.com													  *
* Created by NIBOGO for SMFPacks.com											  *
*																				  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro IS NOT FREE SOFTWARE								  	  *
* THIS ONLY CAN BE USED WITH A VALID LICENCE THAT CAN BE BOUGHT AT SMFPacks.com	  *
* YOU CANNOT REMOVE THE COPYRIGHT EITHER UNLESS YOU PURCHASED THE				  *
* COPYRIGHT FREE VERSION AT SMFPacks.com										  *
*																				  *
**********************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');
	
// This function is a big one! It takes care of every single Rate/Unrate
function Rate()
{
	global $smcFunc, $user_info, $context, $modSettings, $sourcedir, $txt, $board, $topic;
	
	checkSession('get');
	
	// No complete values?
	if (empty($board) || empty($_REQUEST['msg']) || !is_numeric($_REQUEST['msg']))
		rate_error($txt['rates_error']);
		
	$_REQUEST['msg'] = (int) $_REQUEST['msg'];
	$type = (int) $_GET['type'];
	
	if (empty($type))
		rate_error($txt['rates_no_type']);
	
	if (!empty($modSettings['rates_minimun_rates']) && isset($user_info['rated']) && $modSettings['rates_minimun_rates'] > $user_info['rated'])
		rate_error(sprintf($txt['rates_minimun_error'], $modSettings['rates_minimun_rates']));
		
	// Time to see if we are liking/unliking and if we can do multiple rates
	$request = $smcFunc['db_query']('', '
		SELECT id_type
		FROM {db_prefix}rates
		WHERE id_message = {int:id_msg} AND id_member = {int:id_member}',
		array(
			'id_msg' => $_REQUEST['msg'],
			'id_member' => $user_info['id'],
			'type' => $type,
		)
	);
	$unliking = false;
	$total = 0;
	while($row = $smcFunc['db_fetch_assoc']($request))
	{
		$total++;
    	if ($row['id_type'] == $type)
    		$unliking = true;
    }
	$smcFunc['db_free_result']($request);
	
	if ($total > 0 && $unliking == false && !allowedTo('can_multiple_rates'))
		rate_error($txt['rates_already']);
	
	if ($unliking == false && !empty($modSettings['rates_spam']) && !empty($user_info['last_rate']) && ($user_info['last_rate'] + $modSettings['rates_spam']) > time())
		rate_error(sprintf($txt['rates_spam_error'], $modSettings['rates_spam']));

	$dbrequest = $smcFunc['db_query']('', '
		SELECT id_member, subject
		FROM {db_prefix}messages
		WHERE id_msg = {int:id_msg}
		LIMIT 1',
			array(
				'id_msg' => $_REQUEST['msg'],
			)
		);

	list($author, $subject) = $smcFunc['db_fetch_row']($dbrequest);
	$smcFunc['db_free_result']($dbrequest);

	if (!allowedTo('can_own_rate') && $author == $user_info['id'] && $unliking == false)
		rate_error($txt['rates_no_yourself']);
		
	// Get this post value!
	$dbrequest = $smcFunc['db_query']('', '
		SELECT post_value, icon, name
		FROM {db_prefix}rates_types
		WHERE id_type = {int:type}
			AND (FIND_IN_SET(' . implode(', permissions) OR FIND_IN_SET(', $user_info['groups']) . ', permissions))
			AND (id_boards = 0 OR FIND_IN_SET({int:board}, id_boards))
		LIMIT 1',
			array(
				'type' => $type,
				'board' => $board
			)
		);

	if ($smcFunc['db_num_rows']($dbrequest) == 0)
		rate_error($txt['rates_no_type_available']);
	
	list($post_value, $rate_icon, $rate_name) = $smcFunc['db_fetch_row']($dbrequest);
	$smcFunc['db_free_result']($dbrequest);
	
	// Update the author (only if he is not the one who is liking!)
	if ($author != $user_info['id'])
	{
		$search_for = '';
		if ($post_value < 0)
		{
			$tmp = $post_value;
			$post_value *= -1;
			$search_for = 'rated_negative';
		}
		else if ($post_value > 0)
			$search_for = 'rated';
			
		$symbol = $unliking ? '-' : '+';
			
		if ($search_for != '')
			$smcFunc['db_query']('', '
				UPDATE {db_prefix}members
				SET ' . $search_for . ' = ' . $search_for . ' ' . $symbol . ' {int:value}
				WHERE id_member = {int:author}
				LIMIT 1',
					array(
						'value' => $post_value,
						'author' => $author
					)
			);
			
		if (isset($tmp))
		{
			$post_value = $tmp;
			unset($tmp, $search_for);
		}
	}

	// At the end liking and unliking are quite similar!
	if ($unliking)
	{
		$smcFunc['db_query']('', '
			DELETE FROM {db_prefix}rates
			WHERE id_message = {int:id_msg}
				AND id_member = {int:id_member}
				AND id_type = {int:type}
			LIMIT {int:limit}',
			array(
				'limit' => 1,
				'id_msg' => $_REQUEST['msg'],
				'id_member' => $user_info['id'],
				'type' => $type
			)
		);
		
		// Invert post value
		$post_value *= -1;
	}
	else
	{
		$smcFunc['db_insert']('',
			'{db_prefix}rates',
			array(
				'id_member' => 'int', 'id_topic' => 'int', 'id_message' => 'int', 'timestamp' => 'int', 'id_board' => 'int', 'id_member_received' => 'int', 'id_type' => 'int',
			),
			array(
				$user_info['id'], $topic, $_REQUEST['msg'], time(), $board, $author, $type,
			),
			array('')
		);
		
		// Update time of last rate
		updateMemberData($user_info['id'], array('last_rate' => time()));
	}
	
	$smcFunc['db_query']('', '
		UPDATE {db_prefix}messages
		SET rates = rates + {int:value}
		WHERE id_msg = {int:id_msg}
		LIMIT 1',
		array(
			'id_msg' => $_REQUEST['msg'],
			'value' => $post_value
		)
	);
	
	$smcFunc['db_query']('', '
		UPDATE {db_prefix}topics
		SET rates = rates + {int:value}
		WHERE id_topic = {int:id_topic}
		LIMIT 1',
		array(
			'id_topic' => $topic,
			'value' => $post_value
		)
	);
		
	// SMFPacks Alerts Pro and SMFPacks Activity Stream integration!
	if ($unliking == false)
	{
		if (function_exists('not_log_rate'))
			not_log_rate($author, $topic, $_REQUEST['msg'], $rate_icon, $subject, $rate_name);
			
		if (function_exists('as_log_rate'))
			as_log_rate($topic, $_REQUEST['msg'], $board, $subject, $rate_icon, $rate_name);
	}
	
	// Force cache re-generation!
	cache_put_data('rates_topic_' . $topic, array(), 1);
	cache_put_data('rates_post_' . $_REQUEST['msg'], array(), 1);
	
	// What to do now?
	if (isset($_GET['ajax']))
		build_magic_box($_REQUEST['msg'], true, $author);
	else
		redirectexit('topic=' . $topic . '.msg' . $_REQUEST['msg'] . '#msg' . $_REQUEST['msg']);
}

function ViewFacepunch()
{
	global $smcFunc, $topic, $txt, $context, $modSettings, $scripturl, $settings, $boardurl;

	if (empty($topic) && (empty($_REQUEST['msg']) || !is_numeric($_REQUEST['msg'])))
		fatal_lang_error('not_a_topic', false);
		
	if ((!empty($topic) && !empty($modSettings['rates_hide_total_list'])) || (!empty($_REQUEST['msg']) && !empty($modSettings['rates_hide_post_list'])))
		fatal_lang_error('rates_no_permission', false);
		
	$context['is_topic'] = !empty($topic) ? true : false;

    if (!empty($topic) && ($context['rates'] = cache_get_data('rates_topic_' . $topic, 360)) == null)
	{
		$dbrequest = $smcFunc['db_query']('', '
			SELECT mem.id_member, IFNULL(mem.real_name, "Guest") as real_name, msg.body, l.id_message, msg.id_board, a.attachment_type, a.filename, a.id_attach, mem.avatar, msg.rates as total
			FROM {db_prefix}rates AS l 
			     LEFT JOIN {db_prefix}messages AS msg ON (msg.id_msg = l.id_message)
			     LEFT JOIN {db_prefix}members AS mem ON (msg.id_member = mem.id_member)
			     LEFT JOIN {db_prefix}attachments AS a ON (msg.id_member = a.id_member)
			WHERE l.id_topic = {int:topic_id}
				AND msg.id_topic = {int:topic_id}
			GROUP BY l.id_message',
			array(
				'topic_id' => $topic,
			)
		);
	    while($row = $smcFunc['db_fetch_assoc']($dbrequest))
	    {
	    	$context['rates'][$row['id_message']] = array(
    			'member' => $row['real_name'] == 'Guest' ? 'Guest' : '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '">' . $row['real_name'] . '</a>',
    			'preview' => substr($row['body'], 0, 128),
    			'msg' => $row['id_message'],
    			'rates' => $row['total'],
    			'avatar' => $row['avatar'] == '' ? ($row['id_attach'] > 0 ? '<img class="avatar rates_avatar" src="' . (empty($row['attachment_type']) ? $scripturl . '?action=dlattach;attach=' . $row['id_attach'] . ';type=avatar' : $modSettings['custom_avatar_url'] . '/' . $row['filename']) . '" alt="" />' : '<img class="avatar rates_avatar" src="' . $settings['images_url'] . '/rates_no_avatar.png" alt="" />') : (stristr($row['avatar'], 'http://') ? '<img class="avatar rates_avatar" src="' . $row['avatar'] . '" alt="" />' : '<img class="avatar rates_avatar" src="' . $modSettings['avatar_url'] . '/' . htmlspecialchars($row['avatar']) . '" alt="" />'),
    			'href' => $scripturl . '?action=profile;u=' . $row['id_member'],
    		);
	    }
		$smcFunc['db_free_result']($dbrequest);
		
		if (isset($context['rates']) && is_array($context['rates']))
			usort($context['rates'], 'sort_by_rates');
		
		cache_put_data('rates_topic_' . $topic, $context['rates'], 360);
	}
	else if (!empty($_REQUEST['msg']) && ($context['members'] = cache_get_data('rates_post_' . (int) $_REQUEST['msg'], 3600)) == null)
	{
		$dbresult = $smcFunc['db_query']('', '
		SELECT 
			id_type, icon, name, post_value
		FROM {db_prefix}rates_types
		WHERE enabled = 1
			AND (id_boards = 0 OR FIND_IN_SET({int:board}, id_boards))' . (isset($_GET['is']) ? '' :
			' AND only_first_post = 0'). '
		ORDER BY custom_order ASC',
			array(
				'board' => (int) $_GET['b']
			)
		);
	    
		$context['types'] = array();
		while ($row = $smcFunc['db_fetch_assoc']($dbresult))
		{
			$context['message_types'][$row['id_type']] = array(
				'id_type' => $row['id_type'],
				'icon' => '<img src="' . $boardurl . '/rates_types/' . $row['icon'] . '" alt="' . $row['name'] . '" style="vertical-align: middle;" />',
				'name' => $row['name'],
				'members' => array(),
				'post_value' => $row['post_value']
			);
		}
		$smcFunc['db_free_result']($dbresult);
		
		
		$dbrequest = $smcFunc['db_query']('', '
			SELECT mem.id_member, mem.real_name, mem.posts, mem.rated, l.id_type, l.id_topic
			FROM {db_prefix}rates AS l 
				LEFT JOIN {db_prefix}members AS mem ON (mem.id_member = l.id_member)
			WHERE l.id_message = {int:msg}',
			array(
				'msg' => (int) $_REQUEST['msg'],
			)
		);
		
	    while($row = $smcFunc['db_fetch_assoc']($dbrequest))
	    {
	    	$context['message_types'][$row['id_type']]['members'][] = array(
	    		'link' => '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '" >' . $row['real_name'] . ' (' . $row['posts'] . ' ' . $txt['posts'] . ' / ' . $row['rated'] . ' ' . $txt['rates'] . ')</a>',
	    		'id_member' => $row['id_member'],
	    		'id_topic' => $row['id_topic']
	    	);
	    }
		$smcFunc['db_free_result']($dbrequest);
		cache_put_data('rates_post_' . (int) $_REQUEST['msg'], $context['members'], 3600);
	}

	// Now define the template
	loadTemplate('Facepunch');
	$context['template_layers'] = array('rates');
}

function RemoveRate()
{
	global $smcFunc;
	
	checkSession('get');
	
	$_GET['msg'] = (int) $_GET['msg'];
	$_GET['mem'] = (int) $_GET['mem'];
	$_GET['topic'] = (int) $_GET['topic'];
	$_GET['type'] = (int) $_GET['type'];
	
	// Get all the important info!
	$dbrequest = $smcFunc['db_query']('', '
		SELECT id_member
		FROM {db_prefix}messages
		WHERE id_msg = {int:id_msg}
		LIMIT 1',
			array(
				'id_msg' => $_GET['msg'],
			)
		);

	list($author) = $smcFunc['db_fetch_row']($dbrequest);
	$smcFunc['db_free_result']($dbrequest);
	
	$dbrequest = $smcFunc['db_query']('', '
		SELECT post_value
		FROM {db_prefix}rates_types
		WHERE id_type = {int:id_type}
		LIMIT 1',
			array(
				'id_type' => $_GET['type'],
			)
		);

	list($post_value) = $smcFunc['db_fetch_row']($dbrequest);
	$smcFunc['db_free_result']($dbrequest);
	
	// Time to remove this rate!
	$smcFunc['db_query']('', '
		UPDATE {db_prefix}messages
		SET rates = rates - {int:value}
		WHERE id_msg = {int:id_msg}
		LIMIT 1',
		array(
			'id_msg' => $_GET['msg'],
			'value' => $post_value
		)
	);
	
	$smcFunc['db_query']('', '
		UPDATE {db_prefix}topics
		SET rates = rates - {int:value}
		WHERE id_topic = {int:id_topic}
		LIMIT 1',
		array(
			'id_topic' => $_GET['topic'],
			'value' => $post_value
		)
	);
	
	$search_for = '';
	if ($post_value < 0)
	{
		$post_value *= -1;
		$search_for = 'rated';
	}
	else
		$search_for = 'rated_negative';
		
	if ($search_for != '')
		$smcFunc['db_query']('', '
			UPDATE {db_prefix}members
			SET ' . $search_for . ' = ' . $search_for . ' - {int:value}
			WHERE id_member = {int:author}
			LIMIT 1',
				array(
					'value' => $post_value,
					'author' => $author
				)
		);
		
	$smcFunc['db_query']('', '
		DELETE FROM {db_prefix}rates
		WHERE id_message = {int:id_msg}
			AND id_type = {int:type}
			AND id_member = {int:mem}
		LIMIT {int:limit}',
		array(
			'limit' => 1,
			'id_msg' => $_REQUEST['msg'],
			'mem' => $_GET['mem'],
			'type' => $_GET['type']
		)
	);
	
	cache_put_data('rates_topic_' . $_GET['topic'], array(), 1);
	cache_put_data('rates_post_' . $_REQUEST['msg'], array(), 1);
	
	redirectexit('topic=' . $_GET['topic'] . '.msg' . $_REQUEST['msg'] . '#msg' . $_REQUEST['msg']);
}

function sort_by_rates($a, $b)
{
	return $b['rates'] - $a['rates'];
}

function rate_error($error)
{
	if (isset($_GET['ajax']))
		die('ERROR: ' . $error);
	
	fatal_error($error, false);
}
?>