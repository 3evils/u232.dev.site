<?php
/**********************************************************************************
* Likes.english.php																  *
***********************************************************************************
*																				  *
* SMFPacks Likes Pro v1.3.9											  	 		  *
* Copyright (c) 2013 by SMFPacks.com. All rights reserved.					 	  *
* Powered by www.smfpacks.com													  *
* Created by NIBOGO for SMFPacks.com											  *
*																				  *
***********************************************************************************
*																				  *
* SMFPacks Likes Pro IS NOT FREE SOFTWARE								  		  *
* THIS ONLY CAN BE USED WITH A VALID LICENCE THAT CAN BE BOUGHT AT SMFPacks.com	  *
* YOU CANNOT REMOVE THE COPYRIGHT EITHER UNLESS YOU PURCHASED THE				  *
* COPYRIGHT FREE VERSION AT SMFPacks.com										  *
*																				  *
**********************************************************************************/

$txt['likes'] = 'Votos';
$txt['likes_like'] = 'Me gusta';
$txt['likes_members_who'] = 'Usuarios a los que les gusta esto';
$txt['likes_topic'] = 'Votos en este Tema';
$txt['likes_error'] = 'No hay datos suficientes para procesar la solicitud';
$txt['likes_spam_error'] = 'Solo puedes dar me gusta a mensajes cada: %d segundos';
$txt['likes_already'] = 'Ya has votado en este mensaje';
$txt['likes_allow_owner'] = 'Permitir votar al propietario del mensaje';
$txt['likes_allow_owner_desc'] = 'Los votos recibidos no aumentarán aunque se vote';
$txt['likes_no_yourself'] = 'No puedes votar por tus propios mensajes';
$txt['likes_spam'] = 'Permitir votos cada:';
$txt['likes_spam_desc'] = '0 para desactivar';
$txt['likes_seconds'] = 'segundos';
$txt['likes_liked'] = 'Votados';
$txt['likes_stats'] = 'Mostar 10 Mensajes votados y Usuarios Votados en Estad&iacute;sticas';
$txt['likes_mlist'] = 'Motrar Votos en la Lista de Usuarios';
$txt['likes_ajax'] = 'Activar votos Ajax';
$txt['likes_board'] = 'Permitir Votos';
$txt['allow_like'] = 'Votar Mensajes';
$txt['likes_dislike_fail'] = 'No puedes eliminar el voto en ese mensaje';
$txt['likes_unlike'] = 'Ya no me gusta';
$txt['likes_no_permission'] = 'Sin Permiso';
$txt['likes_settings'] = 'Ajustes de Votos';
$txt['likes_settings_description'] = 'Aqu&iacute; puedes configurar todos los ajustes relacionados con el sistema de votaci&oacute;n';
$txt['likes_show_liked'] = 'Muestra los votos recibidos en Temas';
$txt['likes_show_liked_desc'] = 'Muestra cuántos votos ha recibido un usuario';
$txt['likes_show_total'] = 'Muestra el total de votos en la cabecera de los Temas';
$txt['likes_show_total_posts'] = 'Muestra el total de votos en cada Mensaje';
$txt['likes_hide_total_list'] = 'Oculta la Lista de Votos en Temas';
$txt['likes_hide_post_list'] = 'Oculta la Lista de Votos en Mensajes';
$txt['likes_messageindex'] = 'Nuestra Votos de Temas en el &iacute;ndice del Mensaje';
$txt['likes_show_liked_profile'] = 'Mostrar Votos en Perfil';
$txt['likes_show_liked_pm'] = 'Mostrar Votados en Mensajes Personales';
$txt['likes_boards'] = 'Foros';
$txt['likes_boards_description'] = 'Aqu&iacute; puedes configurar en qué foros estará activado el sistema de votaci&oacute;n. Pulsa ctrl (o cmd en mac) para seleccionar varios foros a la vez. También puedes hacerlo usando may&uacute;sculas.';
$txt['likes_permissions'] = 'Permisos';
$txt['likes_all'] = 'Activar Votos en Todos los Foros';
$txt['likes_permissions_description'] = 'Aqu&iacute; puedes configurar quién puede votar mensajes con facilidad';
$txt['can_like'] = 'Votar Mensajes';
$txt['like_maintenance'] = 'Mantenimiento';
$txt['like_maintenance_description'] = 'Aqu&iacute; puedes recalcular todas las estad&iacute;sticas relacioandas con los Votos. Incluyendo el recuento de votos en cada tema, mensaje y perfil.';
$txt['likes_show_messages'] = 'Mensajes Votados';
$txt['likes_search'] = 'Votos M&iacute;nimos Necesarios';
$txt['likes_in_topic'] = 'en tema';
$txt['likes_in_post'] = 'en mensaje';
$txt['likes_show_liked_posts'] = 'Mostrar Temas Votados en Perfil';
$txt['likes_top_liked_topics'] = '10 Temas más votados';
$txt['likes_top_liked_users'] = '10 Usuarios más votados';
$txt['likes_only_first'] = 'Permitir votos s&oacute;lo en el primer mensaje';
$txt['permissionname_can_like'] = 'Votar Mensajes';
$txt['permissionhelp_can_like'] = 'Este permiso permite al usuario votar mensajes';
$txt['likes_button'] = 'Ubicaci&oacute;n del Boton';
$txt['likes_both'] = 'Ambos';
$txt['likes_buttons'] = 'Botones';
$txt['likes_counter'] = 'Despues del Contador';
$txt['likes_you'] = 't&iacute;';
$txt['likes_like_you'] = 'te gusta esto';
$txt['likes_likes_this'] = 'le gusta esto';
$txt['likes_like_this'] = 'les gusta esto';
$txt['likes_and'] = 'y';
$txt['likes_other'] = 'otro';
$txt['likes_others'] = 'otros';
$txt['likes_list_length'] = 'N&uacute;mero de personas a mostrar en la lista previa';
$txt['likes_with_ajax'] = 'Activar Ajax en Likes (No necesita refrescar pagina)';
$txt['like_first_post'] = 'Solo Permitir Likes en Primer Post';
$txt['likes_which_boards'] = 'Selecciona en que foros se permiten Likes';
$txt['likes_which_boards_only'] = 'Selecciona en que foros solo se permiten likes al primer post';
$txt['only_like_first_board'] = 'Solo Permitir Likes en Primer Post';
$txt['likes_first_list'] = 'A';
$txt['likes_icons_set'] = 'Selecciona el Set de Iconos';
$txt['likes_icons_set_desc'] = 'Por Defecto usa like.png y unlike.png, personalizado usa custom_like.png y custom_unlike.png';
$txt['likes_default'] = 'Por Defecto';
$txt['likes_custom'] = 'Personalizado';
$txt['likes_minimun_likes'] = 'Cantidad Minima de Votos Recibidos para Gustar';
$txt['likes_minimun_likes_desc'] = 'Si se pone en 50 y alguien ha recibido solo 30 votos, el no podra dar me gusta a mensajes sin importar otros ajustes';
$txt['likes_minimun_error'] = 'Solo personas con mas de %d votos recibidos puede dar en me gusta';
$txt['likes_not_only_first_all_boards'] = 'Todos los foros permiten votos en todos los mensajes';
$txt['likes_only_first_all_boards'] = 'Todos los foros restringen votos unicamente al primer post';
$txt['likes_per_day'] = 'por mensaje';

// 2.0 new strings
$txt['likes_no_type'] = 'No se selecciono ningun tipo';
$txt['likes_no_type_available'] = 'No se encontro ningun tipo, usted podria no tener permiso para usarlo';
$txt['likes_types'] = 'Tipos';
$txt['likes_types_description'] = 'Aqui se pueden modificar todos los tipos de me gusta para su foro';
$txt['likes_order'] = 'Orden';
$txt['likes_name'] = 'Nombre';
$txt['likes_only_first_post'] = 'Solo en primer mensaje';
$txt['likes_icon'] = 'Icono';
$txt['likes_post_value'] = 'Valor';
$txt['likes_post_value_desc'] = 'Cuantos puntos se le dara a cada mensaje por este me gusta? Use 3 para dar tres positivos, 0 para no dar nada o -2 para dos puntos negativos';
$txt['likes_enabled'] = 'Activado';
$txt['likes_nothing'] = 'No hay tipos';
$txt['likes_actions'] = 'Acciones';
$txt['likes_add_type'] = 'Agregar Nuevo Tipo';
$txt['likes_add_type_desc'] = 'Aqui se pueden agregar nuevos tipos de me gusta';
$txt['likes_save_order'] = 'Guardar Orden';
$txt['likes_boards'] = 'Foros';
$txt['likes_all_boards'] = 'Todos los foros';
$txt['likes_type_no_name'] = 'No se selecciono ningun nombre';
$txt['likes_type_no_icon'] = 'No se selecciono ningun icono';
$txt['likes_type_delete_warning'] = 'ADVERTENCIA! ESTO QUITARA TODOS LOS ME GUSTA DADOS CON ESTE TIPO Y PODRA ALTERAR LOS ME GUSTA RECIBIDOS POR TODOS LOS MIEMBROS. SI DESEA CONTINUAR TENGA EN TIEMPO QUE ESTO PODRA TOMAR MAS DE DOS MINUTOS EN COMPLETARSE';
$txt['likes_continue'] = 'Continuar';
$txt['can_see_likes'] = 'Ver me gusta en mensajes';
$txt['permissionname_can_see_likes'] = 'Ver me gusta en mensajes';
$txt['permissionhelp_can_see_likes'] = 'Este permiso permite ver los me gusta';
$txt['can_own_like'] = 'Me gusta a mensajes propios';
$txt['permissionname_can_own_like'] = 'Me gusta a mensajes propios';
$txt['permissionhelp_can_own_like'] = 'Permite dar me gusta a mensajes propios';
$txt['can_multiple_likes'] = 'Multiples me gusta al mismo mensaje';
$txt['permissionname_can_multiple_likes'] = 'Multiples me gusta al mismo mensaje';
$txt['permissionhelp_can_multiple_likes'] = 'Permite dar me gusta con mas de un tipo a un mismo mensaje';
$txt['can_remove_likes'] = 'Remover todos los me gusta';
$txt['permissionname_can_remove_likes'] = 'Remover todos los me gusta';
$txt['permissionhelp_can_remove_likes'] = 'Permite remover todos los me gusta';
$txt['likes_list_of_likers'] = 'Listado de Me Gusta';
$txt['likes_no_members'] = 'No hay nada que mostrar aun';
$txt['likes_hide'] = 'Ocultar contenido cuando el mensaje obtenga';
$txt['likes_hide_desc'] = 'Cuando un mensaje obtenga el numero de mensajes expuesto su contenido sera ocultado';
$txt['likes_hide_example'] = 'Por ejemplo, si se pone -5 entonces todos los mensajes con un total de me gusta igual o inferior a menos cinco tendran su contenido ocultado. Use -999999 para deshabilitar';
$txt['likes_hide_post'] = 'Total de Me Gusta';
$txt['likes_hide_message'] = 'Seleccionar un mensaje para ocultar mensajes';
$txt['likes_hide_message_desc'] = 'Si se seleccionar este mensaje se mostrara al ocultar el contenido de un mensaje';
$txt['likes_default_message'] = 'Este mensaje se ha ocultado debido a su total de me gusta.';
$txt['likes_show_message'] = 'Mostrar mensaje';
$txt['likes_possitive_received'] = '%d Me Gusta Positivos';
$txt['likes_negative_received'] = '%d Me Gusta Negativos';
$txt['likes_required'] = 'Me Gusta Requeridos';
$txt['likes_received'] = 'Me Gusta Recibidos';
$txt['likes_given'] = 'Me Gusta Dados';
$txt['likes_show_as'] = 'Mostrar Me Gusta recibidos como';
$txt['likes_show_total'] = 'Total de Me Gusta';
$txt['likes_show_possitive_and_negative'] = 'Positivo/Negativo';
$txt['likes_show_bar'] = 'Barra de Me Gusta';
$txt['likes_show_opacity'] = 'Aplicar Opacidad a caja de me gusta';
$txt['likes_show_opacity_desc'] = 'Se deshabilita cuando el cursor esta encima de la caja';
?>