<?php
/**********************************************************************************
* FacepunchAdmin.php															  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro v1.0											  	  	  *
* Copyright (c) 2013 by SMFPacks.com. All rights reserved.					 	  *
* Powered by www.smfpacks.com													  *
* Created by NIBOGO for SMFPacks.com											  *
*																				  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro IS NOT FREE SOFTWARE								  	  *
* THIS ONLY CAN BE USED WITH A VALID LICENCE THAT CAN BE BOUGHT AT SMFPacks.com	  *
* YOU CANNOT REMOVE THE COPYRIGHT EITHER UNLESS YOU PURCHASED THE				  *
* COPYRIGHT FREE VERSION AT SMFPacks.com										  *
*																				  *
**********************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

function FacepunchAdmin()
{
	if (!isset($_REQUEST['sa']) || $_REQUEST['sa'] == 'settings')
		rates_settings();
	else if ($_REQUEST['sa'] == 'boards')
		rates_boards();
	else if ($_REQUEST['sa'] == 'types')
		rates_types();
	else if ($_REQUEST['sa'] == 'add_type')
		rates_add_type();
	else
		rates_permissions();
}

function rates_settings($return_config = false)
{    
	global $user_info, $txt, $scripturl, $context, $sourcedir, $modSettings, $db_prefix;
	
	$context[$context['admin_menu_name']]['tab_data']['title'] = $txt['rates_settings'];
	$context[$context['admin_menu_name']]['tab_data']['description'] = $txt['rates_settings_description'];
	
	if (!$user_info['is_admin'])
		fatal_lang_error('rates_no_permission', false);

    $context['sub_template'] = 'show_settings';
    $context['page_title'] = $txt['rates_settings'];

	// We need this 
	require_once($sourcedir.'/ManageServer.php');
	
	$config_vars = array(
		array('check', 'rates_with_ajax'),
	    array('int', 'rates_spam', 'postinput' => $txt['rates_seconds'], 'subtext' => $txt['rates_spam_desc']),
	    array('int', 'rates_minimun_rates', 'subtext' => $txt['rates_minimun_rates_desc']),
	    array('int', 'rates_hide', 'subtext' => $txt['rates_hide_desc'] . '<div>' . $txt['rates_hide_example'] . '</div>', 'postinput' => '&#8805; ' . $txt['rates_hide_post']),
	    array('text', 'rates_hide_message', 80, 'subtext' => $txt['rates_hide_message_desc']),
	    '',
	    array('check', 'rates_show_opacity', 'subtext' => $txt['rates_show_opacity_desc']),
	    array('select', 'rates_show_as', array($txt['rates_show_total'], $txt['rates_show_possitive_and_negative'], $txt['rates_show_bar'])),
	    '',
	    array('check', 'rates_show_total'),
	    array('check', 'rates_hide_total_list'),
	    '',
	    array('check', 'rates_show_rated', 'subtext' => $txt['rates_show_rated_desc']),
	    array('check', 'rates_show_rated_profile'),
	    array('check', 'rates_show_rated_pm'),
	    array('check', 'rates_show_rated_posts'),
	    array('check', 'rates_stats'),
	    array('check', 'rates_mlist'),
	    array('check', 'rates_messageindex'),
	);

		
	if (isset($_GET['save']))
	{
		saveDBSettings($config_vars);
		redirectexit('action=admin;area=rates;sa=settings');
	}
	$context['post_url'] = $scripturl .'?action=admin;area=rates;sa=settings;save';	
	prepareDBSettingContext($config_vars);
}

function rates_boards()
{
	global $context, $txt, $settings, $user_info, $modSettings, $smcFunc, $scripturl;
	
	$context[$context['admin_menu_name']]['tab_data']['title'] = $txt['rates_boards'];
	$context[$context['admin_menu_name']]['tab_data']['description'] = $txt['rates_boards_description'];

	// Saving?
	if (isset($_GET['save']))
	{
		checkSession('post');

		if (!empty($_POST['boards']) && count(array_intersect($_POST['boards'], array(0))) == 0)
		{
			$smcFunc['db_query']('', '
				UPDATE {db_prefix}boards
				SET allow_rates = {int:enabled}
				WHERE id_board IN ({array_int:boards})',
				array(
					'enabled' => 1,
					'boards' => $_POST['boards']
				)
			);
			
			$smcFunc['db_query']('', '
				UPDATE {db_prefix}boards
				SET allow_rates = {int:disabled}
				WHERE id_board NOT IN ({array_int:boards})',
				array(
					'disabled' => 0,
					'boards' => $_POST['boards']
				)
			);
		}
		else
			$smcFunc['db_query']('', '
				UPDATE {db_prefix}boards
				SET allow_rates = {int:enabled}',
				array(
					'enabled' => 1
				)
			);
			
		if (!empty($_POST['second_boards']))
		{
			// If the allow rates in all posts is selected...
			if (count(array_intersect($_POST['second_boards'], array(-10))) == 1)
			{
				$smcFunc['db_query']('', '
					UPDATE {db_prefix}boards
					SET only_rate_first = {int:disabled}',
					array(
						'disabled' => 0,
					)
				);
			}
			elseif (count(array_intersect($_POST['second_boards'], array(0))) == 1)
			{
				$smcFunc['db_query']('', '
					UPDATE {db_prefix}boards
					SET only_rate_first = {int:enabled}',
					array(
						'enabled' => 1,
					)
				);
			}
			else
			{
				$smcFunc['db_query']('', '
					UPDATE {db_prefix}boards
					SET only_rate_first = {int:enabled}
					WHERE id_board IN ({array_int:boards})',
					array(
						'enabled' => 1,
						'boards' => $_POST['second_boards']
					)
				);
				
				$smcFunc['db_query']('', '
					UPDATE {db_prefix}boards
					SET only_rate_first = {int:disabled}
					WHERE id_board NOT IN ({array_int:boards})',
					array(
						'disabled' => 0,
						'boards' => $_POST['second_boards']
					)
				);
			}
		}

		redirectexit('action=admin;area=rates;sa=boards');
	}

	// Find the boards/cateogories they can see.
	$request = $smcFunc['db_query']('', '
		SELECT c.name AS cat_name, c.id_cat, b.id_board, b.name AS board_name, b.child_level, b.allow_rates, b.only_rate_first
		FROM {db_prefix}boards AS b
			LEFT JOIN {db_prefix}categories AS c ON (c.id_cat = b.id_cat)
		WHERE {query_see_board}');
		
	$context['boards'] = array();
	$this_cat = array('id' => -1);
	$i = 0;
	$j = 0;
	$i2 = 0;
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		if ($this_cat['id'] != $row['id_cat'])
		{
			$this_cat = &$context['boards'][];
			$this_cat['id'] = $row['id_cat'];
			$this_cat['name'] = $row['cat_name'];
			$this_cat['boards'] = array();
		}

		$this_cat['boards'][] = array(
			'id' => $row['id_board'],
			'name' => $row['board_name'],
			'child_level' => $row['child_level'],
			'allow_rates' => !empty($row['allow_rates']),
			'only_rate_first' => !empty($row['only_rate_first']),
		);
		
		if (!empty($row['only_rate_first']))
			$j++;
		else
			$i++;
			
		if (!empty($row['allow_rates']))
			$i2++;
	}
	
	if ($i == $smcFunc['db_num_rows']($request))
		$context['all_boards_none_first'] = true;
	else if ($j == $smcFunc['db_num_rows']($request))
		$context['all_boards_first'] = true;
		
	if ($i2 == $smcFunc['db_num_rows']($request))
		$context['all_boards_allow_rates'] = true;
	
	$smcFunc['db_free_result']($request);

	// Load a diffrent Template
	loadTemplate('Facepunch');
	$context['sub_template'] = 'rates_boards';
}

function rates_permissions($return_config = false)
{
	global $txt, $scripturl, $context, $settings, $sc, $sourcedir;
	global $modSettings, $smcFunc;
	
	$context[$context['admin_menu_name']]['tab_data']['title'] = $txt['rates_permissions'];
	$context[$context['admin_menu_name']]['tab_data']['description'] = $txt['rates_permissions_description'];

	$config_vars = array(
			array('permissions', 'can_see_rates', 'subtext' => $txt['permissionhelp_can_see_rates']),
			array('permissions', 'can_own_rate', 'subtext' => $txt['permissionhelp_can_own_rate']),
			array('permissions', 'can_multiple_rates', 'subtext' => $txt['permissionhelp_can_multiple_rates']),
			array('permissions', 'can_remove_rates', 'subtext' => $txt['permissionhelp_can_remove_rates']),
	);

	if ($return_config)
		return $config_vars;
		
	loadLanguage('ManagePermissions');
	require_once($sourcedir . '/ManagePermissions.php');
	require_once($sourcedir . '/ManageServer.php');
	$context['sub_template'] = 'show_settings';

	prepareDBSettingContext($config_vars);

	$context['general_permissions'] = array(
			'can_see_rates',
			'can_own_rate',
			'can_multiple_rates',
			'can_remove_rates',
	);

	// Saving?
	if (isset($_GET['save']))
	{
		loadIllegalPermissions();
		$insertRows = array();
		
		foreach ($context['general_permissions'] as $permission)
		{
			if (!isset($_POST[$permission]))
				continue;
				
			foreach ($_POST[$permission] as $id_group => $value)
			{
				if (in_array($value, array('on', 'deny')) && (empty($context['illegal_permissions']) || !in_array($permission, $context['illegal_permissions'])))
					$insertRows[] = array((int) $id_group, $permission, $value == 'on' ? 1 : 0);
			}

			unset($_POST[$permission]);
		}

		// Remove the old permissions…
		$smcFunc['db_query']('', '
			DELETE FROM {db_prefix}permissions
			WHERE permission IN ({array_string:permissions})
			' . (empty($context['illegal_permissions']) ? '' : ' AND permission NOT IN ({array_string:illegal_permissions})'),
			array(
				'illegal_permissions' => !empty($context['illegal_permissions']) ? $context['illegal_permissions'] : array(),
				'permissions' => $context['general_permissions'],
			)
		);

		// …and replace them with new ones.
		if (!empty($insertRows))
		{
			$smcFunc['db_insert']('insert',
				'{db_prefix}permissions',
				array('id_group' => 'int', 'permission' => 'string', 'add_deny' => 'int'),
				$insertRows,
				array('id_group', 'permission')
			);
		}
		
		updateChildPermissions(array(), -1);
		updateSettings(array('settings_updated' => time()));
		redirectexit('action=admin;area=rates;sa=permissions');
	}

	foreach ($context['general_permissions'] as $permission)
		$context[$permission] = array(
			-1 => array(
				'id' => -1,
				'name' => $txt['membergroups_guests'],
				'is_postgroup' => false,
				'status' => 'off',
			),
			0 => array(
				'id' => 0,
				'name' => $txt['membergroups_members'],
				'is_postgroup' => false,
				'status' => 'off',
			),
		);

	$request = $smcFunc['db_query']('', '
		SELECT id_group, CASE WHEN add_deny = {int:denied} THEN {string:deny} ELSE {string:on} END AS status, permission
		FROM {db_prefix}permissions
		WHERE id_group IN (-1, 0)
			AND permission IN ({array_string:permissions})',
		array(
			'denied' => 0,
			'permissions' => $context['general_permissions'],
			'deny' => 'deny',
			'on' => 'on',
		)
	);
	while ($row = $smcFunc['db_fetch_assoc']($request))
		$context[$row['permission']][$row['id_group']]['status'] = $row['status'];
	$smcFunc['db_free_result']($request);

	$request = $smcFunc['db_query']('', '
		SELECT mg.id_group, mg.group_name, mg.min_posts, IFNULL(p.add_deny, -1) AS status, p.permission
		FROM {db_prefix}membergroups AS mg
			LEFT JOIN {db_prefix}permissions AS p ON (p.id_group = mg.id_group AND p.permission IN ({array_string:permissions}))
		WHERE mg.id_group NOT IN (1, 3)
			AND mg.id_parent = {int:not_inherited}' . (empty($modSettings['permission_enable_postgroups']) ? '
			AND mg.min_posts = {int:min_posts}' : '') . '
		ORDER BY mg.min_posts, CASE WHEN mg.id_group < {int:newbie_group} THEN mg.id_group ELSE 4 END, mg.group_name',
		array(
			'id_profile_default' => 1,
			'not_inherited' => -2,
			'min_posts' => -1,
			'newbie_group' => 4,
			'permissions' => $context['general_permissions'],
		)
	);
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		foreach ($context['general_permissions'] as $permission)
			if (!isset($context[$permission][$row['id_group']]))
				$context[$permission][$row['id_group']] = array(
					'id' => $row['id_group'],
					'name' => $row['group_name'],
					'is_postgroup' => $row['min_posts'] != -1,
					'status' => 'off',
				);

		if(!empty($row['permission']))
			$context[$row['permission']][$row['id_group']]['status'] = empty($row['status']) ? 'deny' : ($row['status'] == 1 ? 'on' : 'off');
	}
	$smcFunc['db_free_result']($request);

	loadIllegalGuestPermissions();
	foreach($context['non_guest_permissions'] as $permission)
		if (!empty($context[$permission]))
			unset($context[$permission][-1]);

	// Some last important Settings :)
	$context['post_url'] = $scripturl . '?action=admin;area=rates;sa=permissions;save';
	$context['settings_title'] = $txt['rates_permissions'];
}

function rates_types($return_config = false)
{
	global $txt, $scripturl, $context, $settings, $settings, $sourcedir, $txt;
	global $modSettings, $smcFunc, $boardurl;
	
	loadTemplate('Facepunch');
	
	$context[$context['admin_menu_name']]['tab_data']['title'] = $txt['rates_types'];
	$context[$context['admin_menu_name']]['tab_data']['description'] = $txt['rates_types_description'];
	$context['sub_template'] = 'rates_types';
	
	if (isset($_REQUEST['do']))
	{
		checkSession('get');
		if ($_REQUEST['do'] == 'order')
		{
			// So do the order thing!
			$dbrequest = $smcFunc['db_query']('', '
				SELECT id_type
				FROM {db_prefix}rates_types');
				
			while ($row = $smcFunc['db_fetch_assoc']($dbrequest))
			{
				$smcFunc['db_query']('', '
				   UPDATE {db_prefix}rates_types
				   SET custom_order = {int:new_order}
				   WHERE id_type = {int:type}
				   LIMIT 1',
				   array(
					'new_order' => isset($_POST['order_' . $row['id_type']]) && is_numeric($_POST['order_' . $row['id_type']]) ? $_POST['order_' . $row['id_type']] : 0,
					'type' => $row['id_type'], 
				   )
				);
			}
			$smcFunc['db_free_result']($dbrequest);
		}
		else if ($_REQUEST['do'] == 'enabled' && isset($_GET['type']))
		{
			$smcFunc['db_query']('', '
			   UPDATE {db_prefix}rates_types
			   SET enabled = (CASE WHEN enabled = 1 THEN 0 ELSE 1 END)
			   WHERE id_type = {int:type}
			   LIMIT 1',
			   array(
			   		'type' => (int) $_GET['type'],
			   )
			);
		}
		else if ($_REQUEST['do'] == 'first' && isset($_GET['type']))
		{
			$smcFunc['db_query']('', '
			   UPDATE {db_prefix}rates_types
			   SET only_first_post = (CASE WHEN only_first_post = 1 THEN 0 ELSE 1 END)
			   WHERE id_type = {int:type}
			   LIMIT 1',
			   array(
			   		'type' => (int) $_GET['type'],
			   )
			);
		}
		
		redirectexit('action=admin;area=rates;sa=types;' . $context['session_var'] . '=' . $context['session_id']);
	}

	// Load All Types
    $dbresult = $smcFunc['db_query']('', '
	SELECT 
		name, post_value, enabled, only_first_post, icon, id_type, custom_order
	FROM {db_prefix}rates_types
	ORDER BY custom_order ASC'); 	
    
	$context['types'] = array();
	while ($row = $smcFunc['db_fetch_assoc']($dbresult))
	{
		$value = $row['post_value'];
		if ($value > 0)
			$value = '<span style="color: green;">+ ' . $row['post_value'] . '</span>';
		else if ($value < 0)
			$value = '<span style="color: red;">' . str_replace('-', '- ', $row['post_value']) . '</span>';
		
		$context['types'][] = array(
			'custom_order' => $row['custom_order'],
			'id_type' => $row['id_type'],
			'name' => $row['name'],
			'post_value' => $value,
			'enabled' => '<a href="' . $scripturl . '?action=admin;area=rates;sa=types;do=enabled;type=' . $row['id_type'] . ';' . $context['session_var'] . '=' . $context['session_id'] . '">' . (!empty($row['enabled']) ? '<img src="' . $settings['default_images_url'] . '/icons/package_installed.gif" alt="" />' : '<img src="' . $settings['default_images_url'] . '/icons/package_old.gif" alt="" />') . '</a>',
			'only_first_post' => '<a href="' . $scripturl . '?action=admin;area=rates;sa=types;do=first;type=' . $row['id_type'] . ';' . $context['session_var'] . '=' . $context['session_id'] . '">' . (!empty($row['only_first_post']) ? '<img src="' . $settings['default_images_url'] . '/icons/package_installed.gif" alt="" />' : '<img src="' . $settings['default_images_url'] . '/icons/package_old.gif" alt="" />') . '</a>',
			'icon' => '<img src="' . $boardurl . '/rates_types/' . $row['icon'] . '" alt="" />',
			'actions' => '<a href="' . $scripturl . '?action=admin;area=rates;sa=add_type;pid=' . $row['id_type'] . ';' . $context['session_var'] . '=' . $context['session_id'] . '"><img src="' . $settings['default_images_url'] . '/buttons/modify.gif" alt="' . $txt['modify'] . '" /></a> <a href="' . $scripturl . '?action=admin;area=rates;sa=add_type;remove=' . $row['id_type'] . ';' . $context['session_var'] . '=' . $context['session_id'] . '"><img src="' . $settings['default_images_url'] . '/buttons/delete.gif" alt="' . $txt['remove'] . '" /></a>',
		);
	}
	$smcFunc['db_free_result']($dbresult);
}

function rates_add_type()
{
	global $txt, $context, $smcFunc, $sourcedir, $board_info, $selected_boards, $user_info;	
	
	$context[$context['admin_menu_name']]['tab_data']['title'] = $txt['rates_add_type'];
	$context[$context['admin_menu_name']]['tab_data']['description'] = $txt['rates_add_type_desc'];
		
	// Load the sub-template
	loadTemplate('Facepunch');
	$context['sub_template']  = isset($_GET['remove']) ? 'rates_remove' : 'rates_add';
	$context['page_title'] = (empty($_REQUEST['pid'])) ? $txt['rates_add_type'] : $txt['modify'];
	
	if (isset($_GET['remove']) && isset($_GET['confirm']))
		rates_recalculate($_GET['remove'], 'remove');
	else if (isset($_GET['remove']))
		$context['page_title'] = $txt['remove'];
	else
	{
		if (isset($_POST['save']))
		{
			checkSession();
			
			// We need the name
			if (trim($_REQUEST['name']) == '')
				fatal_lang_error('rates_type_no_name', false);
				
			if (trim($_REQUEST['icon']) == '')
				fatal_lang_error('rates_type_no_icon', false);
				
			$name = $smcFunc['htmlspecialchars']($_REQUEST['name'], ENT_QUOTES);
			$icon = $smcFunc['htmlspecialchars']($_REQUEST['icon'], ENT_QUOTES);
			$post_value = trim($_REQUEST['post_value']) == '' || !is_numeric($_REQUEST['post_value']) ? 0 : $_REQUEST['post_value'];
				
			// Load all the boards stuff
			if (!isset($_REQUEST['boards']))
				$id_boards = 0;
			elseif ($_REQUEST['boards'] == 0)
			   	$id_boards = 0;
			else
			{   		
				foreach ($_REQUEST['boards'] as $i => $v)
			         if (!is_numeric($_REQUEST['boards'][$i])) unset($_REQUEST['boards'][$i]);	
				$id_boards = implode(',', $_REQUEST['boards']);
			}
			
			// Permissions
			$permissionsArray = array();
			if (isset($_REQUEST['groups']))
			{
				foreach ($_REQUEST['groups'] as $rgroup)
					$permissionsArray[] = (int) $rgroup;
			}
			$final_permissions = implode(',', $permissionsArray);
			
			$is_enabled = !empty($_POST['enabled']) ? 1 : 0;
			$only_first = !empty($_POST['first']) ? 1 : 0;
			
			// New one?
			if (!isset($_POST['type_id']))
			{
				$smcFunc['db_insert']('replace',
						'{db_prefix}rates_types',
						array(
							'name' => 'text', 'permissions' => 'text', 'id_boards' => 'text', 'icon' => 'text', 'enabled' => 'int', 'custom_order' => 'int', 'only_first_post' => 'int', 'post_value' => 'int'
						),
						array(
							$name, $final_permissions, $id_boards, $icon, $is_enabled, 0, $only_first, $post_value
						),
						array('id_type')
				);
			}
			// Editing
			else
			{
				$smcFunc['db_query']('', "
				UPDATE {db_prefix}rates_types
				SET name = '$name', permissions = '$final_permissions', id_boards = '$id_boards', icon = '$icon', enabled = '$is_enabled', only_first_post = '$only_first', post_value = '$post_value'
				WHERE id_type = {int:type}
				LIMIT 1",
				array(
			         'type' => (int) $_POST['type_id']
			      )
			    );
			    
			    if ($post_value != $_POST['last_post_value'])
			    	rates_recalculate($_POST['type_id'], 'update', $_POST['last_post_value'], $post_value);
			}
			
			redirectexit('action=admin;area=rates;sa=types;' . $context['session_var'] . '=' . $context['session_id']);
		}
		
		// Find the boards/cateogories they can see.
		$request = $smcFunc['db_query']('', "
			SELECT c.name AS cat_name, c.id_cat, b.id_board, b.name AS board_name, b.child_level
			FROM {db_prefix}boards AS b
				LEFT JOIN {db_prefix}categories AS c ON (c.id_cat = b.id_cat)
			WHERE $user_info[query_see_board]");
			
		$context['jump_to'] = array();
		$this_cat = array('id' => -1);
		while ($row = $smcFunc['db_fetch_assoc']($request))
		{
			if ($this_cat['id'] != $row['id_cat'])
			{
				$this_cat = &$context['jump_to'][];
				$this_cat['id'] = $row['id_cat'];
				$this_cat['name'] = $row['cat_name'];
				$this_cat['boards'] = array();
			}
	
			$this_cat['boards'][] = array(
				'id' => $row['id_board'],
				'name' => $row['board_name'],
				'child_level' => $row['child_level'],
				'is_current' => isset($context['current_board']) && $row['id_board'] == $context['current_board']
			);
		}
		$smcFunc['db_free_result']($request);
	
		//Load the language
	    loadLanguage('Admin');
		loadLanguage('Post');
		
		// We need the membergroups
		$dbresult = $smcFunc['db_query']('', '
	    SELECT id_group, group_name
	    FROM {db_prefix}membergroups
	    WHERE min_posts = {int:primary_group}
	      AND id_group <> {int:moderator}
	      ORDER BY group_name',
	      array(
	         'primary_group' => -1,
	         'moderator' => 3,
	      )
	    );
		$context['groups'] = array();
		while ($row = $smcFunc['db_fetch_assoc']($dbresult))
		{
			$context['groups'][$row['id_group']] = array(
				'id_group' => $row['id_group'],
				'group_name' => $row['group_name'],
				);
		}
		$smcFunc['db_free_result']($dbresult);
		
		// Default values
		$selected_boards = array();
		$context['type_data'] = array(
			'enabled' => true,
			'name' => '',
			'icon' => '',
			'only_first_post' => false,
			'id_boards' => 0,
			'post_value' => 0,
			'permissions' => '-1,0'
		);
		
		// We only need this in case that we want to edit
		if (!empty($_REQUEST['pid']))
		{
			$prefixID = (int) $_REQUEST['pid'];	
			
			// Load the prefix info 
			$dbresult = $smcFunc['db_query']('', '
			SELECT 
				*
			FROM {db_prefix}rates_types
			WHERE id_type = {int:type}      
		    LIMIT 1',
		      array(
		         'type' => $prefixID,        
		      )
		    );	
			$row = $smcFunc['db_fetch_assoc']($dbresult);
			$context['type_data'] = $row;
			$smcFunc['db_free_result']($dbresult);
			
			$boards_id = $context['type_data']['id_boards'];
		
			if (isset($context['type_data']['id_boards']))
			{
				foreach (explode(',', $context['type_data']['id_boards']) as $i => $v)
			     $selected_boards[$v] = $v;
			}
		}
	}
}

function rates_recalculate($type, $action, $old = 0, $new = 0)
{
	global $smcFunc, $context;
	
	checkSession('get');
	
	$new_value = $new - $old;
	if ($action == 'remove')
	{
		$db = $smcFunc['db_query']('', '
			SELECT post_value
			FROM {db_prefix}rates_types
			WHERE id_type = {int:type}
			LIMIT 1',
			array(
				'type' => $type
			)
		);
		list($the_value) = $smcFunc['db_fetch_row']($db);
		$smcFunc['db_free_result']($db);
		$new_value = $the_value * -1;
	}
	
	// Grab rates done with this type!
	$dbresult = $smcFunc['db_query']('', '
    SELECT id_member, id_message, id_topic, id_member_received
    FROM {db_prefix}rates
    WHERE id_type = {int:type}',
      array(
         'type' => $type,
      )
    );
    while ($row = $smcFunc['db_fetch_assoc']($dbresult))
	{
		$smcFunc['db_query']('', '
			UPDATE {db_prefix}topics
			SET rates = rates + {int:value}
			WHERE id_topic = {int:topic}
			LIMIT 1',
			array(
				'topic' => $row['id_topic'],
				'value' => $new_value
			)
		);
		
		$smcFunc['db_query']('', '
			UPDATE {db_prefix}messages
			SET rates = rates + {int:value}
			WHERE id_msg = {int:msg}
			LIMIT 1',
			array(
				'msg' => $row['id_message'],
				'value' => $new_value
			)
		);
		
		if ($row['id_member'] == $row['id_member_received'])
			continue;
			
		$smcFunc['db_query']('', '
			UPDATE {db_prefix}members
			SET rated' . ($action == 'remove' ? '_negative' : '') . ' = rated' . ($action == 'remove' ? '_negative' : '') . ' - {int:value}
			WHERE id_member = {int:member}
			LIMIT 1',
			array(
				'member' => $row['id_member_received'],
				'value' => $action == 'remove' ? ($new_value * -1) : $new_value
			)
		);
	}
	$smcFunc['db_free_result']($dbresult);
	
	if ($action == 'remove')
	{
		$dbresult = $smcFunc['db_query']('', '
	    DELETE FROM {db_prefix}rates_types
	    WHERE id_type = {int:type}',
	      array(
	         'type' => $type,
	      )
	    );
	    
	    $dbresult = $smcFunc['db_query']('', '
	    DELETE FROM {db_prefix}rates
	    WHERE id_type = {int:type}',
	      array(
	         'type' => $type,
	      )
	    );
	}
	
	redirectexit('action=admin;area=rates;sa=types;' . $context['session_var'] . '=' . $context['session_id']);
}
?>