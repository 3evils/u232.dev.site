<?php
/**********************************************************************************
* Facepunch.spanish_es-utf8.php													  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro v1.0											  	  	  *
* Copyright (c) 2013 by SMFPacks.com. All rights reserved.					 	  *
* Powered by www.smfpacks.com													  *
* Created by NIBOGO for SMFPacks.com											  *
*																				  *
***********************************************************************************
*																				  *
* SMFPacks Facepunch Pro IS NOT FREE SOFTWARE								  	  *
* THIS ONLY CAN BE USED WITH A VALID LICENCE THAT CAN BE BOUGHT AT SMFPacks.com	  *
* YOU CANNOT REMOVE THE COPYRIGHT EITHER UNLESS YOU PURCHASED THE				  *
* COPYRIGHT FREE VERSION AT SMFPacks.com										  *
*																				  *
**********************************************************************************/

$txt['rates'] = 'Votos';
$txt['rates_rate'] = 'Me gusta';
$txt['rates_members_who'] = 'Usuarios a los que les gusta esto';
$txt['rates_topic'] = 'Votos en este Tema';
$txt['rates_error'] = 'No hay datos suficientes para procesar la solicitud';
$txt['rates_spam_error'] = 'Solo puedes dar me gusta a mensajes cada: %d segundos';
$txt['rates_already'] = 'Ya has votado en este mensaje';
$txt['rates_allow_owner'] = 'Permitir votar al propietario del mensaje';
$txt['rates_allow_owner_desc'] = 'Los votos recibidos no aumentarán aunque se vote';
$txt['rates_no_yourself'] = 'No puedes votar por tus propios mensajes';
$txt['rates_spam'] = 'Permitir votos cada:';
$txt['rates_spam_desc'] = '0 para desactivar';
$txt['rates_seconds'] = 'segundos';
$txt['rates_rated'] = 'Votados';
$txt['rates_stats'] = 'Mostar 10 Mensajes votados y Usuarios Votados en Estadísticas';
$txt['rates_mlist'] = 'Motrar Votos en la Lista de Usuarios';
$txt['rates_ajax'] = 'Activar votos Ajax';
$txt['rates_board'] = 'Permitir Votos';
$txt['allow_rate'] = 'Votar Mensajes';
$txt['rates_disrate_fail'] = 'No puedes eliminar el voto en ese mensaje';
$txt['rates_unrate'] = 'Ya no me gusta';
$txt['rates_no_permission'] = 'Sin Permiso';
$txt['rates_settings'] = 'Ajustes de Votos';
$txt['rates_settings_description'] = 'Aquí puedes configurar todos los ajustes relacionados con el sistema de votación';
$txt['rates_show_rated'] = 'Muestra los votos recibidos en Temas';
$txt['rates_show_rated_desc'] = 'Muestra cuántos votos ha recibido un usuario';
$txt['rates_show_total'] = 'Muestra el total de votos en la cabecera de los Temas';
$txt['rates_show_total_posts'] = 'Muestra el total de votos en cada Mensaje';
$txt['rates_hide_total_list'] = 'Oculta la Lista de Votos en Temas';
$txt['rates_hide_post_list'] = 'Oculta la Lista de Votos en Mensajes';
$txt['rates_messageindex'] = 'Nuestra Votos de Temas en el Índice del Mensaje';
$txt['rates_show_rated_profile'] = 'Mostrar Votos en Perfil';
$txt['rates_show_rated_pm'] = 'Mostrar Votados en Mensajes Personales';
$txt['rates_boards'] = 'Foros';
$txt['rates_boards_description'] = 'Aquí puedes configurar en qué foros estará activado el sistema de votación. Pulsa ctrl (o cmd en mac) para seleccionar varios foros a la vez. También puedes hacerlo usando mayúsculas.';
$txt['rates_permissions'] = 'Permisos';
$txt['rates_all'] = 'Activar Votos en Todos los Foros';
$txt['rates_permissions_description'] = 'Aquí puedes configurar quién puede votar mensajes con facilidad';
$txt['can_rate'] = 'Votar Mensajes';
$txt['rate_maintenance'] = 'Mantenimiento';
$txt['rate_maintenance_description'] = 'Aquí puedes recalcular todas las estadísticas relacioandas con los Votos. Incluyendo el recuento de votos en cada tema, mensaje y perfil.';
$txt['rates_show_messages'] = 'Mensajes Votados';
$txt['rates_search'] = 'Votos Mínimos Necesarios';
$txt['rates_in_topic'] = 'en tema';
$txt['rates_in_post'] = 'en mensaje';
$txt['rates_show_rated_posts'] = 'Mostrar Temas Votados en Perfil';
$txt['rates_top_rated_topics'] = '10 Temas más votados';
$txt['rates_top_rated_users'] = '10 Usuarios más votados';
$txt['rates_only_first'] = 'Permitir votos sólo en el primer mensaje';
$txt['permissionname_can_rate'] = 'Votar Mensajes';
$txt['permissionhelp_can_rate'] = 'Este permiso permite al usuario votar mensajes';
$txt['rates_button'] = 'Ubicación del Boton';
$txt['rates_both'] = 'Ambos';
$txt['rates_buttons'] = 'Botones';
$txt['rates_counter'] = 'Despues del Contador';
$txt['rates_you'] = 'tí';
$txt['rates_rate_you'] = 'te gusta esto';
$txt['rates_rates_this'] = 'le gusta esto';
$txt['rates_rate_this'] = 'les gusta esto';
$txt['rates_and'] = 'y';
$txt['rates_other'] = 'otro';
$txt['rates_others'] = 'otros';
$txt['rates_list_length'] = 'Número de personas a mostrar en la lista previa';
$txt['rates_with_ajax'] = 'Activar Ajax en Calificaciones (No necesita refrescar pagina)';
$txt['rate_first_post'] = 'Solo Permitir Calificaciones en Primer Post';
$txt['rates_which_boards'] = 'Selecciona en que foros se permite calificar';
$txt['rates_which_boards_only'] = 'Selecciona en que foros solo se permiten rates al primer post';
$txt['only_rate_first_board'] = 'Solo Permitir Calificaciones en Primer Post';
$txt['rates_first_list'] = 'A';
$txt['rates_icons_set'] = 'Selecciona el Set de Iconos';
$txt['rates_icons_set_desc'] = 'Por Defecto usa rate.png y unrate.png, personalizado usa custom_rate.png y custom_unrate.png';
$txt['rates_default'] = 'Por Defecto';
$txt['rates_custom'] = 'Personalizado';
$txt['rates_minimun_rates'] = 'Cantidad Minima de Votos Recibidos para Gustar';
$txt['rates_minimun_rates_desc'] = 'Si se pone en 50 y alguien ha recibido solo 30 votos, el no podra dar me gusta a mensajes sin importar otros ajustes';
$txt['rates_minimun_error'] = 'Solo personas con mas de %d votos recibidos puede dar en me gusta';
$txt['rates_not_only_first_all_boards'] = 'Todos los foros permiten votos en todos los mensajes';
$txt['rates_only_first_all_boards'] = 'Todos los foros restringen votos unicamente al primer post';
$txt['rates_per_day'] = 'por mensaje';

// 2.0 new strings
$txt['rates_no_type'] = 'No se selecciono ningun tipo';
$txt['rates_no_type_available'] = 'No se encontro ningun tipo, usted podria no tener permiso para usarlo';
$txt['rates_types'] = 'Tipos';
$txt['rates_types_description'] = 'Aqui se pueden modificar todos los tipos de me gusta para su foro';
$txt['rates_order'] = 'Orden';
$txt['rates_name'] = 'Nombre';
$txt['rates_only_first_post'] = 'Solo en primer mensaje';
$txt['rates_icon'] = 'Icono';
$txt['rates_post_value'] = 'Valor';
$txt['rates_post_value_desc'] = 'Cuantos puntos se le dara a cada mensaje por este me gusta? Use 3 para dar tres positivos, 0 para no dar nada o -2 para dos puntos negativos';
$txt['rates_enabled'] = 'Activado';
$txt['rates_nothing'] = 'No hay tipos';
$txt['rates_actions'] = 'Acciones';
$txt['rates_add_type'] = 'Agregar Nuevo Tipo';
$txt['rates_add_type_desc'] = 'Aqui se pueden agregar nuevos tipos de me gusta';
$txt['rates_save_order'] = 'Guardar Orden';
$txt['rates_boards'] = 'Foros';
$txt['rates_all_boards'] = 'Todos los foros';
$txt['rates_type_no_name'] = 'No se selecciono ningun nombre';
$txt['rates_type_no_icon'] = 'No se selecciono ningun icono';
$txt['rates_type_delete_warning'] = 'ADVERTENCIA! ESTO QUITARA TODOS LOS ME GUSTA DADOS CON ESTE TIPO Y PODRA ALTERAR LOS ME GUSTA RECIBIDOS POR TODOS LOS MIEMBROS. SI DESEA CONTINUAR TENGA EN TIEMPO QUE ESTO PODRA TOMAR MAS DE DOS MINUTOS EN COMPLETARSE';
$txt['rates_continue'] = 'Continuar';
$txt['can_see_rates'] = 'Ver me gusta en mensajes';
$txt['permissionname_can_see_rates'] = 'Ver me gusta en mensajes';
$txt['permissionhelp_can_see_rates'] = 'Este permiso permite ver los me gusta';
$txt['can_own_rate'] = 'Me gusta a mensajes propios';
$txt['permissionname_can_own_rate'] = 'Me gusta a mensajes propios';
$txt['permissionhelp_can_own_rate'] = 'Permite dar me gusta a mensajes propios';
$txt['can_multiple_rates'] = 'Multiples me gusta al mismo mensaje';
$txt['permissionname_can_multiple_rates'] = 'Multiples me gusta al mismo mensaje';
$txt['permissionhelp_can_multiple_rates'] = 'Permite dar me gusta con mas de un tipo a un mismo mensaje';
$txt['can_remove_rates'] = 'Remover todos los me gusta';
$txt['permissionname_can_remove_rates'] = 'Remover todos los me gusta';
$txt['permissionhelp_can_remove_rates'] = 'Permite remover todos los me gusta';
$txt['rates_list_of_raters'] = 'Listado de Me Gusta';
$txt['rates_no_members'] = 'No hay nada que mostrar aun';
$txt['rates_hide'] = 'Ocultar contenido cuando el mensaje obtenga';
$txt['rates_hide_desc'] = 'Cuando un mensaje obtenga el numero de mensajes expuesto su contenido sera ocultado';
$txt['rates_hide_example'] = 'Por ejemplo, si se pone -5 entonces todos los mensajes con un total de me gusta igual o inferior a menos cinco tendran su contenido ocultado. Use -999999 para deshabilitar';
$txt['rates_hide_post'] = 'Total de Me Gusta';
$txt['rates_hide_message'] = 'Seleccionar un mensaje para ocultar mensajes';
$txt['rates_hide_message_desc'] = 'Si se seleccionar este mensaje se mostrara al ocultar el contenido de un mensaje';
$txt['rates_default_message'] = 'Este mensaje se ha ocultado debido a su total de me gusta.';
$txt['rates_show_message'] = 'Mostrar mensaje';
$txt['rates_possitive_received'] = '%d Me Gusta Positivos';
$txt['rates_negative_received'] = '%d Me Gusta Negativos';
$txt['rates_required'] = 'Me Gusta Requeridos';
$txt['rates_received'] = 'Me Gusta Recibidos';
$txt['rates_given'] = 'Me Gusta Dados';
$txt['rates_show_as'] = 'Mostrar Me Gusta recibidos como';
$txt['rates_show_total'] = 'Total de Me Gusta';
$txt['rates_show_possitive_and_negative'] = 'Positivo/Negativo';
$txt['rates_show_bar'] = 'Barra de Me Gusta';
$txt['rates_show_opacity'] = 'Aplicar Opacidad a caja de me gusta';
$txt['rates_show_opacity_desc'] = 'Se deshabilita cuando el cursor esta encima de la caja';
?>