<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif(!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify that you put this file in the same place as SMF\'s index.php and SSI.php files.');

if ((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin privileges required.');
	
db_extend('packages');

$smcFunc['db_insert']('ignore',
	'{db_prefix}settings',
	array(
		'variable' => 'string',
		'value' => 'string'
	),
	array(
		array('messageIcons_enable', '1'),
	),
	array('variable')
);

$smcFunc['db_query']('', "DELETE FROM {db_prefix}message_icons");

$smcFunc['db_insert']('ignore',
	'{db_prefix}message_icons',
	array(
		'filename' => 'string',
		'title' => 'string',
		'icon_order' => 'int'
	),
	array(
		array('xx', 'Standard', 0),
		array('thumbup', 'Thumb Up', 1),
		array('thumbdown', 'Thumb Down', 2),
		array('exclamation', 'Exclamation point', 3),
		array('question', 'Question mark', 4),
		array('bug', 'Bug', 5),
		array('smiley', 'Smiley', 6),
		array('cheesy', 'Cheesy', 7),
		array('angry', 'Angry', 8),
		array('lamp', 'Lamp', 9),
		array('card', 'Card', 10),
		array('grin', 'Grin', 11),
		array('sad', 'Sad', 12),
		array('wink', 'Wink', 13),
		array('leaf', 'Leaf', 14),
		array('present', 'Present', 15),
		array('car', 'Car', 16),
	),
	array('icon_order')
);

if (SMF == 'SSI')
	echo 'Database changes are complete! Please wait...';

?>