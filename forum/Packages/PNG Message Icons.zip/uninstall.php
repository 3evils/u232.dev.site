<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif(!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify that you put this file in the same place as SMF\'s index.php and SSI.php files.');

if ((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin privileges required.');
	
global $smcFunc;

$smcFunc['db_query']('', "DELETE FROM {db_prefix}message_icons", array());

$smcFunc['db_query']('', "
	INSERT INTO {db_prefix}message_icons (filename, title, icon_order)
	VALUES ('xx', 'Standard', '0'),
		('thumbup', 'Thumb Up', '1'),
		('thumbdown', 'Thumb Down', '2'),
		('exclamation', 'Exclamation point', '3'),
		('question', 'Question mark', '4'),
		('lamp', 'Lamp', '5'),
		('smiley', 'Smiley', '6'),
		('angry', 'Angry', '7'),
		('cheesy', 'Cheesy', '8'),
		('grin', 'Grin', '9'),
		('sad', 'Sad', '10'),
		('wink', 'Wink', '11')"
);

if (SMF == 'SSI')
	echo 'Database changes are complete! Please wait...';

?>