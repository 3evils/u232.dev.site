
[size=12pt][b]Dynamic Memberlist 2.0.6 (a slightly different look)[/b][/size]
by Antechinus 

This modification (for SMF 2.0 only) completely replaces the standard SMF Memberlist.template.php. 
The new template includes full 2.0 sorting options and has an added option to sort members by last activity.

Member blocks stack dynamically according to available width. No scroll bar is required on 800 px wide screens.
Header and avatar are coded with hidden overflow so that large avatars and long usernames do not break the layout. 
Avatars are clickable and will redirect to the member's profile (if allowed) or to the login/registration page.

By default this template will fully display avatars up to 125px wide by 150px high and usernames up to 16 letters long.
Changes may be made in the classes at the end of index.css and rtl.css, or by changing the memberlist_bg.png or memberlist_buttons.png images.

[b]This latest version has been recoded so that:[/b]

1/ the sorting options will now stack cleanly to another line if there are extra custom options and/or if the screen is very narrow.

2/ all inline css has been removed so more styling changes can be made without touching the template.

3/ apart from the actual search form, this version is completely tableless.

4/ oversized avatars will not overflow the blocks any more (although you should really sort the sizing in admin).

5/ LTR languages have full css support for all browsers including Internet Explorer.

6/ RTL languages have full css support for all browsers except Internet Explorer.

NOTE: If you want to use IE 6, 7 or 8 with an RTL language I suggest you stick to the standard memberlist.

This version has been tested in IE6, IE7, IE8, Safari, Chrome, Opera, and Firefox 2 through to Firefox 4.0.


