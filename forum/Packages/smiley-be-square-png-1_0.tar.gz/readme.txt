Package: Smiley - Be Square
©2010 Brannon Hall - All Rights Reserved

All smileys are original work by the author. You may not redistribute these icons separately from this SMF modification.

Once the package has been installed, you will need to manually add the smiley set to your SMF install from its administration center.
