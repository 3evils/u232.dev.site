<?php
/********************************************************
* Adk Topic Private                
* Version: 1.0
* Official support: http://www.smfpersonal.net           
* Auhot: ^Heracles^
* 2011
/**********************************************************/
	$direct_install = false;
	
if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')){
	require_once(dirname(__FILE__) . '/SSI.php');
	$direct_install = true;
}
elseif (!defined('SMF'))
	die('Adk Topic Private wasn\'t able to conect to smf');
	
	global $smcFunc;
	
	db_extend('packages');
	
$drops = array(
	'topics' => 'is_private',
);

foreach($drops AS $table => $column)
	$smcFunc['db_remove_column']('{db_prefix}'.$table, $column, array(), 'ignore');


	$deleteinsert = array(
		'Private_Act',
		'Private_board'
	);
	
	//Delete Settings
	$smcFunc['db_query']('','
		DELETE FROM {db_prefix}settings WHERE 
		variable IN ({array_string:settings})',
		array(
			'settings' => $deleteinsert,
		)
	);

	if($direct_install)
		echo'Done...';
?>
