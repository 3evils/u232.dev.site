<?php
/********************************************************
* Adk Topic Private                
* Version: 1.0
* Official support: http://www.smfpersonal.net           
* Auhot: ^Heracles^
* 2011
/**********************************************************/

	$direct_install = false;

if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')){
	require_once(dirname(__FILE__) . '/SSI.php');
	$direct_install = true;
}
elseif (!defined('SMF'))
	die('Adk Topic Private wasn\'t able to conect to smf');
	
	global $scripturl, $boardurl, $db_prefix;
	
	db_extend('packages');
	
	$columns[] = array(
		'table_name' => '{db_prefix}topics',
		'column_info' => array(
			'name' => 'is_private',
			'type' => 'tinyint',
			'default' => '0',
			'auto' => false,
			'unsigned' => false,
		),
		'parameters' => array(),
		'if_exists' => 'ignore',
	);
	
	foreach($columns AS $add)
		$smcFunc['db_add_column']($add['table_name'], $add['column_info'], $add['parameters'], $add['if_exists'], 'fatal');
	
	
	if($direct_install)
		echo'Done...';

?>