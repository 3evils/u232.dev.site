[center][size=18pt][font=tahoma][b][color=#006666]Adk Topic Private 1.0[/color][/b][/font][/size][/center]

[center][url=http://www.smfpersonal.net/][img]http://www.smfpersonal.net/imagen-mods/adk-team.png[/img][/url][/center]

[img]http://www.smfpersonal.net/famfamfam/user.png[/img] [b]Autor/Author:[/b]
     [url=http://www.smfpersonal.net/profiles/heracles-u259.html][color=#9A0ABC][b]^HeRaCLeS^[/b][/color][/url]
     
[img]http://www.smfpersonal.net/famfamfam/page_white_flash.png[/img] [b]Caracter�sticas:[/b]

     Esta aplicaci�n nos permitira agregar una opcion en los temas, para convertirlos en privados.
     Caracter�sticas:
          &#8226; Activar/Desactivar el mod.
          &#8226; Ingresar las id de los foros donde se quiere activar.
     En caso de no ingresar ninguna id, se activara en todos los foros.

     Si se pone el tema como privado solo lo podran ver los usuarios registrados, 
     mostrando a los visitantes una nueva pagina en lugar del tema.
     
Las opciones de este mod se encuentran en:
[i]Admin -> Modificaciones[/i]

Copyright 2011 by SMF Personal @ visita [url=http://www.smfpersonal.net]www.smfpersonal.net[/url] para soporte oficial. 

Si tu quieres ayudarnos, por favor visita nuestra seccion de contribuciones: [url=http://www.smfpersonal.net/about.html;sa=contritube-spanish]Contribuir[/url]

[hr]
[img]http://www.smfpersonal.net/famfamfam/page_white_flash.png[/img] [b]Features:[/b]

     This application will allow us to add an option in the topics, to make them private.
     Features:
          &#8226; Enable/Disable the mod.
          &#8226; Enter the id of the forums where you want to enable.
     If you do not enter any id, was activated in all the forums.

     If put the topic in private, only what users will see,
     taking visitors a new page instead of the topic.

The options of this mod are in:
[i]Admin -> Modification Settings[/i]

Copyright 2011 by SMF Personal @ visit [url=http://www.smfpersonal.net]www.smfpersonal.net[/url] for official support. 

If you want help, please visit our contributions section: [url=http://www.smfpersonal.net/about.html;sa=contribute]Contribute[/url]

[hr]

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Idiomas/Languages:[/b]

o English
o English-utf8
o Spanish_es
o Spanish_es-utf8
o Spanish_latin
o Spanish_latin-utf8

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Compatibilidad/Compatibility:[/b]
     SMF 2.0 RC5
     SMF 2.0 Gold
     SMF 2.0.2
     SMF 2.0.2

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Desarrollador/Developer:[/b]
     [url=http://www.smfpersonal.net][b]Adk-Team[/b][/url]

