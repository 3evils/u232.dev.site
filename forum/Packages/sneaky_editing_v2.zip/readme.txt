Thanks for installing [b]Sneaky Editing[/b].

This modification will allow you to modify posts without anyone noticing.
However, as this is done by manipulating the data input, you won't be able to change what you have done (once an edit's in place it will stay, once you chose to hide one there's no way to retrieve it).
So choose your actions wisely and use this feature with care.

The code included is licensed via [url=http://www.perlfoundation.org/artistic_license_2_0]Artistic License 2.0[/url].